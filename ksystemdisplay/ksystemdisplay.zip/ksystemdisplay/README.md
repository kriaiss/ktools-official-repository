<div align="center">
    <pre>
    __                            __                      .___.__               .__                
    |  | __  _________.__. _______/  |_  ____   _____    __| _/|__| ____________ |  | _____  ___.__.
    |  |/ / /  ___<   |  |/  ___/\   __\/ __ \ /     \  / __ | |  |/  ___/\____ \|  | \__  \<   |  |
    |    <  \___ \ \___  |\___ \  |  | \  ___/|  Y Y  \/ /_/ | |  |\___ \ |  |_> >  |__/ __ \\___  |
    |__|_ \/____  >/ ____/____  > |__|  \___  >__|_|  /\____ | |__/____  >|   __/|____(____  / ____|
        \/     \/ \/         \/            \/      \/      \/         \/ |__|             \/\/     
    </pre>
</div>
<p align="center">
    The telemetry overlay for ktools.
</p>
<p align="center">
    <img src="https://img.shields.io/badge/python-3.12+-blue?style=flat-square" alt="Python">
    <img src="https://img.shields.io/badge/platform-macOS-lightgrey?style=flat-square" alt="Platform">
</p>

⠀

## What is ksystemdisplay?

`ksystemdisplay` is a telemetry overlay for `ktools`. It displays live system statistics on your desktop in a low-footprint, frameless window that lives above all spaces and ignores user focus. This plugin serves as the **reference implementation** for `fixed` layer plugins in the `ktools` engine.

### Core Features
* **Live Metrics**: CPU, RAM, Disk and Network usage tracking using `psutil`.
* **Accurate Data**: RAM calculations use `ram.used` to perfectly match the macOS Activity Monitor.
* **Non-Intrusive**: Frameless, click-through, and `IgnoresCycle` behaviors keep it hidden from `Cmd+Tab` switchers.

⠀

## Screenshots section

<img src="ksystemdisplay.png" alt="Screenshot" width="300">

⠀

## How to Use (For Users)

1. Download the `ksystemdisplay` `.zip` archive from the Releases page.
2. Open the **ktools Plugin Manager** from your menu bar and click **import plugins** to install it.
3. Press `⌥⌘\` (Option + Command + Backslash).
4. The display slides in from the left side of the screen.
5. It completely ignores mouse input, so it won't block clicks when you are working in other apps.

⠀

## API & Architecture (For Plugin Developers)

`ksystemdisplay` is the definitive example of how to build a `fixed` layer plugin. A `fixed` plugin is a standalone, floating UI that exists independently of the main `kshell` overlay.

### 1. Registering the Fixed Layer
In your plugin's `__init__`, you must explicitly declare the layer type. This tells `ktools` to treat your UI as a persistent desktop widget rather than a standard window or a `kshell` tab.

```python
class Plugin:
    def __init__(self, ktools):
        self.ktools = ktools
        self.layer = "fixed" # CRITICAL: This assigns the plugin to the fixed layer
        self.name = "ksystemdisplay"
```

### 2. Toggling the UI
Because `fixed` plugins inherit from `OverlayWindow` (imported from `main.py`), `ktools` handles the slide-in/slide-out animations automatically. To show or hide your widget, simply call:

```python
self.ktools.toggle_plugin("ksystemdisplay")
```
Do not call `.show()` or `.hide()` manually.

### 3. Native macOS Ghosting (Click-Through)
To make your widget truly non-intrusive (so users can click "through" it to the desktop behind it) and keep it on all virtual desktops without showing up in `Cmd+Tab`, you must use PyObjC to modify the `NSWindow` flags after the UI is rendered:

```python
def _apply_native_flags(self):
    view_ptr = int(self.winId())
    ns_view = objc.objc_object(c_void_p=view_ptr)
    window = ns_view.window()
    
    if window:
        window.setLevel_(NSStatusWindowLevel + 1)
        window.setIgnoresMouseEvents_(True) # Click-through
        
        behavior = (NSWindowCollectionBehaviorCanJoinAllSpaces | 
                    NSWindowCollectionBehaviorStationary | 
                    NSWindowCollectionBehaviorIgnoresCycle) # Hide from Cmd+Tab
        window.setCollectionBehavior_(behavior)
```

### 4. Throttled Polling (Save the Battery)
**Rule:** Never run a telemetry loop while your widget is hidden.
**Why:** Querying `psutil.cpu_percent()` requires system calls that wake up the CPU. If you leave a 2-second `QTimer` running when the user can't even see the widget, your plugin will drain the battery unnecessarily.

Always check visibility before doing work:
```python
def refresh_stats(self):
    # If the window is hidden or currently sliding out, do nothing
    if not self.isVisible() or self.windowOpacity() < 0.05:
        return
        
    # Do expensive psutil calls here...
```

⠀

by kriaiss.
