import psutil
import platform
import time
import objc
import os
import json
import subprocess
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QFrame, QApplication, QProgressBar)
from PyQt6.QtCore import (Qt, QPoint, QTimer, pyqtSignal, QObject, QEasingCurve, QParallelAnimationGroup)
from main import OverlayWindow
from PyQt6.QtGui import QAction
from AppKit import (NSUserDefaults, NSEvent, NSKeyDownMask, 
                    NSWindowCollectionBehaviorCanJoinAllSpaces,
                    NSWindowCollectionBehaviorStationary,
                    NSWindowCollectionBehaviorIgnoresCycle,
                    NSWindow, NSStatusWindowLevel)

def get_ksys_theme(is_dark):
    bg = "transparent"
    text = "#ffffff" if is_dark else "#000000"
    subtext = "rgba(255, 255, 255, 140)" if is_dark else "rgba(0, 0, 0, 140)"
    border = "rgba(255, 255, 255, 25)" if is_dark else "rgba(0, 0, 0, 25)"
    bar_bg = "rgba(255, 255, 255, 30)" if is_dark else "rgba(0, 0, 0, 20)"
    
    return f"""
    QFrame#MainContainer {{
        background: {bg};
        border-radius: 24px;
        border: 1px solid {border};
    }}
    QLabel {{ font-family: 'Menlo'; }}
    QLabel#Title {{ color: {subtext}; font-size: 10px; font-weight: bold; text-transform: uppercase; }}
    QLabel#Value {{ color: {text}; font-size: 12px; font-weight: bold; }}
    QLabel#Info {{ color: {subtext}; font-size: 9px; }}
    QProgressBar {{
        border: none;
        background-color: {bar_bg};
        height: 4px;
        border-radius: 2px;
    }}
    QProgressBar::chunk {{ background-color: #007AFF; border-radius: 2px; }}
    """

class StatRow(QWidget):
    def __init__(self, title):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        
        header = QHBoxLayout()
        self.title_label = QLabel(title)
        self.title_label.setObjectName("Title")
        self.val_label = QLabel("0%")
        self.val_label.setObjectName("Value")
        header.addWidget(self.title_label)
        header.addStretch()
        header.addWidget(self.val_label)
        
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)
        self.info_label = QLabel("")
        self.info_label.setObjectName("Info")
        
        layout.addLayout(header)
        layout.addWidget(self.bar)
        layout.addWidget(self.info_label)

class KSysWindow(OverlayWindow):
    def __init__(self, ktools):
        super().__init__(ktools, width=220, height=270)
        self.auto_center = False
        self.auto_hide = False
        
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowTransparentForInput)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)

        self.update_screen_positions()

        self.pos_anim.setDuration(400)
        self.opacity_anim.setDuration(400)
        self.pos_anim.setEasingCurve(QEasingCurve.Type.OutQuint)
        self.opacity_anim.setEasingCurve(QEasingCurve.Type.OutQuint)

        self.root = QFrame(self)
        self.root.setObjectName("MainContainer")
        self.root.setFixedSize(220, 270)
        
        self.setCentralWidget(self.root)
        
        layout = QVBoxLayout(self.root)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        try:
            sys_ver = platform.mac_ver()[0]
            try:
                cpu_name = subprocess.check_output(
                    ['/usr/sbin/sysctl', '-n', 'machdep.cpu.brand_string'],
                    stderr=subprocess.DEVNULL
                ).decode('utf-8').strip()
                if cpu_name.startswith("Apple "):
                    cpu_name = cpu_name[6:]
            except:
                arch = platform.machine()
                cpu_name = "Apple Silicon" if arch == 'arm64' else "Intel Core"
                
            info_text = f"macOS {sys_ver}\n{cpu_name}"
        except:
            info_text = "System Monitor"

        self.sys_label = QLabel(info_text)
        self.sys_label.setObjectName("Info")
        self.sys_label.setStyleSheet("font-weight: bold; font-size: 10px;")
        layout.addWidget(self.sys_label)

        self.cpu_stat = StatRow("CPU")
        self.ram_stat = StatRow("RAM")
        self.disk_stat = StatRow("DISK")
        self.net_stat = StatRow("NET")
        
        self.net_stat.bar.setVisible(False)
        
        layout.addWidget(self.cpu_stat)
        layout.addWidget(self.ram_stat)
        layout.addWidget(self.disk_stat)
        layout.addWidget(self.net_stat)


        try:
            self.last_cpu_times = psutil.cpu_times()
        except:
            self.last_cpu_times = None
        
        try:
            self.boot_time = psutil.boot_time()
        except:
            self.boot_time = time.time()
            
        try:
            self.total_ram = psutil.virtual_memory().total
            self.total_ram_gb = self.total_ram / (1024**3)
        except:
            self.total_ram = 1
            self.total_ram_gb = 1
            
        try:
            import shutil
            disk = shutil.disk_usage(os.path.expanduser('~'))
            self.total_disk = disk.total
            self.total_disk_gb = self.total_disk / (1024**3)
        except:
            self.total_disk = 1
            self.total_disk_gb = 1

        try:
            self.last_net_io = psutil.net_io_counters()
            self.last_net_time = time.time()
        except:
            self.last_net_io = None
            self.last_net_time = None
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_stats)
        self.update_theme()

    def showEvent(self, event):
        if not self.timer.isActive():
            self.timer.start(2000)
        self.refresh_stats()
        QTimer.singleShot(50, self._apply_native_flags)
        super().showEvent(event)

    def hideEvent(self, event):
        if self.timer.isActive():
            self.timer.stop()
        super().hideEvent(event)

    def _apply_native_flags(self):
        try:
            view_ptr = int(self.winId())
            ns_view = objc.objc_object(c_void_p=view_ptr)
            window = ns_view.window()
            
            if window:
                window.setLevel_(NSStatusWindowLevel + 1)
                window.setHidesOnDeactivate_(False)
                window.setIgnoresMouseEvents_(True)
                
                behavior = (NSWindowCollectionBehaviorCanJoinAllSpaces | 
                            NSWindowCollectionBehaviorStationary | 
                            NSWindowCollectionBehaviorIgnoresCycle)
                window.setCollectionBehavior_(behavior)
            from main import apply_liquid_glass
            apply_liquid_glass(self, radius=24.0)
        except Exception:
            pass

    def refresh_stats(self):
        if not self.isVisible() or getattr(self, 'is_hiding', False):
            if self.timer.isActive():
                self.timer.stop()
            return

        try:
            cur_cpu = psutil.cpu_times()
            if hasattr(self, 'last_cpu_times') and self.last_cpu_times is not None:
                delta_total = sum(cur_cpu) - sum(self.last_cpu_times)
                delta_idle = (cur_cpu.idle + getattr(cur_cpu, 'iowait', 0.0)) - (self.last_cpu_times.idle + getattr(self.last_cpu_times, 'iowait', 0.0))
                cpu_p = max(0.0, min(100.0, ((delta_total - delta_idle) / delta_total) * 100)) if delta_total > 0 else 0.0
            else:
                cpu_p = 0.0
            self.last_cpu_times = cur_cpu
            self.cpu_stat.val_label.setText(f"{int(cpu_p)}%")
            self.cpu_stat.bar.setValue(int(cpu_p))

            uptime_seconds = time.time() - self.boot_time
            hours = int(uptime_seconds // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            if hours >= 24:
                days = hours // 24
                self.cpu_stat.info_label.setText(f"Uptime: {days}d {hours%24}h {minutes}m")
            else:
                self.cpu_stat.info_label.setText(f"Uptime: {hours}h {minutes}m")
        except:
            pass

        try:
            ram = psutil.virtual_memory()
            used_gb = (ram.total - ram.available) / (1024**3)
            display_percent = ram.percent
            
            self.ram_stat.val_label.setText(f"{display_percent:.1f}%")
            self.ram_stat.bar.setValue(int(display_percent))
            self.ram_stat.info_label.setText(f"Used: {used_gb:.1f}GB / {self.total_ram_gb:.0f}GB")
        except:
            pass

        try:
            import shutil
            disk = shutil.disk_usage(os.path.expanduser('~'))
            percent = (disk.used / disk.total) * 100
            self.disk_stat.val_label.setText(f"{percent:.1f}%")
            self.disk_stat.bar.setValue(int(percent))
            used_disk = disk.used / (1024**3)
            self.disk_stat.info_label.setText(f"Used: {used_disk:.0f}GB / {self.total_disk_gb:.0f}GB")
        except:
            pass

        try:
            if self.last_net_io and self.last_net_time:
                current_net_io = psutil.net_io_counters()
                current_time = time.time()
                time_delta = current_time - self.last_net_time
                
                if time_delta > 0:
                    up_speed = (current_net_io.bytes_sent - self.last_net_io.bytes_sent) / time_delta
                    down_speed = (current_net_io.bytes_recv - self.last_net_io.bytes_recv) / time_delta
                    
                    def fmt(b):
                        if b < 1024: return f"{b:.0f} B/s"
                        elif b < 1024**2: return f"{b/1024:.1f} KB/s"
                        else: return f"{b/(1024**2):.1f} MB/s"

                    self.net_stat.val_label.setText(fmt(down_speed) + " ↓")
                    self.net_stat.info_label.setText(f"Up: {fmt(up_speed)} ↑")
                
                self.last_net_io = current_net_io
                self.last_net_time = current_time
        except:
            pass



    def update_screen_positions(self, screen=None):
        if not screen:
            screen = QApplication.primaryScreen()
        geo = screen.geometry() if screen else self.geometry()
        self.end_pos = QPoint(geo.x() + 20, geo.y() + 50)
        self.start_pos = QPoint(geo.x() - 250, geo.y() + 50)
        if self.isVisible() and self.windowOpacity() > 0.05:
            if hasattr(self, 'anim_group') and self.anim_group.state() == QParallelAnimationGroup.State.Running:
                self.anim_group.stop()
            self.move(self.end_pos)
        else:
            self.move(self.start_pos)

    def on_screen_changed(self, target_geom=None):
        if target_geom:
            self.end_pos = QPoint(target_geom.x() + 20, target_geom.y() + 50)
            self.start_pos = QPoint(target_geom.x() - 250, target_geom.y() + 50)
            if self.isVisible() and self.windowOpacity() > 0.05:
                if hasattr(self, 'anim_group') and self.anim_group.state() == QParallelAnimationGroup.State.Running:
                    self.anim_group.stop()
                self.move(self.end_pos)
            else:
                self.move(self.start_pos)
        else:
            self.update_screen_positions()

    def update_theme(self):
        defaults = NSUserDefaults.standardUserDefaults()
        is_dark = defaults.stringForKey_("AppleInterfaceStyle") == "Dark" if defaults else True
        self.setStyleSheet(get_ksys_theme(is_dark))
        from main import apply_liquid_glass
        apply_liquid_glass(self, radius=24.0, force=True)
        self.root.style().unpolish(self.root)
        self.root.style().polish(self.root)
        self.root.update()

class Plugin:
    def __init__(self, ktools):
        self.layer = "fixed"
        self.ktools = ktools
        self.name = "ksystemdisplay"
        self.config_path = os.path.join(os.path.dirname(__file__), "ksystemdisplay.json")
        self.config = {}
        
        self._load_config()
        self.monitor = KSysWindow(self.ktools)
        
        self.action = QAction("toggle ksystemdisplay (⌥⌘\\)", self.ktools.manager)
        self.action.triggered.connect(self.toggle_ksystemdisplay)
        
        if self.config.get("is_visible", True):
            QTimer.singleShot(1000, self._startup_show)

    def get_actions(self):
        return [self.action]

    def on_screen_changed(self):
        if hasattr(self, 'monitor') and self.monitor:
            self.monitor.on_screen_changed()

    def update_theme(self):
        if hasattr(self, 'monitor') and self.monitor:
            self.monitor.update_theme()

    def unload(self):
        if self.monitor and hasattr(self.monitor, 'timer'):
            self.monitor.timer.stop()

        try:
            self.action.triggered.disconnect()
        except Exception: 
            pass

        if self.monitor:
            if hasattr(self.monitor, 'anim_group'):
                self.monitor.anim_group.stop()
            self.monitor.close()
            self.monitor.deleteLater()
            self.monitor = None

        import gc
        gc.collect()

    def _load_config(self):
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    self.config = json.load(f)
            except Exception:
                self.config = {"is_visible": True}
        else:
            self.config = {"is_visible": True}
            self._save_config()

    def _save_config(self):
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4)
        except Exception as e:
            print(f"ksystemdisplay: failed to save config {e}")

    def _startup_show(self):
        if self.monitor:
            self.ktools.toggle_plugin("ksystemdisplay")

    def toggle_ksystemdisplay(self):
        if self.monitor and self.monitor.anim_group.state() == QParallelAnimationGroup.State.Running:
            return
            
        self.config["is_visible"] = not self.config.get("is_visible", True)
        self._save_config()
        
        if self.monitor:
            self.ktools.toggle_plugin("ksystemdisplay")