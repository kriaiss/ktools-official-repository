import gc
import zipfile
import shutil
import subprocess
import sys
import os
import posixpath
import types
import time
import tempfile
import urllib.request
import urllib.parse
import base64
import hashlib
import importlib.util
import importlib.metadata
import json
import re
import socket
import ipaddress
import ctypes

if __name__ == "__main__":
    sys.modules.setdefault("main", sys.modules[__name__])

core_deps = [
    "pyqt6",
    "pyobjc-core",
    "pyobjc-framework-cocoa",
    "pyobjc-framework-quartz",
    "objgraph"
]

base_deps = [
    "pip",
    "setuptools",
    "wheel"
]

def extract_package_name(spec):
    if not spec:
        return ""
    clean = re.split(r"[; \(\)><=!~\[@]", str(spec))[0].strip()
    return clean

def normalize_name(name):
    clean = extract_package_name(name)
    return re.sub(r"[-_.]+", "-", clean).strip().lower()

def is_system_package(name):
    norm = normalize_name(name)
    if norm in {normalize_name(p) for p in core_deps + base_deps} or norm == "objgraph":
        return True
    if norm.startswith("pyqt6") or norm.startswith("pyobjc") or norm == "objc":
        return True
    return False

def resolve_transitive_dependencies(root_packages):
    all_needed = set()
    queue = [extract_package_name(p) for p in root_packages if extract_package_name(p)]
    while queue:
        item = queue.pop(0)
        norm = normalize_name(item)
        if norm in all_needed:
            continue
        all_needed.add(norm)
        reqs = None
        try:
            reqs = importlib.metadata.requires(norm)
        except Exception:
            pass
        if reqs is None:
            try:
                reqs = importlib.metadata.requires(item)
            except Exception:
                reqs = None
        if reqs:
            for r in reqs:
                if "extra ==" in r:
                    continue
                clean_r = extract_package_name(r)
                if clean_r:
                    norm_dep = normalize_name(clean_r)
                    if norm_dep not in all_needed:
                        queue.append(clean_r)
    return all_needed

def get_installed_distributions():
    pkgs = {}
    try:
        for dist in importlib.metadata.distributions():
            name = dist.metadata.get("Name")
            if name:
                pkgs[normalize_name(name)] = name
    except Exception:
        pass
    return pkgs

def get_missing_core_dependencies():
    installed = get_installed_distributions()
    missing = []
    for dep in core_deps:
        if normalize_name(dep) not in installed:
            missing.append(dep)
    return missing

def get_all_plugin_dependencies(plugins_dir):
    needed = set()
    if not os.path.isdir(plugins_dir):
        return needed
    for name in os.listdir(plugins_dir):
        if name.startswith(".") or name == "__MACOSX":
            continue
        p_dir = os.path.join(plugins_dir, name)
        if not os.path.isdir(p_dir):
            continue
        inf_file = os.path.join(p_dir, "inf.json")
        if os.path.isfile(inf_file):
            try:
                with open(inf_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    deps = data.get("dependencies", [])
                    if isinstance(deps, list):
                        for d in deps:
                            d_clean = str(d).strip()
                            if d_clean and d_clean.lower() != "no deps":
                                needed.add(d_clean)
            except Exception:
                pass
    return needed

def ensure_dependencies_headless():
    if os.environ.get("_KTOOLS_DEP_CHECKED") == "1":
        return
    missing_core = get_missing_core_dependencies()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    plugins_dir = os.path.join(base_dir, "plugins")
    plugin_deps = get_all_plugin_dependencies(plugins_dir)
    installed = get_installed_distributions()
    missing_plugins = [p for p in plugin_deps if normalize_name(p) not in installed]
    all_missing = missing_core + [p for p in missing_plugins if p not in missing_core]
    if not all_missing:
        return
    os.environ["_KTOOLS_DEP_CHECKED"] = "1"
    print(f"ktools: missing dependencies detected: {all_missing}")
    print("ktools: launching headless dependency manager...")
    cmd = [sys.executable, "-m", "pip", "install"] + all_missing
    if sys.prefix == sys.base_prefix:
        cmd.extend(["--user", "--break-system-packages"])
    try:
        res = subprocess.run(cmd)
        if res.returncode != 0:
            print("ktools: failed to install required dependencies")
            return
    except Exception as e:
        print(f"ktools: dependency install error: {e}")
        return
    print("ktools: dependencies installed, starting engine...")
    importlib.invalidate_caches()
    os.execv(sys.executable, [sys.executable] + sys.argv)

ensure_dependencies_headless()
os.environ.pop("_KTOOLS_DEP_CHECKED", None)

try:
    import objgraph
    from PyQt6.QtWidgets import *
    from PyQt6.QtCore import *
    from PyQt6.QtGui import *
    import Quartz
    import objc
    from AppKit import NSEvent, NSKeyDownMask
    from Foundation import NSObject, NSUserDefaults
except ImportError as err:
    print(f"ktools: fatal import error: {err}")
    sys.exit(1)

try:
    KToolsNotificationObserver = objc.lookUpClass("KToolsNotificationObserver")
except objc.nosuchclass_error:
    class KToolsNotificationObserver(NSObject):
        def initWithKtools_(self, ktools_instance):
            self = objc.super(KToolsNotificationObserver, self).init()
            if self is None:
                return None
            self.ktools = ktools_instance
            return self

        def onScreenParametersChanged_(self, notification):
            if hasattr(self, "ktools") and self.ktools:
                self.ktools._schedule_screen_reconfiguration()

        def updateSystemTheme_(self, notification):
            if hasattr(self, "ktools") and self.ktools:
                self.ktools.update_theme()
                QTimer.singleShot(80, self.ktools.update_theme)

class OverlayWindow(QMainWindow):
    def __init__(self, ktools, width=780, height=500):
        super().__init__()
        self.ktools = ktools
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        if width and height:
            self.setFixedSize(width, height)
        self.setWindowOpacity(0.0)
        self.is_hiding = False
        self.auto_hide = True
        self.auto_center = True

        self.anim_group = QParallelAnimationGroup(self)
        self.pos_anim = QPropertyAnimation(self, b"pos", self)
        self.opacity_anim = QPropertyAnimation(self, b"windowOpacity", self)
        
        for a in [self.pos_anim, self.opacity_anim]:
            a.setDuration(180)
            a.setEasingCurve(QEasingCurve.Type.OutCubic)
            self.anim_group.addAnimation(a)
            
        self.anim_group.finished.connect(self._on_anim_finished)

    def event(self, event):
        if event.type() == QEvent.Type.WindowDeactivate and self.auto_hide:
            if getattr(self.ktools, 'is_switching', False):
                return super().event(event)
            if self.is_hiding:
                return super().event(event)
            if self.windowOpacity() < 0.95:
                QTimer.singleShot(100, lambda: self.hide_anim() if (self.isVisible() and not self.isActiveWindow() and self.auto_hide) else None)
                return super().event(event)
            if QApplication.activePopupWidget() is not None:
                QTimer.singleShot(150, lambda: self.hide_anim() if (self.isVisible() and not self.isActiveWindow() and self.auto_hide and QApplication.activePopupWidget() is None) else None)
                return super().event(event)
            if self.isVisible():
                self.hide_anim()
        return super().event(event)

    def show_anim(self):
        if self.anim_group.state() == QParallelAnimationGroup.State.Running:
            self.anim_group.stop()
        self.is_hiding = False
        self.show()
        
        start_p = getattr(self, 'start_pos', self.pos())
        end_p = getattr(self, 'end_pos', self.pos())
        self.pos_anim.setStartValue(start_p)
        self.pos_anim.setEndValue(end_p)

        self.opacity_anim.setStartValue(self.windowOpacity() if self.isVisible() and self.windowOpacity() > 0.0 else 0.0)
        self.opacity_anim.setEndValue(1.0)
        self.anim_group.start()
        
        QTimer.singleShot(300, self._reset_switching)

    def _reset_switching(self):
        if hasattr(self.ktools, 'is_switching'):
            self.ktools.is_switching = False

    def hide_anim(self):
        if self.is_hiding: return
        if self.anim_group.state() == QParallelAnimationGroup.State.Running:
            self.anim_group.stop()
        self.is_hiding = True
        
        start_p = getattr(self, 'start_pos', self.pos())
        self.pos_anim.setStartValue(self.pos())
        self.pos_anim.setEndValue(start_p)
            
        self.opacity_anim.setStartValue(self.windowOpacity())
        self.opacity_anim.setEndValue(0.0)
        self.anim_group.start()

    def _on_anim_finished(self):
        if self.is_hiding:
            self.hide()
            self.setWindowOpacity(0.0)
            self.is_hiding = False
            if hasattr(self.ktools, 'restore_focus'):
                self.ktools.restore_focus()
        else:
            if hasattr(self, 'focus_current'):
                self.focus_current()


class FixedWindow(QWidget):
    def __init__(self, ktools):
        super().__init__()
        self.ktools = ktools
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.Tool |
            Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)


class WallpaperWindow(QWidget):
    def __init__(self, ktools):
        super().__init__()
        self.ktools = ktools
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.Tool |
            Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        
    def showEvent(self, event):
        QTimer.singleShot(50, self._apply_desktop_layer)
        super().showEvent(event)

    def _apply_desktop_layer(self):
        try:
            view_ptr = int(self.winId())
            import objc
            ns_view = objc.objc_object(c_void_p=view_ptr)
            window = ns_view.window()
            if window:
                from AppKit import (NSWindowCollectionBehaviorCanJoinAllSpaces, 
                                    NSWindowCollectionBehaviorStationary, 
                                    NSWindowCollectionBehaviorIgnoresCycle)
                behavior = (NSWindowCollectionBehaviorCanJoinAllSpaces | 
                            NSWindowCollectionBehaviorStationary | 
                            NSWindowCollectionBehaviorIgnoresCycle)
                window.setCollectionBehavior_(behavior)
                window.setLevel_(-2147483623)
                window.setHidesOnDeactivate_(False)
                window.setCanHide_(False)
        except Exception as e:
            print(f"ktools API: failed to apply wallpaper layer: {e}")

try:
    from AppKit import (
        NSBundle, NSApplication, NSWorkspace, NSStatusWindowLevel,
        NSWindowCollectionBehaviorCanJoinAllSpaces,
        NSWindowCollectionBehaviorStationary,
        NSWindowCollectionBehaviorIgnoresCycle,
        NSWindowCollectionBehaviorFullScreenAuxiliary,
        NSApplicationActivateIgnoringOtherApps,
        NSApplicationActivateAllWindows,
        NSUserDefaults
    )
    import objc
    
    info = NSBundle.mainBundle().infoDictionary()
    if info:
        info['LSUIElement'] = '1'
except Exception as e:
    print(f"ktools: Failed to load AppKit bindings - {e}")


def apply_liquid_glass(window, radius=24.0, force=False):
    if not force and not isinstance(window, QMenu) and getattr(window, '_glass_applied', False):
        return
    try:
        view_ptr = int(window.winId())
        import objc
        ns_view = objc.objc_object(c_void_p=view_ptr)
        ns_win = ns_view.window()
        if ns_win:
            import AppKit
            from AppKit import (
                NSViewWidthSizable,
                NSViewHeightSizable,
                NSWindowBelow,
                NSColor,
                NSUserDefaults,
                NSAppearance,
                NSAppearanceNameVibrantDark,
                NSAppearanceNameVibrantLight,
                NSVisualEffectView,
                NSVisualEffectBlendingModeBehindWindow,
                NSVisualEffectStateActive
            )
            
            defaults = NSUserDefaults.standardUserDefaults()
            is_dark = defaults.stringForKey_("AppleInterfaceStyle") == "Dark" if defaults else True
            target_app = NSAppearance.appearanceNamed_(NSAppearanceNameVibrantDark if is_dark else NSAppearanceNameVibrantLight)
            ns_win.setAppearance_(target_app)
            ns_win.setOpaque_(False)
            ns_win.setBackgroundColor_(NSColor.clearColor())
            
            qt_view = ns_win.contentView()
            theme_frame = qt_view.superview()
            if theme_frame:
                theme_frame.setWantsLayer_(True)
            if qt_view:
                qt_view.setWantsLayer_(True)
            
            target_rect = theme_frame.bounds() if theme_frame else qt_view.bounds()
            check_views = list(qt_view.subviews())
            if theme_frame:
                check_views = list(theme_frame.subviews()) + check_views
            for subview in check_views:
                cname = subview.className()
                if cname in ('NSGlassEffectView', 'NSVisualEffectView'):
                    subview.setAppearance_(target_app)
                    if hasattr(subview, 'setFrame_'):
                        subview.setFrame_(target_rect)
                    if hasattr(subview, 'setCornerRadius_'):
                        subview.setCornerRadius_(radius)
                    if subview.layer():
                        subview.layer().setCornerRadius_(radius)
                        subview.layer().setMasksToBounds_(True)
                    window._glass_applied = True
                    return
                    
            effect_view = None
            if hasattr(AppKit, 'NSGlassEffectView'):
                try:
                    effect_view = AppKit.NSGlassEffectView.alloc().initWithFrame_(target_rect)
                    effect_view.setAutoresizingMask_(NSViewWidthSizable | NSViewHeightSizable)
                    effect_view.setAppearance_(target_app)
                    style = getattr(AppKit, "NSGlassEffectViewStyleRegular", 0)
                    if hasattr(effect_view, "setStyle_"):
                        effect_view.setStyle_(style)
                    if hasattr(effect_view, "setCornerRadius_"):
                        effect_view.setCornerRadius_(radius)
                    effect_view.setWantsLayer_(True)
                    if effect_view.layer():
                        effect_view.layer().setCornerRadius_(radius)
                        effect_view.layer().setMasksToBounds_(True)
                except Exception:
                    effect_view = None

            if effect_view is None:
                effect_view = NSVisualEffectView.alloc().initWithFrame_(target_rect)
                effect_view.setAutoresizingMask_(NSViewWidthSizable | NSViewHeightSizable)
                effect_view.setAppearance_(target_app)
                effect_view.setBlendingMode_(NSVisualEffectBlendingModeBehindWindow)
                effect_view.setMaterial_(13)
                effect_view.setState_(NSVisualEffectStateActive)
                effect_view.setWantsLayer_(True)
                if effect_view.layer():
                    effect_view.layer().setCornerRadius_(radius)
                    effect_view.layer().setMasksToBounds_(True)
            
            if theme_frame:
                theme_frame.addSubview_positioned_relativeTo_(effect_view, NSWindowBelow, qt_view)
            else:
                rel = qt_view.subviews()[0] if qt_view.subviews() else None
                qt_view.addSubview_positioned_relativeTo_(effect_view, NSWindowBelow, rel)
            window._glass_applied = True
    except Exception as e:
        print(f"ktools: failed to apply liquid glass: {e}")

def get_theme(is_dark):
    bg = "transparent"
    text = "#ffffff" if is_dark else "#000000"
    nav_text = "rgba(255, 255, 255, 120)" if is_dark else "rgba(0, 0, 0, 120)"
    border = "rgba(255, 255, 255, 30)" if is_dark else "rgba(0, 0, 0, 30)"
    item_hover = "rgba(255, 255, 255, 20)" if is_dark else "rgba(0, 0, 0, 10)"
    scroll_handle = "rgba(255, 255, 255, 40)" if is_dark else "rgba(0, 0, 0, 40)"
    scroll_hover = "rgba(255, 255, 255, 70)" if is_dark else "rgba(0, 0, 0, 70)"
    menu_bg = "transparent"
    
    return f"""
    QMenu {{
        background-color: {menu_bg};
        color: {text};
        border: 1px solid {border};
        border-radius: 8px;
        padding: 5px;
        font-family: 'Menlo';
    }}
    QMenu::item {{
        padding: 6px 25px 6px 20px;
        background-color: transparent;
        color: {text};
        border-radius: 4px;
        font-family: 'Menlo';
    }}
    QMenu::item:selected {{
        background-color: {item_hover};
    }}
    QMenu::item:disabled {{
        color: {nav_text};
    }}
    QMenu::separator {{
        height: 1px;
        background: {border};
        margin: 4px 10px;
    }}
    QPushButton#PluginTabBtn {{
        color: {nav_text}; background: transparent; border: none;
        font-family: 'Menlo'; font-size: 14px; padding: 8px 12px;
        border-bottom: 2px solid transparent; margin: 0px 2px;
    }}
    QPushButton#PluginTabBtn:checked {{ color: {text}; border-bottom: 2px solid {text}; }}
    
    QLabel#PluginTitle {{ 
        font-size: 42px; font-weight: bold; color: {text}; 
        font-family: 'Menlo'; 
    }}
    
    QPushButton#BottomNavBtn {{
        color: {nav_text}; background: transparent; border: none;
        font-family: 'Menlo'; font-size: 13px; padding: 5px 10px;
        border-bottom: 2px solid transparent;
    }}
    QPushButton#BottomNavBtn:checked {{ 
        color: {text}; border-bottom: 2px solid {text}; 
    }}
    QScrollBar:vertical {{
        border: none; background: transparent; width: 8px; margin: 0px 2px 0px 2px;
    }}
    QScrollBar::handle:vertical {{
        background: {scroll_handle}; border-radius: 4px; min-height: 40px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: {scroll_hover};
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px; background: none;
    }}
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
        background: none;
    }}
    QScrollBar:horizontal {{
        height: 0px;
    }}
    """

class KToast(QWidget):
    def __init__(self, text, manager_list):
        super().__init__()
        self.manager_list = manager_list
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.WindowStaysOnTopHint | 
            Qt.WindowType.Tool |
            Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        # kill toast native window resources on close
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

        self.setFixedSize(400, 40)
        
        self.root = QFrame(self)
        self.root.setObjectName("MainContainer")
        self.root.setFixedSize(400, 40)
        
        layout = QHBoxLayout(self.root)
        layout.setContentsMargins(20, 0, 20, 0)
        self.label = QLabel(text.lower())
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.label)

        self.anim_group = QParallelAnimationGroup(self)
        self.pos_anim = QPropertyAnimation(self, b"pos")
        self.opacity_anim = QPropertyAnimation(self, b"windowOpacity")
        
        for a in [self.pos_anim, self.opacity_anim]:
            a.setDuration(300)
            a.setEasingCurve(QEasingCurve.Type.OutQuint)
            self.anim_group.addAnimation(a)
            
        self.anim_group.finished.connect(self._on_anim_finished)
        self.is_hiding = False
        self.update_theme()

    def _on_anim_finished(self):
        if getattr(self, "is_hiding", False):
            self.close()

    def update_position(self, index):
        if getattr(self, "is_hiding", False):
            return
        if self.anim_group.state() == QParallelAnimationGroup.State.Running:
            self.anim_group.stop()
        primary = QApplication.primaryScreen()
        if primary:
            screen = primary.availableGeometry()
            target_y = screen.y() + screen.height() - 80 - (index * 55)
            target_x = screen.x() + (screen.width() - self.width()) // 2
        else:
            target_y = 1080 - 80 - (index * 55)
            target_x = (1920 - self.width()) // 2
        
        self.pos_anim.setStartValue(self.pos())
        self.pos_anim.setEndValue(QPoint(target_x, target_y))
        self.opacity_anim.setStartValue(self.windowOpacity())
        self.opacity_anim.setEndValue(1.0)
        self.anim_group.start()

    def hide_anim(self):
        if self.is_hiding: return
        self.is_hiding = True
        if self.anim_group.state() == QParallelAnimationGroup.State.Running:
            self.anim_group.stop()
        self.pos_anim.setStartValue(self.pos())
        self.pos_anim.setEndValue(self.pos())
        self.opacity_anim.setStartValue(self.windowOpacity())
        self.opacity_anim.setEndValue(0.0)
        self.anim_group.start()

    def closeEvent(self, event):
        try:
            if self in self.manager_list:
                self.manager_list.remove(self)
        except ValueError:
            pass
        self.deleteLater()
        super().closeEvent(event)

    def update_theme(self):
        defaults = NSUserDefaults.standardUserDefaults()
        is_dark = defaults.stringForKey_("AppleInterfaceStyle") == "Dark" if defaults else True
        
        bg = "transparent"
        text = "#ffffff" if is_dark else "#000000"
        border = "rgba(255, 255, 255, 25)" if is_dark else "rgba(0, 0, 0, 25)"
        
        self.setStyleSheet(f"""
            QFrame#MainContainer {{
                background: {bg};
                border-radius: 20px;
                border: 1px solid {border};
            }}
            QLabel {{ color: {text}; font-family: 'Menlo'; font-size: 13px; }}
        """)
        apply_liquid_glass(self, radius=20.0, force=True)

    def _apply_native_flags(self):
        try:
            view_ptr = int(self.winId())
            ns_view = objc.objc_object(c_void_p=view_ptr)
            window = ns_view.window()
            if window:
                window.setLevel_(NSStatusWindowLevel + 1)
                window.setHidesOnDeactivate_(False)
                behavior = (NSWindowCollectionBehaviorCanJoinAllSpaces | 
                            NSWindowCollectionBehaviorStationary | 
                            NSWindowCollectionBehaviorIgnoresCycle)
                window.setCollectionBehavior_(behavior)
                
            apply_liquid_glass(self, radius=20.0)
        except Exception: 
            pass


class KToolsMenuFilter(QObject):
    def eventFilter(self, obj, event):
        if isinstance(obj, QMenu):
            if event.type() == QEvent.Type.Polish:
                if not getattr(obj, "_ktools_flags_set", False):
                    obj._ktools_flags_set = True
                    obj.setWindowFlags(obj.windowFlags() | Qt.WindowType.FramelessWindowHint | Qt.WindowType.NoDropShadowWindowHint)
                    obj.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
                    defaults = NSUserDefaults.standardUserDefaults()
                    is_dark = defaults.stringForKey_("AppleInterfaceStyle") == "Dark" if defaults else True
                    obj.setStyleSheet(get_theme(is_dark))
            elif event.type() == QEvent.Type.Show:
                apply_liquid_glass(obj, radius=8.0, force=True)
                QTimer.singleShot(0, lambda: apply_liquid_glass(obj, radius=8.0, force=True))
                for act in obj.actions():
                    t = act.text()
                    if "&" in t:
                        t = t.replace("&", "")
                    clean = t.strip().lower()
                    if clean and act.text() != clean:
                        if "(" in t and ")" in t:
                            base, rest = t.split("(", 1)
                            clean = f"{base.strip().lower()} ({rest}"
                        act.setText(clean)
            elif event.type() in (QEvent.Type.Hide, QEvent.Type.Close):
                obj._glass_applied = False
        return super().eventFilter(obj, event)


class LogEmitter(QObject):
    sig_log = pyqtSignal(str)


class LogStream:
    def __init__(self, emitter, original_stream):
        self.emitter = emitter
        self.original_stream = original_stream
        self._buffer = ""

    def write(self, text):
        self.original_stream.write(text)
        self._buffer += str(text)
        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            line = line.strip()
            if line:
                self.emitter.sig_log.emit(line)

    def flush(self):
        self.original_stream.flush()
        if self._buffer.strip():
            self.emitter.sig_log.emit(self._buffer.strip())
            self._buffer = ""

    def isatty(self):
        return getattr(self.original_stream, "isatty", lambda: False)()

    def fileno(self):
        return getattr(self.original_stream, "fileno", lambda: 1)()

    @property
    def encoding(self):
        return getattr(self.original_stream, "encoding", "utf-8")

    @property
    def errors(self):
        return getattr(self.original_stream, "errors", "replace")

    @property
    def buffer(self):
        return getattr(self.original_stream, "buffer", self.original_stream)

    def writable(self):
        return True

    def readable(self):
        return False


class InstallWorker(QThread):
    package_started = pyqtSignal(str, int, int)
    package_finished = pyqtSignal(str, bool)
    finished = pyqtSignal(list, list)

    def __init__(self, dep_mgr, packages):
        super().__init__()
        self.dep_mgr = dep_mgr
        self.packages = packages

    def run(self):
        installed_pkgs = []
        failed_pkgs = []
        total = len(self.packages)
        for idx, pkg in enumerate(self.packages):
            self.package_started.emit(pkg, idx + 1, total)
            print(f"dependency manager: installing ({idx + 1}/{total}): {pkg}")
            cmd = self.dep_mgr.pip_cmd + ["install", pkg]
            if sys.prefix == sys.base_prefix:
                cmd.extend(["--user", "--break-system-packages"])
            res = subprocess.run(cmd, capture_output=True, text=True)
            if res.returncode == 0:
                installed_pkgs.append(pkg)
                self.package_finished.emit(pkg, True)
            else:
                failed_pkgs.append(pkg)
                self.package_finished.emit(pkg, False)
                print(f"dependency manager: failed to install {pkg}: {res.stderr}")
        self.finished.emit(installed_pkgs, failed_pkgs)


KEYCODE_TO_KEY = {
    0: "a", 1: "s", 2: "d", 3: "f", 4: "h", 5: "g", 6: "z", 7: "x",
    8: "c", 9: "v", 10: "section", 11: "b", 12: "q", 13: "w", 14: "e", 15: "r",
    16: "y", 17: "t", 18: "1", 19: "2", 20: "3", 21: "4", 22: "6",
    23: "5", 24: "=", 25: "9", 26: "7", 27: "-", 28: "8", 29: "0",
    30: "]", 31: "o", 32: "u", 33: "[", 34: "i", 35: "p", 36: "return",
    37: "l", 38: "j", 39: "'", 40: "k", 41: ";", 42: "\\", 43: ",",
    44: "/", 45: "n", 46: "m", 47: ".", 48: "tab", 49: "space",
    50: "`", 51: "backspace", 53: "escape",
    65: ".", 67: "*", 69: "+", 75: "/", 76: "return", 78: "-", 81: "=",
    82: "0", 83: "1", 84: "2", 85: "3", 86: "4", 87: "5", 88: "6", 89: "7", 91: "8", 92: "9",
    96: "f5", 97: "f6", 98: "f7", 99: "f3", 100: "f8", 101: "f9",
    103: "f11", 109: "f10", 111: "f12", 118: "f4", 120: "f2", 122: "f1",
    115: "home", 116: "pageup", 117: "delete", 119: "end", 121: "pagedown",
    123: "left", 124: "right", 125: "down", 126: "up",
}

KEY_ALIASES = {
    "enter": "return",
    "esc": "escape",
    "spc": "space",
    "del": "delete",
    "bs": "backspace",
    "tilde": "`",
    "grave": "`",
    "~": "`",
    "plus": "=",
    "+": "=",
    "equal": "=",
    "equals": "=",
    "minus": "-",
    "backslash": "\\",
    "slash": "/",
    "comma": ",",
    "period": ".",
    "dot": ".",
    "semicolon": ";",
    "quote": "'",
}

KEY_TO_KEYCODE = {v: k for k, v in KEYCODE_TO_KEY.items()}
KEY_TO_KEYCODE.update({
    "enter": 36,
    "esc": 53,
    "spc": 49,
    "bs": 51,
    "backspace": 51,
    "delete": 117,
    "del": 117,
    "tilde": 50,
    "grave": 50,
    "~": 50,
    "backslash": 42,
    "slash": 44,
    "minus": 27,
    "equal": 24,
    "equals": 24,
    "plus": 24,
    "+": 24,
    "comma": 43,
    "period": 47,
    "dot": 47,
    "semicolon": 41,
    "quote": 39,
    "bracketleft": 33,
    "bracketright": 30,
})

MOD_MASKS = {
    "cmd": Quartz.kCGEventFlagMaskCommand,
    "opt": Quartz.kCGEventFlagMaskAlternate,
    "ctrl": Quartz.kCGEventFlagMaskControl,
    "shift": Quartz.kCGEventFlagMaskShift,
}

ALL_MODS_MASK = (
    Quartz.kCGEventFlagMaskCommand |
    Quartz.kCGEventFlagMaskAlternate |
    Quartz.kCGEventFlagMaskControl |
    Quartz.kCGEventFlagMaskShift
)

def parse_hotkey(hotkey_str):
    if not hotkey_str or not str(hotkey_str).strip():
        return set(), None, ""
    s = str(hotkey_str).strip().lower()
    for sym, word in [('⌘', ' cmd '), ('⌥', ' opt '), ('⌃', ' ctrl '), ('⇧', ' shift ')]:
        s = s.replace(sym, word)
    raw_parts = [p.strip() for p in s.replace('+', ' ').split() if p.strip()]
    mods = set()
    key = None
    for p in raw_parts:
        if p in ('cmd', 'command', 'meta'):
            mods.add('cmd')
        elif p in ('opt', 'option', 'alt'):
            mods.add('opt')
        elif p in ('ctrl', 'control'):
            mods.add('ctrl')
        elif p in ('shift',):
            mods.add('shift')
        else:
            key = p
    if key:
        key = KEY_ALIASES.get(key, key)
    sorted_mods = [m for m in ('ctrl', 'opt', 'shift', 'cmd') if m in mods]
    norm = '+'.join(sorted_mods + ([key] if key else []))
    return mods, key, norm

def normalize_hotkey(hotkey_str):
    _, _, norm = parse_hotkey(hotkey_str)
    return norm

def format_display_hotkey(hotkey_str):
    mods, key, norm = parse_hotkey(hotkey_str)
    if not key and not mods:
        return "none"
    disp = ""
    if "ctrl" in mods: disp += "⌃"
    if "opt" in mods: disp += "⌥"
    if "shift" in mods: disp += "⇧"
    if "cmd" in mods: disp += "⌘"
    key_disp_map = {
        "space": "Space", "return": "Return", "escape": "Esc", "tab": "Tab",
        "backspace": "⌫", "delete": "⌦", "up": "↑", "down": "↓", "left": "←", "right": "→"
    }
    if key in key_disp_map:
        key_disp = key_disp_map[key]
    elif key:
        key_disp = key.upper()
    else:
        key_disp = ""
    return disp + key_disp

def hotkey_to_code_and_mask(hotkey_str):
    mods, key, norm = parse_hotkey(hotkey_str)
    if not key:
        return None, 0
    kc = KEY_TO_KEYCODE.get(key)
    if kc is None:
        return None, 0
    mask = 0
    for m in mods:
        mask |= MOD_MASKS.get(m, 0)
    return kc, mask

def code_and_mask_to_hotkey(keycode, mask):
    key = KEYCODE_TO_KEY.get(keycode)
    if not key:
        return ""
    key = KEY_ALIASES.get(key, key)
    mods = []
    if mask & Quartz.kCGEventFlagMaskControl: mods.append("ctrl")
    if mask & Quartz.kCGEventFlagMaskAlternate: mods.append("opt")
    if mask & Quartz.kCGEventFlagMaskShift: mods.append("shift")
    if mask & Quartz.kCGEventFlagMaskCommand: mods.append("cmd")
    return "+".join(mods + [key])

class HotkeyManager(QObject):
    sig_trigger = pyqtSignal(object)

    def __init__(self, ktools):
        super().__init__()
        self.ktools = ktools
        base_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_path = os.path.join(base_dir, "hotkeys.json")
        self.items = {}
        self.user_overrides = {}
        self.active_bindings = {}
        self.conflicts = {}
        self.is_recording = False
        self.tap = None
        self.runLoopSource = None
        self.global_monitor = None
        self.local_monitor = None
        self._tap_callback_ref = None
        self._tap_callback_fn = None
        self._cg_lib = None
        self._cf_lib = None
        self._common_modes = None
        self._last_trigger_time = {}
        self.sig_trigger.connect(self._execute_callback)

    def _get_native_tap_libs(self):
        if self._cg_lib and self._cf_lib and self._common_modes:
            return self._cg_lib, self._cf_lib, self._common_modes
        try:
            cg = ctypes.CDLL("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
            cf = ctypes.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")

            cg.CGEventTapCreate.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_void_p]
            cg.CGEventTapCreate.restype = ctypes.c_void_p
            cg.CGEventTapEnable.argtypes = [ctypes.c_void_p, ctypes.c_bool]
            cg.CGEventTapEnable.restype = None
            cg.CGEventGetFlags.argtypes = [ctypes.c_void_p]
            cg.CGEventGetFlags.restype = ctypes.c_uint64
            cg.CGEventGetIntegerValueField.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            cg.CGEventGetIntegerValueField.restype = ctypes.c_int64

            cf.CFMachPortCreateRunLoopSource.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long]
            cf.CFMachPortCreateRunLoopSource.restype = ctypes.c_void_p
            cf.CFMachPortInvalidate.argtypes = [ctypes.c_void_p]
            cf.CFMachPortInvalidate.restype = None
            cf.CFRunLoopGetMain.argtypes = []
            cf.CFRunLoopGetMain.restype = ctypes.c_void_p
            cf.CFRunLoopAddSource.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
            cf.CFRunLoopAddSource.restype = None
            cf.CFRunLoopRemoveSource.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
            cf.CFRunLoopRemoveSource.restype = None
            cf.CFRelease.argtypes = [ctypes.c_void_p]
            cf.CFRelease.restype = None

            common_modes = ctypes.c_void_p.in_dll(cf, "kCFRunLoopCommonModes").value
            if not common_modes:
                return None, None, None

            self._cg_lib = cg
            self._cf_lib = cf
            self._common_modes = common_modes
            return cg, cf, common_modes
        except Exception:
            return None, None, None

    def _execute_callback(self, cb):
        try:
            cb()
        except Exception as e:
            print(f"ktools: hotkey callback execution error: {e}")

    def load(self):
        self._load_user_overrides()
        self._discover_plugin_hotkeys()
        self._rebuild_bindings()
        self._check_and_notify_conflicts()
        self._setup_event_tap()

    def reload(self):
        self._load_user_overrides()
        self._discover_plugin_hotkeys()
        self._rebuild_bindings()
        self._check_and_notify_conflicts()
        self._setup_event_tap()

    def _load_user_overrides(self):
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.user_overrides = data
                    else:
                        self.user_overrides = {}
            except Exception as e:
                print(f"ktools: failed to load hotkeys.json: {e}")
                self.user_overrides = {}
        else:
            self.user_overrides = {}

    def _save_user_overrides(self):
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.user_overrides, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"ktools: failed to save hotkeys.json: {e}")

    def _discover_plugin_hotkeys(self):
        base_path = os.path.dirname(os.path.abspath(__file__))
        plugins_dir = os.path.join(base_path, "plugins")
        if not os.path.exists(plugins_dir):
            return

        new_items = {}
        for plugin_name in os.listdir(plugins_dir):
            if plugin_name.startswith(".") or plugin_name == "__MACOSX":
                continue
            p_dir = os.path.join(plugins_dir, plugin_name)
            if not os.path.isdir(p_dir):
                continue
            inf_path = os.path.join(p_dir, "inf.json")
            if not os.path.exists(inf_path):
                continue

            try:
                with open(inf_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception:
                continue

            raw_hotkeys = meta.get("hotkeys", {})
            if not raw_hotkeys and "keybinds" in meta:
                raw_hotkeys = meta.get("keybinds", {})

            for action_id, info in raw_hotkeys.items():
                if not isinstance(info, dict):
                    continue

                full_key = f"{plugin_name}.{action_id}"
                label = info.get("label", action_id)
                callback_name = info.get("callback", action_id)

                default_hk = ""
                if "hotkey" in info:
                    default_hk = normalize_hotkey(info["hotkey"])
                elif "keycode" in info:
                    kc = info.get("keycode")
                    raw_mods = info.get("modifiers", 0)
                    default_hk = code_and_mask_to_hotkey(kc, raw_mods)

                current_hk = self.user_overrides.get(full_key, default_hk)

                new_items[full_key] = {
                    "plugin_name": plugin_name,
                    "action_id": action_id,
                    "key": full_key,
                    "label": label,
                    "callback": callback_name,
                    "default_hotkey": default_hk,
                    "current_hotkey": current_hk,
                }

            if not raw_hotkeys and hasattr(self.ktools, "plugins") and plugin_name in self.ktools.plugins:
                p_inst = self.ktools.plugins[plugin_name]
                if hasattr(p_inst, "toggle"):
                    toggle_key = f"{plugin_name}.toggle_{plugin_name}"
                    if toggle_key not in new_items:
                        def_hk = ""
                        curr_hk = self.user_overrides.get(toggle_key, def_hk)
                        new_items[toggle_key] = {
                            "plugin_name": plugin_name,
                            "action_id": f"toggle_{plugin_name}",
                            "key": toggle_key,
                            "label": f"toggle {plugin_name}",
                            "callback": f"toggle_{plugin_name}",
                            "default_hotkey": def_hk,
                            "current_hotkey": curr_hk,
                        }

        mgr_key = "kmanager.toggle_manager"
        mgr_current = self.user_overrides.get(mgr_key, "")
        new_items[mgr_key] = {
            "plugin_name": "kmanager",
            "action_id": "toggle_manager",
            "key": mgr_key,
            "label": "open plugin manager",
            "callback": "toggle_manager",
            "default_hotkey": "",
            "current_hotkey": mgr_current,
        }

        self.items = new_items

    def _rebuild_bindings(self):
        self.active_bindings = {}
        hotkey_groups = {}

        for full_key, item in self.items.items():
            current_hk = item["current_hotkey"]
            if current_hk:
                hotkey_groups.setdefault(current_hk, []).append(item)
                kc, mask = hotkey_to_code_and_mask(current_hk)
                if kc is not None:
                    self.active_bindings.setdefault((kc, mask), []).append(item)
                    if kc == 36:
                        self.active_bindings.setdefault((76, mask), []).append(item)
                    elif kc == 76:
                        self.active_bindings.setdefault((36, mask), []).append(item)

        new_conflicts = {}
        for hk, group in hotkey_groups.items():
            if len(group) > 1:
                new_conflicts[hk] = group
        self.conflicts = new_conflicts

    def _check_and_notify_conflicts(self):
        if not self.conflicts:
            return
        details = []
        for hk, items in self.conflicts.items():
            names = ", ".join(f"{it['plugin_name']}: {it['label']}" for it in items)
            details.append(f"{format_display_hotkey(hk)} ({names})")
        msg = f"hotkey conflict: {'; '.join(details)}"
        if hasattr(self.ktools, "notify"):
            self.ktools.notify(msg)
        print(f"ktools: {msg}")

    def set_hotkey(self, plugin_name, action_id, new_hotkey_str):
        full_key = f"{plugin_name}.{action_id}"
        norm = normalize_hotkey(new_hotkey_str)
        if full_key in self.items:
            self.items[full_key]["current_hotkey"] = norm
        self.user_overrides[full_key] = norm
        self._save_user_overrides()
        self._rebuild_bindings()
        self._check_and_notify_conflicts()
        return self.conflicts

    def reset_hotkey(self, plugin_name, action_id):
        full_key = f"{plugin_name}.{action_id}"
        if full_key in self.user_overrides:
            del self.user_overrides[full_key]
            self._save_user_overrides()
        if full_key in self.items:
            self.items[full_key]["current_hotkey"] = self.items[full_key]["default_hotkey"]
        self._rebuild_bindings()
        self._check_and_notify_conflicts()

    def clear_hotkey(self, plugin_name, action_id):
        full_key = f"{plugin_name}.{action_id}"
        self.user_overrides[full_key] = ""
        self._save_user_overrides()
        if full_key in self.items:
            self.items[full_key]["current_hotkey"] = ""
        self._rebuild_bindings()
        self._check_and_notify_conflicts()

    def get_items(self):
        return list(self.items.values())

    def get_conflicts(self):
        return self.conflicts

    def is_item_conflicting(self, item):
        hk = item.get("current_hotkey", "")
        if not hk:
            return False
        return hk in self.conflicts

    def get_item_conflicts(self, item):
        hk = item.get("current_hotkey", "")
        if not hk or hk not in self.conflicts:
            return []
        return [other for other in self.conflicts[hk] if other["key"] != item["key"]]

    def key_event_to_hotkey(self, event):
        mods = set()
        native_mods = event.nativeModifiers()
        if native_mods:
            if native_mods & Quartz.kCGEventFlagMaskCommand:
                mods.add("cmd")
            if native_mods & Quartz.kCGEventFlagMaskAlternate:
                mods.add("opt")
            if native_mods & Quartz.kCGEventFlagMaskControl:
                mods.add("ctrl")
            if native_mods & Quartz.kCGEventFlagMaskShift:
                mods.add("shift")

        qmods = event.modifiers()
        if qmods & Qt.KeyboardModifier.ControlModifier:
            mods.add("cmd")
        if qmods & Qt.KeyboardModifier.AltModifier:
            mods.add("opt")
        if qmods & Qt.KeyboardModifier.MetaModifier:
            mods.add("ctrl")
        if qmods & Qt.KeyboardModifier.ShiftModifier:
            mods.add("shift")

        if event.key() in (Qt.Key.Key_Control, Qt.Key.Key_Shift, Qt.Key.Key_Alt, Qt.Key.Key_Meta):
            return ""

        native_kc = event.nativeVirtualKey()
        key_name = None
        if native_kc == 0:
            if event.key() == Qt.Key.Key_A or event.text().lower() == "a":
                key_name = "a"
        else:
            key_name = KEYCODE_TO_KEY.get(native_kc)

        if not key_name:
            qt_key = event.key()
            qt_map = {
                Qt.Key.Key_Space: "space",
                Qt.Key.Key_Return: "return",
                Qt.Key.Key_Enter: "return",
                Qt.Key.Key_Escape: "escape",
                Qt.Key.Key_Tab: "tab",
                Qt.Key.Key_Backspace: "backspace",
                Qt.Key.Key_Delete: "delete",
                Qt.Key.Key_Left: "left",
                Qt.Key.Key_Right: "right",
                Qt.Key.Key_Up: "up",
                Qt.Key.Key_Down: "down",
                Qt.Key.Key_Home: "home",
                Qt.Key.Key_End: "end",
                Qt.Key.Key_PageUp: "pageup",
                Qt.Key.Key_PageDown: "pagedown",
            }
            if qt_key in qt_map:
                key_name = qt_map[qt_key]
            elif Qt.Key.Key_F1 <= qt_key <= Qt.Key.Key_F12:
                f_idx = qt_key - Qt.Key.Key_F1 + 1
                key_name = f"f{f_idx}"
            elif Qt.Key.Key_A <= qt_key <= Qt.Key.Key_Z:
                key_name = chr(qt_key).lower()
            elif Qt.Key.Key_0 <= qt_key <= Qt.Key.Key_9:
                key_name = chr(qt_key)
            elif event.text().strip():
                key_name = event.text().strip().lower()

        if not key_name:
            return ""

        key_name = KEY_ALIASES.get(key_name, key_name)

        if not (mods & {"cmd", "opt", "ctrl"}) and not (key_name.startswith("f") and key_name[1:].isdigit()):
            return ""

        sorted_mods = [m for m in ("ctrl", "opt", "shift", "cmd") if m in mods]
        return "+".join(sorted_mods + [key_name])

    def trigger_action(self, item):
        key = item["key"]
        now = time.time()
        last = self._last_trigger_time.get(key, 0)
        if now - last < 0.15:
            return
        self._last_trigger_time[key] = now

        plugin_name = item["plugin_name"]
        cb_name = item["callback"]
        plugin = self.ktools.plugins.get(plugin_name)
        if plugin and hasattr(plugin, cb_name):
            cb = getattr(plugin, cb_name)
            self.sig_trigger.emit(cb)
        elif cb_name == f"toggle_{plugin_name}" and hasattr(self.ktools, "toggle_plugin"):
            self.sig_trigger.emit(lambda p=plugin_name: self.ktools.toggle_plugin(p))
        elif plugin_name == "kmanager" and hasattr(self.ktools, "toggle_plugin"):
            self.sig_trigger.emit(lambda: self.ktools.toggle_plugin("kmanager"))
        elif plugin_name == "kmanager" and hasattr(self.ktools, "manager"):
            self.sig_trigger.emit(self.ktools.manager.toggle)
        else:
            print(f"ktools: hotkey trigger failed for {plugin_name}.{cb_name} (plugin or callback not found)")

    def _setup_event_tap(self):
        if self.tap or self.global_monitor:
            return

        cg, cf, common_modes = self._get_native_tap_libs()
        if cg and cf and common_modes:
            tap_disabled_timeout = Quartz.kCGEventTapDisabledByTimeout
            tap_disabled_user = Quartz.kCGEventTapDisabledByUserInput
            ev_key_down = Quartz.kCGEventKeyDown
            kc_field = Quartz.kCGKeyboardEventKeycode

            def event_tap_callback(proxy, type_, event, refcon):
                try:
                    if type_ == tap_disabled_timeout or type_ == tap_disabled_user:
                        if self.tap:
                            cg.CGEventTapEnable(self.tap, True)
                        return event

                    if type_ == ev_key_down:
                        if self.is_recording or not event:
                            return event

                        flags = cg.CGEventGetFlags(event)
                        mask = flags & ALL_MODS_MASK
                        keycode = cg.CGEventGetIntegerValueField(event, kc_field)

                        lookup_key = (keycode, mask)
                        matched_items = self.active_bindings.get(lookup_key)
                        if matched_items:
                            for it in matched_items:
                                self.trigger_action(it)
                            return None
                except Exception:
                    pass
                return event

            cb_type = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_void_p)
            self._tap_callback_fn = event_tap_callback
            self._tap_callback_ref = cb_type(event_tap_callback)

            try:
                self.tap = cg.CGEventTapCreate(
                    Quartz.kCGSessionEventTap,
                    Quartz.kCGHeadInsertEventTap,
                    0,
                    (1 << Quartz.kCGEventKeyDown),
                    self._tap_callback_ref,
                    None
                )
                if self.tap:
                    self.runLoopSource = cf.CFMachPortCreateRunLoopSource(None, self.tap, 0)
                    if self.runLoopSource:
                        cf.CFRunLoopAddSource(cf.CFRunLoopGetMain(), self.runLoopSource, common_modes)
                        cg.CGEventTapEnable(self.tap, True)
                    else:
                        cf.CFMachPortInvalidate(self.tap)
                        cf.CFRelease(self.tap)
                        self.tap = None
                        self._tap_callback_ref = None
                        self._tap_callback_fn = None
                        self._setup_passive_monitors()
                else:
                    self._tap_callback_ref = None
                    self._tap_callback_fn = None
                    self._setup_passive_monitors()
            except Exception:
                if self.tap:
                    try:
                        cf.CFMachPortInvalidate(self.tap)
                        cf.CFRelease(self.tap)
                    except Exception:
                        pass
                    self.tap = None
                self._tap_callback_ref = None
                self._tap_callback_fn = None
                self._setup_passive_monitors()
        else:
            self._setup_passive_monitors()

        if not self.local_monitor:
            try:
                def local_handler(event):
                    if self.is_recording:
                        return event
                    mask = int(event.modifierFlags()) & ALL_MODS_MASK
                    kc = int(event.keyCode())
                    matched_items = self.active_bindings.get((kc, mask))
                    if matched_items:
                        for it in matched_items:
                            self.trigger_action(it)
                        return None
                    return event
                self.local_monitor = NSEvent.addLocalMonitorForEventsMatchingMask_handler_(NSKeyDownMask, local_handler)
            except Exception as e:
                print(f"ktools: failed to setup local monitor: {e}")

    def _setup_passive_monitors(self):
        if self.global_monitor:
            return

        def global_handler(event):
            if self.is_recording:
                return
            mask = int(event.modifierFlags()) & ALL_MODS_MASK
            kc = int(event.keyCode())
            matched_items = self.active_bindings.get((kc, mask))
            if matched_items:
                for it in matched_items:
                    self.trigger_action(it)

        def local_handler(event):
            if self.is_recording:
                return event
            mask = int(event.modifierFlags()) & ALL_MODS_MASK
            kc = int(event.keyCode())
            matched_items = self.active_bindings.get((kc, mask))
            if matched_items:
                for it in matched_items:
                    self.trigger_action(it)
                return None
            return event

        try:
            self.global_monitor = NSEvent.addGlobalMonitorForEventsMatchingMask_handler_(NSKeyDownMask, global_handler)
            if not self.local_monitor:
                self.local_monitor = NSEvent.addLocalMonitorForEventsMatchingMask_handler_(NSKeyDownMask, local_handler)
        except Exception as e:
            print(f"ktools: failed to setup passive monitors: {e}")

    def unload(self):
        cg = getattr(self, "_cg_lib", None)
        cf = getattr(self, "_cf_lib", None)
        common_modes = getattr(self, "_common_modes", None)
        try:
            if self.tap:
                if cg:
                    cg.CGEventTapEnable(self.tap, False)
                if cf and self.runLoopSource and common_modes:
                    cf.CFRunLoopRemoveSource(cf.CFRunLoopGetMain(), self.runLoopSource, common_modes)
                    cf.CFRelease(self.runLoopSource)
                    self.runLoopSource = None
                if cf:
                    cf.CFMachPortInvalidate(self.tap)
                    cf.CFRelease(self.tap)
                self.tap = None
        except Exception:
            pass

        self._tap_callback_ref = None
        self._tap_callback_fn = None

        try:
            if self.global_monitor:
                NSEvent.removeMonitor_(self.global_monitor)
                self.global_monitor = None
            if self.local_monitor:
                NSEvent.removeMonitor_(self.local_monitor)
                self.local_monitor = None
        except Exception:
            pass


class SecurityError(Exception):
    pass

class SemVer:
    @staticmethod
    def parse(version_str):
        if not version_str:
            return ((0, 0, 0), "")
        clean = str(version_str).strip().lstrip("vV")
        parts = clean.split("-", 1)
        main_part = parts[0]
        prerelease = parts[1] if len(parts) > 1 else ""
        nums = []
        for segment in main_part.split("."):
            try:
                nums.append(int(segment))
            except ValueError:
                nums.append(0)
        while len(nums) < 3:
            nums.append(0)
        return (tuple(nums[:3]), prerelease)

    @classmethod
    def compare(cls, v1, v2):
        n1, p1 = cls.parse(v1)
        n2, p2 = cls.parse(v2)
        if n1 != n2:
            return 1 if n1 > n2 else -1
        if p1 and not p2:
            return -1
        if not p1 and p2:
            return 1
        if p1 < p2:
            return -1
        elif p1 > p2:
            return 1
        return 0

    @classmethod
    def is_newer(cls, remote_version, local_version):
        return cls.compare(remote_version, local_version) > 0

class SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        valid_newurl = SecurityValidator.validate_url(newurl)
        clean_newurl, new_auth = SecurityValidator._split_url_auth(valid_newurl)
        new_req = super().redirect_request(req, fp, code, msg, headers, clean_newurl)
        if new_req is None:
            return None
        if new_auth:
            new_req.add_unredirected_header("Authorization", new_auth)
        else:
            old_auth = req.get_header("Authorization") or req.unredirected_hdrs.get("Authorization")
            old_p = urllib.parse.urlparse(req.full_url)
            new_p = urllib.parse.urlparse(clean_newurl)
            if old_auth and (old_p.scheme.lower(), (old_p.hostname or "").lower(), old_p.port) == (new_p.scheme.lower(), (new_p.hostname or "").lower(), new_p.port):
                new_req.add_unredirected_header("Authorization", old_auth)
            else:
                new_req.headers.pop("Authorization", None)
                new_req.unredirected_hdrs.pop("Authorization", None)
        return new_req

class SecurityValidator:
    @classmethod
    def validate_url(cls, url, check_dns=True):
        if not url or not isinstance(url, str):
            raise SecurityError("URL must be a non-empty string")
        parsed = urllib.parse.urlparse(url.strip())
        if parsed.scheme.lower() not in ("http", "https"):
            raise SecurityError("Only HTTP and HTTPS protocols are allowed")
        host = (parsed.hostname or "").lower()
        if not host:
            raise SecurityError("Invalid host in URL")
        try:
            _ = parsed.port
        except ValueError:
            raise SecurityError("Invalid port in URL")
        return parsed.geturl()

    @staticmethod
    def _split_url_auth(url):
        parsed = urllib.parse.urlparse(url)
        if parsed.username is None and parsed.password is None:
            return url, None
        user = urllib.parse.unquote(parsed.username or "")
        pwd = urllib.parse.unquote(parsed.password or "")
        token = base64.b64encode(f"{user}:{pwd}".encode("utf-8")).decode("ascii")
        host = parsed.hostname or ""
        if ":" in host and not host.startswith("["):
            host = f"[{host}]"
        netloc = f"{host}:{parsed.port}" if parsed.port is not None else host
        clean_url = urllib.parse.urlunparse((parsed.scheme, netloc, parsed.path, parsed.params, parsed.query, parsed.fragment))
        return clean_url, f"Basic {token}"

    @classmethod
    def open_url(cls, req_or_url, timeout=10):
        if isinstance(req_or_url, str):
            valid_url = cls.validate_url(req_or_url)
            clean_url, auth_header = cls._split_url_auth(valid_url)
            req = urllib.request.Request(clean_url, headers={"User-Agent": "ktools-updater/1.0"})
        else:
            valid_url = cls.validate_url(req_or_url.full_url)
            clean_url, auth_header = cls._split_url_auth(valid_url)
            if clean_url != req_or_url.full_url:
                headers = dict(req_or_url.header_items())
                req = urllib.request.Request(clean_url, data=req_or_url.data, headers=headers, method=req_or_url.get_method())
            else:
                req = req_or_url
            if not req.has_header("User-agent"):
                req.add_header("User-Agent", "ktools-updater/1.0")
        if auth_header and not req.has_header("Authorization"):
            req.add_unredirected_header("Authorization", auth_header)
        opener = urllib.request.build_opener(SafeRedirectHandler())
        return opener.open(req, timeout=timeout)

    @staticmethod
    def sanitize_name(name):
        clean = str(name).strip()
        if not re.match(r"^[a-zA-Z0-9_\-]+$", clean):
            raise SecurityError("Invalid name format: only alphanumeric, dash and underscore allowed")
        return clean

    @classmethod
    def inspect_zip_archive(cls, zip_path, target_dir):
        if not os.path.isfile(zip_path):
            raise SecurityError("Archive file does not exist")

        target_abs = os.path.abspath(target_dir)
        parent_dir = os.path.dirname(target_abs)
        if not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)

        usage = shutil.disk_usage(parent_dir)
        free_bytes = usage.free

        with zipfile.ZipFile(zip_path, "r") as zf:
            infolist = zf.infolist()
            total_uncompressed = sum(m.file_size for m in infolist)
            total_compressed = sum(m.compress_size for m in infolist)

            reserve_bytes = 250 * 1024 * 1024
            if total_uncompressed + reserve_bytes > free_bytes:
                raise SecurityError(
                    f"Insufficient disk space: requires {total_uncompressed / (1024*1024):.1f} MB, "
                    f"free space {free_bytes / (1024*1024):.1f} MB"
                )

            if total_uncompressed > 500 * 1024 * 1024 and total_compressed > 0:
                ratio = total_uncompressed / max(total_compressed, 1)
                if ratio > 200:
                    raise SecurityError("Suspicious compression ratio detected (compression bomb)")

            for member in infolist:
                norm_name = os.path.normpath(member.filename)
                if norm_name.startswith("..") or os.path.isabs(norm_name):
                    raise SecurityError(f"Zip Slip path traversal detected in member: {member.filename}")
                dest_path = os.path.abspath(os.path.join(target_abs, member.filename))
                if os.path.commonpath([target_abs, dest_path]) != target_abs:
                    raise SecurityError(f"Path traversal escape detected in member: {member.filename}")
                is_symlink = False
                if hasattr(member, "is_symlink") and member.is_symlink():
                    is_symlink = True
                elif (member.external_attr >> 16) & 0o120000 == 0o120000:
                    is_symlink = True
                if is_symlink:
                    raise SecurityError(f"Symlinks are forbidden in archive: {member.filename}")

class SafeArchiveExtractor:
    CORE_ALWAYS_PROTECTED = {
        "plugins"
    }

    CORE_PROTECTED_ENTRIES = {
        "plugins",
        ".venv",
        ".venv_test",
        "venv",
        ".git",
        "hotkeys.json",
        "ktools_settings.json",
        "dev_logs",
        "dev_scripts",
        "scratch",
        ".DS_Store"
    }

    @staticmethod
    def _normalize_rel_entry(raw_entry, base_dir):
        if not isinstance(raw_entry, str):
            return None
        s = raw_entry.strip().replace("\\", "/")
        if not s or s.startswith("/") or os.path.isabs(raw_entry.strip()):
            return None
        if len(s) >= 2 and s[1] == ":":
            return None
        while s.startswith("./"):
            s = s[2:]
        s = s.rstrip("/")
        if not s:
            return None
        norm = posixpath.normpath(s)
        if norm in ("", ".", "..", "inf.json") or norm.startswith("../"):
            return None
        base_abs = os.path.abspath(base_dir)
        target_abs = os.path.abspath(os.path.join(base_abs, norm.replace("/", os.sep)))
        try:
            if os.path.commonpath([base_abs, target_abs]) != base_abs or target_abs == base_abs:
                return None
        except ValueError:
            return None
        return norm

    @classmethod
    def _read_preserve_spec(cls, inf_path, base_dir):
        if not os.path.isfile(inf_path):
            return False, []
        try:
            with open(inf_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return False, []
        if not isinstance(data, dict):
            return False, []
        has_field = ("preserve" in data) or ("preserve_files" in data)
        if not has_field:
            return False, []
        raw_val = data.get("preserve") if "preserve" in data else data.get("preserve_files")
        if isinstance(raw_val, str):
            raw_list = [raw_val]
        elif isinstance(raw_val, list):
            raw_list = raw_val
        else:
            raw_list = []
        rules = []
        seen = set()
        for item in raw_list:
            norm = cls._normalize_rel_entry(item, base_dir)
            if norm and norm != "inf.json" and norm not in seen:
                seen.add(norm)
                rules.append(norm)
        return True, rules

    @classmethod
    def _resolve_preserve_rules(cls, staging_dir, destination_dir, is_core=False):
        new_has, new_rules = cls._read_preserve_spec(os.path.join(staging_dir, "inf.json"), destination_dir)
        old_has, old_rules = cls._read_preserve_spec(os.path.join(destination_dir, "inf.json"), destination_dir)
        explicit = new_has or old_has
        rules = list(new_rules if new_has else (old_rules if old_has else []))

        if is_core:
            mandatory = list(cls.CORE_ALWAYS_PROTECTED)
            if sys.prefix and sys.prefix != sys.base_prefix:
                dest_abs = os.path.abspath(destination_dir)
                prefix_abs = os.path.abspath(sys.prefix)
                try:
                    if os.path.commonpath([dest_abs, prefix_abs]) == dest_abs and prefix_abs != dest_abs:
                        rel_venv = os.path.relpath(prefix_abs, dest_abs).replace(os.sep, "/")
                        norm_venv = cls._normalize_rel_entry(rel_venv, destination_dir)
                        if norm_venv and norm_venv not in mandatory:
                            mandatory.append(norm_venv)
                except ValueError:
                    pass
            base_rules = rules if explicit else list(cls.CORE_PROTECTED_ENTRIES)
            merged = []
            seen = set()
            for r in mandatory + base_rules:
                if r not in seen:
                    seen.add(r)
                    merged.append(r)
            return explicit, merged

        return explicit, rules

    @staticmethod
    def _is_rel_preserved(rel_posix, rules):
        if rel_posix == "inf.json":
            return False
        for rule in rules:
            if rel_posix == rule or rel_posix.startswith(rule + "/"):
                return True
        return False

    @classmethod
    def _is_dir_needed_by_preserved(cls, dir_rel_posix, rules):
        if cls._is_rel_preserved(dir_rel_posix, rules):
            return True
        prefix = dir_rel_posix + "/"
        return any(rule.startswith(prefix) for rule in rules)

    @classmethod
    def extract(cls, zip_path, destination_dir, is_core=False):
        destination_dir = os.path.abspath(destination_dir)
        SecurityValidator.inspect_zip_archive(zip_path, destination_dir)

        if not is_core:
            if os.path.isdir(os.path.join(destination_dir, "plugins")):
                if os.path.isfile(os.path.join(destination_dir, "main.py")):
                    is_core = True
                else:
                    inf_file = os.path.join(destination_dir, "inf.json")
                    if os.path.isfile(inf_file):
                        try:
                            with open(inf_file, "r", encoding="utf-8") as f:
                                is_core = json.load(f).get("name") == "ktools"
                        except Exception:
                            pass

        if is_core:
            return cls._extract_core(zip_path, destination_dir)
        return cls._extract_plugin(zip_path, destination_dir)

    @classmethod
    def _unpack_zip(cls, zip_path, staging_dir):
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.filename.startswith("__MACOSX/") or "/__MACOSX/" in member.filename:
                    continue
                if os.path.basename(member.filename).startswith("._"):
                    continue
                target_path = os.path.abspath(os.path.join(staging_dir, member.filename))
                if os.path.commonpath([staging_dir, target_path]) != staging_dir:
                    raise SecurityError("Extraction path boundary violation")
                if member.is_dir() or member.filename.endswith("/"):
                    os.makedirs(target_path, exist_ok=True)
                    continue

                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                bytes_written = 0
                with zf.open(member) as source_f, open(target_path, "wb") as dest_f:
                    while True:
                        chunk = source_f.read(65536)
                        if not chunk:
                            break
                        dest_f.write(chunk)
                        bytes_written += len(chunk)
                        if bytes_written > member.file_size:
                            raise SecurityError("Member wrote more bytes than declared (stream overflow)")

    @classmethod
    def _unwrap_single_root(cls, staging_dir, base_parent, dir_name):
        macosx_dir = os.path.join(staging_dir, "__MACOSX")
        if os.path.exists(macosx_dir):
            shutil.rmtree(macosx_dir, ignore_errors=True)

        staging_items = [i for i in os.listdir(staging_dir) if not i.startswith(".") and i != "__MACOSX"]
        if len(staging_items) == 1:
            single_item = os.path.join(staging_dir, staging_items[0])
            if os.path.isdir(single_item):
                temp_inner = os.path.join(base_parent, f".temp_inner_{dir_name}_{int(time.time() * 1000)}")
                os.rename(single_item, temp_inner)
                shutil.rmtree(staging_dir)
                os.rename(temp_inner, staging_dir)
                macosx_inner = os.path.join(staging_dir, "__MACOSX")
                if os.path.exists(macosx_inner):
                    shutil.rmtree(macosx_inner, ignore_errors=True)

    @classmethod
    def _extract_core(cls, zip_path, destination_dir):
        base_parent = os.path.dirname(destination_dir)
        dir_name = os.path.basename(destination_dir)
        staging_dir = os.path.join(base_parent, f".staging_{dir_name}_{int(time.time() * 1000)}")

        if os.path.exists(staging_dir):
            shutil.rmtree(staging_dir, ignore_errors=True)
        os.makedirs(staging_dir, exist_ok=True)

        backup_dir = os.path.join(base_parent, f".backup_core_{int(time.time() * 1000)}")
        copied_backup_paths = []
        new_paths = []
        current_tmp_file = None

        try:
            cls._unpack_zip(zip_path, staging_dir)
            cls._unwrap_single_root(staging_dir, base_parent, dir_name)

            _, preserve_rules = cls._resolve_preserve_rules(staging_dir, destination_dir, is_core=True)

            staging_plugins = os.path.join(staging_dir, "plugins")
            if os.path.exists(staging_plugins):
                if os.path.isdir(staging_plugins):
                    shutil.rmtree(staging_plugins, ignore_errors=True)
                else:
                    os.remove(staging_plugins)

            for root, dirs, files in os.walk(staging_dir, topdown=False):
                rel_dir = os.path.relpath(root, staging_dir)
                for f in files:
                    src_f = os.path.join(root, f)
                    rel_f = f if rel_dir == "." else os.path.join(rel_dir, f)
                    rel_posix = rel_f.replace(os.sep, "/")
                    dest_f = os.path.join(destination_dir, rel_f)
                    if cls._is_rel_preserved(rel_posix, preserve_rules) and os.path.exists(dest_f):
                        try:
                            os.remove(src_f)
                        except Exception:
                            pass
                if rel_dir != "." and os.path.isdir(root) and not os.listdir(root):
                    try:
                        os.rmdir(root)
                    except Exception:
                        pass

            os.makedirs(backup_dir, exist_ok=True)
            os.makedirs(destination_dir, exist_ok=True)

            staging_files_rel = set()
            for root, dirs, files in os.walk(staging_dir):
                rel_dir = os.path.relpath(root, staging_dir)
                for f in files:
                    rel_f = f if rel_dir == "." else os.path.join(rel_dir, f)
                    staging_files_rel.add(rel_f.replace(os.sep, "/"))

            non_preserved_existing = []
            for root, dirs, files in os.walk(destination_dir, topdown=True):
                rel_dir = os.path.relpath(root, destination_dir)
                kept_dirs = []
                for d in dirs:
                    d_rel_posix = d if rel_dir == "." else f"{rel_dir.replace(os.sep, '/')}/{d}"
                    if not cls._is_rel_preserved(d_rel_posix, preserve_rules):
                        kept_dirs.append(d)
                dirs[:] = kept_dirs

                for f in files:
                    rel_f = f if rel_dir == "." else os.path.join(rel_dir, f)
                    rel_posix = rel_f.replace(os.sep, "/")
                    if cls._is_rel_preserved(rel_posix, preserve_rules):
                        continue
                    dest_f = os.path.join(destination_dir, rel_f)
                    bup_f = os.path.join(backup_dir, rel_f)
                    os.makedirs(os.path.dirname(bup_f), exist_ok=True)
                    shutil.copy2(dest_f, bup_f)
                    copied_backup_paths.append((dest_f, bup_f))
                    non_preserved_existing.append((rel_posix, dest_f))

            for rel_posix, dest_f in non_preserved_existing:
                if rel_posix not in staging_files_rel and os.path.isfile(dest_f):
                    os.remove(dest_f)

            for root, dirs, files in os.walk(destination_dir, topdown=False):
                rel_dir = os.path.relpath(root, destination_dir)
                if rel_dir == ".":
                    continue
                rel_posix = rel_dir.replace(os.sep, "/")
                if not cls._is_dir_needed_by_preserved(rel_posix, preserve_rules):
                    if os.path.isdir(root) and not os.listdir(root):
                        os.rmdir(root)

            backed_up_targets = {dest_f for dest_f, _ in copied_backup_paths}
            for root, dirs, files in os.walk(staging_dir):
                rel_dir = os.path.relpath(root, staging_dir)
                dest_dir = destination_dir if rel_dir == "." else os.path.join(destination_dir, rel_dir)
                if os.path.isfile(dest_dir):
                    os.remove(dest_dir)
                os.makedirs(dest_dir, exist_ok=True)

                for f in files:
                    src_f = os.path.join(root, f)
                    rel_f = f if rel_dir == "." else os.path.join(rel_dir, f)
                    dest_f = os.path.join(destination_dir, rel_f)

                    if os.path.isdir(dest_f):
                        shutil.rmtree(dest_f)
                    if dest_f not in backed_up_targets and not os.path.exists(dest_f):
                        new_paths.append(dest_f)

                    current_tmp_file = dest_f + f".kupdate_{int(time.time() * 1000)}.tmp"
                    shutil.copy2(src_f, current_tmp_file)
                    os.replace(current_tmp_file, dest_f)
                    current_tmp_file = None

            if os.path.exists(backup_dir):
                shutil.rmtree(backup_dir, ignore_errors=True)

            return True

        except Exception as e:
            if current_tmp_file and os.path.exists(current_tmp_file):
                try:
                    os.remove(current_tmp_file)
                except Exception:
                    pass

            if os.path.exists(backup_dir):
                for nf in new_paths:
                    try:
                        if os.path.isfile(nf):
                            os.remove(nf)
                        elif os.path.isdir(nf):
                            shutil.rmtree(nf, ignore_errors=True)
                    except Exception:
                        pass
                for dest_f, bup_f in copied_backup_paths:
                    try:
                        if os.path.exists(bup_f):
                            if os.path.isdir(dest_f):
                                shutil.rmtree(dest_f, ignore_errors=True)
                            os.makedirs(os.path.dirname(dest_f), exist_ok=True)
                            shutil.copy2(bup_f, dest_f)
                    except Exception:
                        pass
                shutil.rmtree(backup_dir, ignore_errors=True)
            raise e

        finally:
            if os.path.exists(staging_dir):
                shutil.rmtree(staging_dir, ignore_errors=True)

    @classmethod
    def _extract_plugin(cls, zip_path, destination_dir):
        base_parent = os.path.dirname(destination_dir)
        dir_name = os.path.basename(destination_dir)
        staging_dir = os.path.join(base_parent, f".staging_{dir_name}_{int(time.time() * 1000)}")

        if os.path.exists(staging_dir):
            shutil.rmtree(staging_dir, ignore_errors=True)
        os.makedirs(staging_dir, exist_ok=True)

        try:
            cls._unpack_zip(zip_path, staging_dir)
            cls._unwrap_single_root(staging_dir, base_parent, dir_name)

            explicit, preserve_rules = cls._resolve_preserve_rules(staging_dir, destination_dir, is_core=False)

            backup_dir = os.path.join(base_parent, f".backup_{dir_name}_{int(time.time() * 1000)}")
            if os.path.exists(destination_dir):
                os.rename(destination_dir, backup_dir)

            try:
                os.rename(staging_dir, destination_dir)

                if os.path.exists(backup_dir):
                    for b_root, b_dirs, b_files in os.walk(backup_dir):
                        rel_path = os.path.relpath(b_root, backup_dir)
                        target_sub = destination_dir if rel_path == "." else os.path.join(destination_dir, rel_path)
                        for bf in b_files:
                            rel_f = bf if rel_path == "." else os.path.join(rel_path, bf)
                            rel_posix = rel_f.replace(os.sep, "/")
                            if rel_posix == "inf.json":
                                continue
                            src_bf = os.path.join(b_root, bf)
                            dest_bf = os.path.join(target_sub, bf)
                            if explicit:
                                if cls._is_rel_preserved(rel_posix, preserve_rules):
                                    if os.path.isdir(dest_bf):
                                        shutil.rmtree(dest_bf)
                                    os.makedirs(target_sub, exist_ok=True)
                                    shutil.copy2(src_bf, dest_bf)
                            else:
                                if not os.path.exists(dest_bf):
                                    if bf.endswith(".json"):
                                        os.makedirs(target_sub, exist_ok=True)
                                        shutil.copy2(src_bf, dest_bf)
                                    elif not bf.endswith((".py", ".pyc", ".c", ".so", ".dylib")):
                                        os.makedirs(target_sub, exist_ok=True)
                                        shutil.copy2(src_bf, dest_bf)

                    shutil.rmtree(backup_dir, ignore_errors=True)

            except Exception as e:
                if os.path.exists(backup_dir):
                    if os.path.exists(destination_dir):
                        shutil.rmtree(destination_dir, ignore_errors=True)
                    os.rename(backup_dir, destination_dir)
                raise e

            return True

        finally:
            if os.path.exists(staging_dir):
                shutil.rmtree(staging_dir, ignore_errors=True)

class ImageCache:
    _instance = None

    def __init__(self):
        self.cache_dir = os.path.expanduser("~/.cache/ktools/img_cache")
        os.makedirs(self.cache_dir, exist_ok=True)
        self.memory_cache = {}
        self.max_memory_items = 60

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = ImageCache()
        return cls._instance

    def clear_memory(self):
        self.memory_cache.clear()

    def get_local_path(self, url):
        if not url:
            return ""
        if os.path.isfile(url):
            return url
        url_hash = hashlib.sha256(url.encode("utf-8")).hexdigest()
        ext = os.path.splitext(urllib.parse.urlparse(url).path)[1]
        if not ext or len(ext) > 5:
            ext = ".png"
        return os.path.join(self.cache_dir, f"{url_hash}{ext}")

    def get_pixmap(self, url, max_w=None, max_h=None):
        if not url:
            return None
        cache_key = f"{url}_{max_w}_{max_h}"
        if cache_key in self.memory_cache:
            pix = self.memory_cache.pop(cache_key)
            self.memory_cache[cache_key] = pix
            return pix

        local_path = self.get_local_path(url)
        if os.path.isfile(local_path):
            pix = QPixmap(local_path)
            if not pix.isNull():
                if max_w or max_h:
                    target_w = max_w if max_w is not None else 10000
                    target_h = max_h if max_h is not None else 10000
                    pix = pix.scaled(target_w, target_h, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                while len(self.memory_cache) >= self.max_memory_items:
                    oldest_key = next(iter(self.memory_cache))
                    del self.memory_cache[oldest_key]
                self.memory_cache[cache_key] = pix
                return pix
        return None

class DownloadWorker(QThread):
    progress = pyqtSignal(int, int, float, str)
    finished = pyqtSignal(bool, str, str)

    def __init__(self, url, label="downloading"):
        super().__init__()
        self.url = url
        self.label = label
        self._is_cancelled = False

    def cancel(self):
        self._is_cancelled = True

    def run(self):
        temp_file = None
        try:
            valid_url = SecurityValidator.validate_url(self.url, check_dns=False)
            req = urllib.request.Request(
                valid_url,
                headers={"User-Agent": "ktools-updater/1.0"}
            )
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".ktools_download")
            temp_path = temp_file.name

            with SecurityValidator.open_url(req, timeout=30) as response:
                total_bytes = int(response.headers.get("Content-Length", 0))
                bytes_downloaded = 0
                start_time = time.time()
                last_update_time = start_time
                last_bytes = 0

                while not self._is_cancelled:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    temp_file.write(chunk)
                    bytes_downloaded += len(chunk)

                    now = time.time()
                    if now - last_update_time >= 0.1 or bytes_downloaded == total_bytes:
                        elapsed = now - last_update_time
                        speed = (bytes_downloaded - last_bytes) / max(elapsed, 0.001)
                        last_update_time = now
                        last_bytes = bytes_downloaded

                        if total_bytes > 0:
                            percent = int((bytes_downloaded / total_bytes) * 100)
                            mb_done = bytes_downloaded / (1024 * 1024)
                            mb_total = total_bytes / (1024 * 1024)
                            mb_speed = speed / (1024 * 1024)
                            status_text = (
                                f"{self.label}: {mb_done:.1f} MB / {mb_total:.1f} MB ({percent}%) • {mb_speed:.1f} MB/s"
                            )
                        else:
                            mb_done = bytes_downloaded / (1024 * 1024)
                            mb_speed = speed / (1024 * 1024)
                            status_text = f"{self.label}: {mb_done:.1f} MB • {mb_speed:.1f} MB/s"

                        self.progress.emit(bytes_downloaded, total_bytes, speed, status_text)

            temp_file.close()

            if self._is_cancelled:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                self.finished.emit(False, "Download cancelled", "")
                return

            self.finished.emit(True, "", temp_path)
        except Exception as e:
            if temp_file and os.path.exists(temp_file.name):
                try:
                    os.remove(temp_file.name)
                except Exception:
                    pass
            self.finished.emit(False, str(e), "")

class ImageDownloadWorker(QThread):
    image_loaded = pyqtSignal(str, str)

    def __init__(self, urls):
        super().__init__()
        self.urls = urls

    def run(self):
        cache = ImageCache.get_instance()
        for url in self.urls:
            if not url or not url.startswith("http"):
                continue
            local_path = cache.get_local_path(url)
            if not os.path.exists(local_path):
                tmp_path = local_path + f".tmp_{int(time.time() * 1000)}"
                try:
                    valid_url = SecurityValidator.validate_url(url, check_dns=False)
                    req = urllib.request.Request(valid_url, headers={"User-Agent": "ktools-updater/1.0"})
                    with SecurityValidator.open_url(req, timeout=10) as resp, open(tmp_path, "wb") as out_f:
                        shutil.copyfileobj(resp, out_f)
                    os.replace(tmp_path, local_path)
                    self.image_loaded.emit(url, local_path)
                except Exception:
                    if os.path.exists(tmp_path):
                        try:
                            os.remove(tmp_path)
                        except Exception:
                            pass
                    continue
            else:
                self.image_loaded.emit(url, local_path)

class RepoCheckWorker(QThread):
    finished = pyqtSignal(bool, str, dict, list)

    def __init__(self, repo_url, installed_plugins, core_version, repo_name=""):
        super().__init__()
        self.repo_url = repo_url
        self.installed_plugins = installed_plugins
        self.core_version = core_version
        self.repo_name = repo_name

    def _parse_github_repo(self, repo_url):
        clean_url = repo_url.strip().rstrip("/")
        parsed = urllib.parse.urlparse(clean_url)
        if parsed.scheme.lower() in ("http", "https") and (parsed.hostname or "").lower() in ("github.com", "www.github.com"):
            parts = [p for p in parsed.path.strip("/").split("/") if p]
            if len(parts) >= 2:
                owner = parts[0]
                repo = parts[1][:-4] if parts[1].endswith(".git") else parts[1]
                userinfo = parsed.netloc.rsplit("@", 1)[0] + "@" if "@" in parsed.netloc else ""
                return owner, repo, userinfo
        match_short = re.match(r"^([a-zA-Z0-9_-]+)/([a-zA-Z0-9_.-]+)$", clean_url)
        if match_short:
            return match_short.group(1), match_short.group(2), ""
        return None

    def _resolve_raw_root(self, repo_url):
        clean_url = repo_url.strip().rstrip("/")
        parsed = urllib.parse.urlparse(clean_url)
        if parsed.scheme.lower() == "https" and (parsed.hostname or "").lower() == "raw.githubusercontent.com":
            return clean_url
        gh = self._parse_github_repo(clean_url)
        if gh:
            owner, repo, userinfo = gh
            return f"https://{userinfo}raw.githubusercontent.com/{owner}/{repo}/main"
        return clean_url

    def _fetch_text(self, url):
        valid_url = SecurityValidator.validate_url(url, check_dns=False)
        req = urllib.request.Request(valid_url, headers={"User-Agent": "ktools-updater/1.0"})
        with SecurityValidator.open_url(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def _fetch_json(self, url):
        return json.loads(self._fetch_text(url))

    def _parse_manifest_items(self, repo_manifest, raw_root):
        parsed_items = {}
        if not isinstance(repo_manifest, dict):
            return parsed_items
        raw_plugins = repo_manifest.get("plugins")
        if raw_plugins is None:
            raw_plugins = repo_manifest.get("items")
        if isinstance(raw_plugins, dict):
            for k, v in raw_plugins.items():
                if isinstance(v, dict):
                    parsed_items[k] = dict(v)
        elif isinstance(raw_plugins, list):
            for entry in raw_plugins:
                if isinstance(entry, dict):
                    key = entry.get("id") or entry.get("name")
                    if key:
                        parsed_items[str(key)] = dict(entry)
        ktools_core = repo_manifest.get("ktools")
        if isinstance(ktools_core, dict):
            parsed_items["ktools"] = dict(ktools_core)
        for item_id, item_data in parsed_items.items():
            dl = item_data.get("download_url")
            if isinstance(dl, str) and dl and not dl.startswith(("http://", "https://")):
                item_data["download_url"] = urllib.parse.urljoin(raw_root.rstrip("/") + "/", dl)
        return parsed_items

    def _discover_from_html_index(self, base_root):
        items = {}
        try:
            body = self._fetch_text(base_root + "/")
        except Exception:
            try:
                body = self._fetch_text(base_root)
            except Exception:
                return items
        stripped = body.lstrip()
        if stripped.startswith("{"):
            try:
                manifest = json.loads(stripped)
                return self._parse_manifest_items(manifest, base_root)
            except Exception:
                pass
        base_slash = base_root.rstrip("/") + "/"
        base_parsed = urllib.parse.urlparse(base_slash)
        hrefs = re.findall(r'href\s*=\s*["\']([^"\']+)["\']', body, flags=re.IGNORECASE)
        seen_dirs = []
        seen_set = set()
        for href in hrefs:
            if not href or href.startswith(("#", "?", "mailto:", "javascript:")):
                continue
            joined = urllib.parse.urljoin(base_slash, href)
            child_parsed = urllib.parse.urlparse(joined)
            if child_parsed.scheme != base_parsed.scheme or child_parsed.netloc != base_parsed.netloc:
                continue
            if not child_parsed.path.startswith(base_parsed.path):
                continue
            rel = child_parsed.path[len(base_parsed.path):].strip("/")
            if not rel or "/" in rel or rel in (".", "..") or rel.startswith("."):
                continue
            if not child_parsed.path.endswith("/") and "." in rel:
                continue
            if rel not in seen_set:
                seen_set.add(rel)
                seen_dirs.append(rel)
        for item_name in seen_dirs:
            try:
                inf = self._fetch_json(f"{base_root}/{item_name}/inf.json")
                if isinstance(inf, dict):
                    if "download_url" not in inf:
                        inf["download_url"] = f"{base_root}/{item_name}/{item_name}.zip"
                    elif isinstance(inf["download_url"], str) and not inf["download_url"].startswith(("http://", "https://")):
                        inf["download_url"] = urllib.parse.urljoin(f"{base_root}/{item_name}/", inf["download_url"])
                    items[item_name] = inf
            except Exception:
                pass
        return items

    def _discover_from_git_forge(self, repo_url):
        items = {}
        clean = repo_url.strip().rstrip("/")
        parsed = urllib.parse.urlparse(clean)
        if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
            return items
        parts = [p for p in parsed.path.strip("/").split("/") if p]
        if len(parts) < 2:
            return items
        owner, repo = parts[0], parts[1]
        if repo.endswith(".git"):
            repo = repo[:-4]
        origin = f"{parsed.scheme}://{parsed.netloc}"
        api_url = f"{origin}/api/v1/repos/{owner}/{repo}/contents"
        try:
            contents = self._fetch_json(api_url)
        except Exception:
            return items
        if not isinstance(contents, list):
            return items
        branch = "main"
        try:
            repo_meta = self._fetch_json(f"{origin}/api/v1/repos/{owner}/{repo}")
            if isinstance(repo_meta, dict) and repo_meta.get("default_branch"):
                branch = str(repo_meta["default_branch"])
        except Exception:
            pass
        raw_base = f"{origin}/{owner}/{repo}/raw/branch/{branch}"
        for entry in contents:
            if isinstance(entry, dict) and entry.get("type") == "dir":
                item_name = entry.get("name")
                if not item_name or item_name.startswith("."):
                    continue
                try:
                    inf = self._fetch_json(f"{raw_base}/{item_name}/inf.json")
                    if isinstance(inf, dict):
                        if "download_url" not in inf:
                            inf["download_url"] = f"{raw_base}/{item_name}/{item_name}.zip"
                        items[item_name] = inf
                except Exception:
                    pass
        return items, raw_base

    def run(self):
        try:
            raw_root = self._resolve_raw_root(self.repo_url)
            repo_manifest = None
            manifest_base = raw_root
            if raw_root.lower().endswith(".json"):
                manifest_base = raw_root.rsplit("/", 1)[0]
                try:
                    repo_manifest = self._fetch_json(raw_root)
                except Exception:
                    repo_manifest = None
            else:
                for cand_name in ("repo.json", "index.json"):
                    try:
                        repo_manifest = self._fetch_json(f"{raw_root}/{cand_name}")
                        break
                    except Exception:
                        repo_manifest = None

            items = {}
            if repo_manifest and isinstance(repo_manifest, dict):
                items = self._parse_manifest_items(repo_manifest, manifest_base)
                raw_root = manifest_base
            else:
                gh = self._parse_github_repo(self.repo_url)
                if gh:
                    owner, repo, userinfo = gh
                    api_url = f"https://{userinfo}api.github.com/repos/{owner}/{repo}/contents"
                    contents = self._fetch_json(api_url)
                    if isinstance(contents, list):
                        for entry in contents:
                            if entry.get("type") == "dir":
                                item_name = entry.get("name")
                                try:
                                    inf = self._fetch_json(f"{raw_root}/{item_name}/inf.json")
                                    inf["download_url"] = f"{raw_root}/{item_name}/{item_name}.zip"
                                    items[item_name] = inf
                                except Exception:
                                    pass
                else:
                    items = self._discover_from_html_index(raw_root)
                    if not items:
                        forge_res = self._discover_from_git_forge(self.repo_url)
                        if isinstance(forge_res, tuple) and forge_res[0]:
                            items, raw_root = forge_res

            if not items:
                self.finished.emit(False, "Repository structure is empty or invalid", {}, [])
                return

            updates_available = []
            sanitized_items = {}
            for raw_id, item_data in items.items():
                if not isinstance(item_data, dict):
                    continue
                if raw_id == "ktools":
                    item_id = "ktools"
                else:
                    try:
                        item_id = SecurityValidator.sanitize_name(raw_id)
                    except SecurityError:
                        continue
                sanitized_items[item_id] = item_data
                remote_ver = item_data.get("version", "1.0.0")
                item_data["id"] = item_id
                item_data["raw_root"] = raw_root
                if "download_url" not in item_data:
                    item_data["download_url"] = f"{raw_root}/{item_id}/{item_id}.zip"

                if item_id == "ktools":
                    if SemVer.is_newer(remote_ver, self.core_version):
                        item_data["current_version"] = self.core_version
                        item_data["update_available"] = True
                        updates_available.append(item_data)
                    else:
                        item_data["current_version"] = self.core_version
                        item_data["update_available"] = False
                else:
                    installed_ver = self.installed_plugins.get(item_id, None)
                    if installed_ver is not None:
                        item_data["current_version"] = installed_ver
                        if SemVer.is_newer(remote_ver, installed_ver):
                            item_data["update_available"] = True
                            updates_available.append(item_data)
                        else:
                            item_data["update_available"] = False
                    else:
                        item_data["current_version"] = None
                        item_data["update_available"] = False

            repo_result = {
                "name": self.repo_name,
                "url": self.repo_url,
                "raw_root": raw_root,
                "items": sanitized_items
            }
            self.finished.emit(True, "", repo_result, updates_available)
        except Exception as e:
            self.finished.emit(False, str(e), {}, [])

class BatchUpdateWorker(QThread):
    queue_progress = pyqtSignal(int, int, str, int, int, float, str)
    plugin_updated = pyqtSignal(str, bool, str)
    all_finished = pyqtSignal(list)

    def __init__(self, updates_queue, plugins_dir, core_dir):
        super().__init__()
        self.queue = updates_queue
        self.plugins_dir = plugins_dir
        self.core_dir = core_dir
        self._is_cancelled = False

    def cancel(self):
        self._is_cancelled = True

    def _download_file(self, url, label, idx, total_items, item_id):
        temp_file = None
        try:
            valid_url = SecurityValidator.validate_url(url, check_dns=False)
            req = urllib.request.Request(
                valid_url,
                headers={"User-Agent": "ktools-updater/1.0"}
            )
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".ktools_download")
            temp_path = temp_file.name

            with SecurityValidator.open_url(req, timeout=30) as response:
                total_bytes = int(response.headers.get("Content-Length", 0))
                bytes_downloaded = 0
                start_time = time.time()
                last_update_time = start_time
                last_bytes = 0

                while not self._is_cancelled:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    temp_file.write(chunk)
                    bytes_downloaded += len(chunk)

                    now = time.time()
                    if now - last_update_time >= 0.1 or bytes_downloaded == total_bytes:
                        elapsed = now - last_update_time
                        speed = (bytes_downloaded - last_bytes) / max(elapsed, 0.001)
                        last_update_time = now
                        last_bytes = bytes_downloaded

                        if total_bytes > 0:
                            percent = int((bytes_downloaded / total_bytes) * 100)
                            mb_done = bytes_downloaded / (1024 * 1024)
                            mb_total = total_bytes / (1024 * 1024)
                            mb_speed = speed / (1024 * 1024)
                            status_text = (
                                f"{label}: {mb_done:.1f} MB / {mb_total:.1f} MB ({percent}%) • {mb_speed:.1f} MB/s"
                            )
                        else:
                            mb_done = bytes_downloaded / (1024 * 1024)
                            mb_speed = speed / (1024 * 1024)
                            status_text = f"{label}: {mb_done:.1f} MB • {mb_speed:.1f} MB/s"

                        self.queue_progress.emit(idx + 1, total_items, item_id, bytes_downloaded, total_bytes, speed, status_text)

            temp_file.close()

            if self._is_cancelled:
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except Exception:
                        pass
                return False, "Download cancelled", ""

            return True, "", temp_path
        except Exception as e:
            if temp_file and os.path.exists(temp_file.name):
                try:
                    os.remove(temp_file.name)
                except Exception:
                    pass
            return False, str(e), ""

    def run(self):
        results = []
        total_items = len(self.queue)

        for idx, item in enumerate(self.queue):
            if self._is_cancelled:
                break

            item_id = item.get("id")
            if not item_id or not isinstance(item_id, str):
                continue

            is_core = (item_id == "ktools")
            if not is_core:
                try:
                    item_id = SecurityValidator.sanitize_name(item_id)
                except SecurityError:
                    results.append({"id": str(item_id), "success": False, "error": "Invalid plugin id"})
                    continue
                target_dir = os.path.abspath(os.path.join(self.plugins_dir, item_id))
                if os.path.commonpath([self.plugins_dir, target_dir]) != self.plugins_dir:
                    results.append({"id": item_id, "success": False, "error": "Path traversal detected"})
                    continue
            else:
                target_dir = self.core_dir

            download_url = item.get("download_url")
            label = f"downloading {item_id}"

            download_success, err_msg, temp_path = self._download_file(download_url, label, idx, total_items, item_id)

            if not download_success or not temp_path:
                results.append({"id": item_id, "success": False, "error": err_msg})
                self.plugin_updated.emit(item_id, False, err_msg)
                continue

            try:
                self.queue_progress.emit(idx + 1, total_items, item_id, 100, 100, 0.0, f"extracting & verifying {item_id}...")
                if not is_core and os.path.isdir(self.plugins_dir) and not os.path.exists(target_dir):
                    for entry in os.listdir(self.plugins_dir):
                        if entry.startswith(".") or entry == "__MACOSX":
                            continue
                        edir = os.path.join(self.plugins_dir, entry)
                        if not os.path.isdir(edir) or edir == target_dir:
                            continue
                        inf_p = os.path.join(edir, "inf.json")
                        if os.path.isfile(inf_p):
                            try:
                                with open(inf_p, "r", encoding="utf-8") as f:
                                    d = json.load(f)
                                    if d.get("id") == item_id or d.get("name") == item_id:
                                        os.rename(edir, target_dir)
                                        break
                            except Exception:
                                pass

                SafeArchiveExtractor.extract(temp_path, target_dir, is_core=is_core)
                results.append({"id": item_id, "success": True, "error": ""})
                self.plugin_updated.emit(item_id, True, "")
            except Exception as e:
                results.append({"id": item_id, "success": False, "error": str(e)})
                self.plugin_updated.emit(item_id, False, str(e))
            finally:
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except Exception:
                        pass

        self.all_finished.emit(results)

class RepositoryManager(QObject):
    updates_found = pyqtSignal(list)
    check_started = pyqtSignal()
    check_finished = pyqtSignal(list, str)
    repo_list_changed = pyqtSignal()
    core_update_ready = pyqtSignal(dict)

    DEFAULT_OFFICIAL_REPO = {
        "name": "official",
        "url": "https://github.com/kriaiss/ktools-official-repository",
        "is_default": True
    }

    def __init__(self, ktools):
        super().__init__()
        self.ktools = ktools
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.plugins_dir = os.path.join(self.base_dir, "plugins")
        self.settings_path = os.path.join(self.base_dir, "ktools_settings.json")
        self.cache_dir = os.path.expanduser("~/.cache/ktools")
        os.makedirs(self.cache_dir, exist_ok=True)

        self.settings = {}
        self.cached_repos_data = {}
        self.available_updates = []
        self.core_update = None
        self._active_worker = None
        self._batch_worker = None

        self._load_settings()

        self.check_timer = QTimer(self)
        self.check_timer.setInterval(1800 * 1000)
        self.check_timer.timeout.connect(self._on_timer_check)
        self.check_timer.start()

        QTimer.singleShot(2500, self._startup_check)

    def _load_settings(self):
        default_settings = {
            "repositories": [self.DEFAULT_OFFICIAL_REPO],
            "auto_check_updates": True,
            "check_interval_hours": 24,
            "last_update_check_timestamp": 0
        }
        if os.path.exists(self.settings_path):
            try:
                with open(self.settings_path, "r", encoding="utf-8") as f:
                    self.settings = json.load(f)
                for k, v in default_settings.items():
                    if k not in self.settings:
                        self.settings[k] = v
                for r in self.settings.get("repositories", []):
                    if r.get("is_default", False) and r.get("name") == "official":
                        r["url"] = self.DEFAULT_OFFICIAL_REPO["url"]
            except Exception:
                self.settings = default_settings
        else:
            self.settings = default_settings
            self._save_settings()

    def _save_settings(self):
        try:
            with open(self.settings_path, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"ktools: failed to save settings: {e}")

    def get_repositories(self):
        return list(self.settings.get("repositories", []))

    def get_installed_plugins_dict(self):
        installed = {}
        if os.path.isdir(self.plugins_dir):
            for name in os.listdir(self.plugins_dir):
                if name.startswith(".") or name == "__MACOSX":
                    continue
                inf_path = os.path.join(self.plugins_dir, name, "inf.json")
                if os.path.isfile(inf_path):
                    try:
                        with open(inf_path, "r", encoding="utf-8") as f:
                            d = json.load(f)
                            ver = d.get("version", "1.0.0")
                            for key in [name, d.get("id"), d.get("name")]:
                                if key:
                                    if key in installed:
                                        if SemVer.is_newer(ver, installed[key]):
                                            installed[key] = ver
                                    else:
                                        installed[key] = ver
                    except Exception:
                        if name not in installed:
                            installed[name] = "1.0.0"
        return installed

    def sync_installed_status(self):
        installed = self.get_installed_plugins_dict()
        core_ver = self.get_core_version()
        new_updates = []

        for repo_name, repo_data in self.cached_repos_data.items():
            items = repo_data.get("items", {})
            for item_id, item_data in items.items():
                remote_ver = item_data.get("version", "1.0.0")
                if item_id == "ktools":
                    item_data["current_version"] = core_ver
                    if SemVer.is_newer(remote_ver, core_ver):
                        item_data["update_available"] = True
                        if not any(u.get("id") == "ktools" for u in new_updates):
                            new_updates.append(item_data)
                    else:
                        item_data["update_available"] = False
                else:
                    cur_ver = installed.get(item_id, None)
                    if cur_ver is None and item_data.get("id"):
                        cur_ver = installed.get(item_data.get("id"), None)
                    if cur_ver is None and item_data.get("name"):
                        cur_ver = installed.get(item_data.get("name"), None)
                    item_data["current_version"] = cur_ver
                    if cur_ver is not None:
                        if SemVer.is_newer(remote_ver, cur_ver):
                            item_data["update_available"] = True
                            if not any(u.get("id") == item_id for u in new_updates):
                                new_updates.append(item_data)
                        else:
                            item_data["update_available"] = False
                    else:
                        item_data["update_available"] = False

        self.available_updates = [u for u in new_updates if u.get("id") != "ktools"]
        core_up = next((u for u in new_updates if u.get("id") == "ktools"), None)
        self.core_update = core_up

    def get_core_version(self):
        inf_path = os.path.join(self.base_dir, "inf.json")
        if os.path.isfile(inf_path):
            try:
                with open(inf_path, "r", encoding="utf-8") as f:
                    d = json.load(f)
                    return d.get("version", "1.1.0")
            except Exception:
                pass
        return "1.1.0"

    def add_repository(self, name, url, on_done=None):
        name = SecurityValidator.sanitize_name(name)
        url = SecurityValidator.validate_url(url, check_dns=False)

        repos = self.settings.get("repositories", [])
        for r in repos:
            if r["name"].lower() == name.lower() or r["url"].lower() == url.lower():
                raise SecurityError(f"Repository with this name or URL already exists")

        installed = self.get_installed_plugins_dict()
        worker = RepoCheckWorker(url, installed, self.get_core_version(), repo_name=name)

        def on_check_finished(success, err, repo_data, updates):
            if success:
                repos.append({
                    "name": name,
                    "url": url,
                    "is_default": False
                })
                self.settings["repositories"] = repos
                self._save_settings()
                self.cached_repos_data[name] = repo_data
                self.repo_list_changed.emit()
                if on_done:
                    on_done(True, "")
            else:
                if on_done:
                    on_done(False, err)
            worker.deleteLater()

        worker.finished.connect(on_check_finished)
        worker.start()

    def remove_repository(self, name):
        repos = self.settings.get("repositories", [])
        new_repos = [r for r in repos if r["name"].lower() != name.lower() or r.get("is_default", False)]
        self.settings["repositories"] = new_repos
        self._save_settings()
        if name in self.cached_repos_data:
            del self.cached_repos_data[name]
        self.repo_list_changed.emit()

    def _startup_check(self):
        if not self.settings.get("auto_check_updates", True):
            return
        if self.settings.get("check_interval_hours", 24) <= 0:
            return
        self.check_all_repositories(notify_if_found=True)

    def _on_timer_check(self):
        if not self.settings.get("auto_check_updates", True):
            return
        interval_hours = self.settings.get("check_interval_hours", 24)
        if interval_hours <= 0:
            return
        last_check = self.settings.get("last_update_check_timestamp", 0)
        interval_sec = interval_hours * 3600
        if time.time() - last_check >= interval_sec:
            self.check_all_repositories(notify_if_found=True)

    def set_check_interval(self, hours):
        if hours <= 0:
            self.settings["auto_check_updates"] = False
            self.settings["check_interval_hours"] = 0
        else:
            self.settings["auto_check_updates"] = True
            self.settings["check_interval_hours"] = hours
        self._save_settings()

    def check_all_repositories(self, notify_if_found=False, on_complete=None):
        if self._active_worker and self._active_worker.isRunning():
            if on_complete:
                on_complete(self.available_updates, "already checking")
            return

        self.check_started.emit()
        repos = self.get_repositories()
        if not repos:
            self.check_finished.emit([], "")
            if on_complete:
                on_complete([], "")
            return

        installed = self.get_installed_plugins_dict()
        core_ver = self.get_core_version()
        all_updates = []
        repo_errors = []
        repo_idx = 0

        def check_next_repo():
            nonlocal repo_idx
            if repo_idx >= len(repos):
                self.settings["last_update_check_timestamp"] = int(time.time())
                self._save_settings()
                self.sync_installed_status()
                total_updates = self.available_updates + ([self.core_update] if self.core_update else [])

                if total_updates and notify_if_found:
                    self.ktools.notify("updates found")
                    self.updates_found.emit(total_updates)

                err_summary = "; ".join(repo_errors) if len(repo_errors) == len(repos) else ""
                self.check_finished.emit(total_updates, err_summary)
                if on_complete:
                    on_complete(total_updates, err_summary)
                return

            repo_info = repos[repo_idx]
            repo_idx += 1
            worker = RepoCheckWorker(repo_info["url"], installed, core_ver, repo_name=repo_info["name"])
            self._active_worker = worker

            def on_sub_finished(success, err, data, updates):
                if success:
                    self.cached_repos_data[repo_info["name"]] = data
                    for u in updates:
                        if not any(x["id"] == u["id"] for x in all_updates):
                            all_updates.append(u)
                else:
                    repo_errors.append(f"{repo_info['name']}: {err}")
                worker.deleteLater()
                self._active_worker = None
                check_next_repo()

            worker.finished.connect(on_sub_finished)
            worker.start()

        check_next_repo()

    def update_plugin(self, plugin_data, on_progress=None, on_done=None):
        queue = [plugin_data]
        self._run_batch(queue, on_progress=on_progress, on_done=on_done)

    def get_all_pending_updates(self):
        queue = list(self.available_updates)
        if self.core_update and not any(u.get("id") == "ktools" for u in queue):
            queue.append(self.core_update)
        return queue

    def update_all(self, on_progress=None, on_done=None):
        queue = self.get_all_pending_updates()
        if not queue:
            if on_done:
                on_done([])
            return
        self._run_batch(queue, on_progress=on_progress, on_done=on_done)

    def _run_batch(self, queue, on_progress=None, on_done=None):
        if self._batch_worker and self._batch_worker.isRunning():
            return

        worker = BatchUpdateWorker(queue, self.plugins_dir, self.base_dir)
        self._batch_worker = worker

        if on_progress:
            worker.queue_progress.connect(on_progress)

        def on_all_done(results):
            has_core_update = any(r["id"] == "ktools" and r["success"] for r in results)
            self._batch_worker.deleteLater()
            self._batch_worker = None

            if has_core_update:
                if on_done:
                    on_done(results)
                QTimer.singleShot(1200, self.restart_ktools)
            else:
                def after_reload():
                    if on_done:
                        on_done(results)
                self.ktools.reload_all(on_done=after_reload)

        worker.all_finished.connect(on_all_done)
        worker.start()

    def restart_ktools(self):
        try:
            if hasattr(self, "check_timer"):
                self.check_timer.stop()
            if hasattr(self.ktools, "cleanup_timer"):
                self.ktools.cleanup_timer.stop()
            if hasattr(self.ktools, "screen_change_timer"):
                self.ktools.screen_change_timer.stop()
            if hasattr(self.ktools, "hotkey_mgr"):
                self.ktools.hotkey_mgr.unload()
            if hasattr(self.ktools, "screen_notif_center") and hasattr(self.ktools, "notif_observer"):
                self.ktools.screen_notif_center.removeObserver_(self.ktools.notif_observer)
            if hasattr(self.ktools, "dist_center") and hasattr(self.ktools, "notif_observer"):
                self.ktools.dist_center.removeObserver_(self.ktools.notif_observer)
            for p in list(self.ktools.plugins.values()):
                if hasattr(p, "unload"):
                    p.unload()
            if hasattr(self.ktools, "tray") and self.ktools.tray:
                self.ktools.tray.hide()
            if hasattr(self.ktools, "manager") and self.ktools.manager:
                self.ktools.manager.hide()
        except Exception:
            pass

        os.environ.pop("_KTOOLS_DEP_CHECKED", None)

        env = os.environ.copy()
        python = sys.executable
        entry_rel = "main.py"
        inf_path = os.path.join(self.base_dir, "inf.json")
        if os.path.isfile(inf_path):
            try:
                with open(inf_path, "r", encoding="utf-8") as f:
                    inf_d = json.load(f)
                    cand = str(inf_d.get("entrypoint") or inf_d.get("entry") or "main.py").strip()
                    if cand and not os.path.isabs(cand):
                        cand_abs = os.path.abspath(os.path.join(self.base_dir, cand))
                        if os.path.commonpath([self.base_dir, cand_abs]) == self.base_dir and os.path.isfile(cand_abs):
                            entry_rel = cand
            except Exception:
                pass
        main_script = os.path.abspath(os.path.join(self.base_dir, entry_rel))
        if os.path.isfile(main_script) and (not sys.argv or os.path.basename(sys.argv[0]) == "main.py" or not os.path.exists(sys.argv[0])):
            cmd = [python, main_script] + sys.argv[1:]
            launch_cwd = self.base_dir
        else:
            cmd = [python, os.path.abspath(sys.argv[0]) if sys.argv else main_script] + sys.argv[1:]
            launch_cwd = os.getcwd()

        subprocess.Popen(cmd, cwd=launch_cwd, env=env, start_new_session=True)

        app = QApplication.instance()
        if app:
            app.processEvents()
            app.quit()
        QTimer.singleShot(300, lambda: os._exit(0))



class PluginCard(QPushButton):
    def __init__(self, name, is_active=False, has_update=False):
        display_name = name.lower()
        if has_update:
            display_name = f"{display_name} •"
        super().__init__(display_name)
        self.raw_name = name
        self.has_update = has_update
        self.setObjectName("PluginTabBtn")
        self.setCheckable(True)
        self.setChecked(is_active)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

class RepoPluginCardWidget(QFrame):
    def __init__(self, item_id, item_data, manager, parent=None):
        super().__init__(parent)
        self.item_id = item_id
        self.item_data = item_data
        self.manager = manager
        self.setObjectName("RepoPluginCard")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        top_row = QHBoxLayout()
        top_row.setSpacing(10)
        top_row.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        installed_ver = item_data.get("current_version")
        is_installed = (installed_ver is not None)
        remote_ver = item_data.get("version", "1.0.0")
        has_update = item_data.get("update_available", False)

        status_dot = QLabel("●" if is_installed else "○")
        if is_installed:
            status_dot.setStyleSheet("color: #73d216; font-size: 14px;")
        else:
            status_dot.setStyleSheet("color: rgba(255, 255, 255, 80); font-size: 14px;")
        top_row.addWidget(status_dot)

        title_layout = QVBoxLayout()
        title_layout.setSpacing(2)

        name_row = QHBoxLayout()
        name_row.setSpacing(8)

        name_lbl = QLabel(item_data.get("name", item_id).lower())
        name_lbl.setStyleSheet("color: #ffffff; font-family: 'Menlo'; font-size: 13px; font-weight: bold;")
        name_row.addWidget(name_lbl)

        ver_lbl = QLabel(f"v{remote_ver}")
        ver_lbl.setStyleSheet("color: rgba(255, 255, 255, 120); font-family: 'Menlo'; font-size: 11px;")
        name_row.addWidget(ver_lbl)

        if is_installed:
            if has_update:
                status_text = f"[installed: v{installed_ver} -> v{remote_ver}]"
                st_color = "#729fcf"
            else:
                status_text = f"[installed: v{installed_ver}]"
                st_color = "rgba(255, 255, 255, 100)"
        else:
            status_text = "[not installed]"
            st_color = "rgba(255, 255, 255, 80)"

        status_lbl = QLabel(status_text)
        status_lbl.setStyleSheet(f"color: {st_color}; font-family: 'Menlo'; font-size: 11px;")
        name_row.addWidget(status_lbl)
        name_row.addStretch()

        title_layout.addLayout(name_row)

        desc_lbl = QLabel(item_data.get("description", "no description"))
        desc_lbl.setStyleSheet("color: rgba(255, 255, 255, 120); font-family: 'Menlo'; font-size: 11px;")
        desc_lbl.setWordWrap(True)
        title_layout.addWidget(desc_lbl)

        top_row.addLayout(title_layout, stretch=1)

        self.info_btn = QPushButton("info")
        self.info_btn.setObjectName("ActionBtn")
        self.info_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.info_btn.clicked.connect(self.toggle_expanded)
        top_row.addWidget(self.info_btn)

        self.action_btn = QPushButton()
        self.action_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        if not is_installed:
            self.action_btn.setText("install")
            self.action_btn.setObjectName("InstallBtn")
            self.action_btn.clicked.connect(lambda: self.manager.handle_install_or_update_plugin(self.item_data, self.action_btn))
        elif has_update:
            self.action_btn.setText("update")
            self.action_btn.setObjectName("UpdateBtn")
            self.action_btn.clicked.connect(lambda: self.manager.handle_install_or_update_plugin(self.item_data, self.action_btn))
        else:
            self.action_btn.setText("installed")
            self.action_btn.setObjectName("ActionBtn")
            self.action_btn.setEnabled(False)
            self.action_btn.setStyleSheet("color: rgba(255, 255, 255, 80); border-color: rgba(255, 255, 255, 20);")

        top_row.addWidget(self.action_btn)
        layout.addLayout(top_row)

        self.expanded_box = QWidget()
        expanded_layout = QVBoxLayout(self.expanded_box)
        expanded_layout.setContentsMargins(36, 4, 0, 4)
        expanded_layout.setSpacing(6)

        self.readme_browser = QTextBrowser()
        self.readme_browser.setObjectName("PluginReadme")
        self.readme_browser.setOpenExternalLinks(True)
        self.readme_browser.setFrameShape(QFrame.Shape.NoFrame)
        self.readme_browser.setStyleSheet("background: transparent; border: none;")
        self.readme_browser.setFixedHeight(120)
        self.readme_browser.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        raw_readme = item_data.get("readme")
        if raw_readme:
            self.readme_browser.setMarkdown(raw_readme)
        else:
            self.readme_browser.setMarkdown(f"**description:**\n\n{item_data.get('description', 'no description')}")
        expanded_layout.addWidget(self.readme_browser)

        self.screenshots_scroll = QScrollArea()
        self.screenshots_scroll.setFixedHeight(100)
        self.screenshots_scroll.setWidgetResizable(True)
        self.screenshots_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.screenshots_scroll.setStyleSheet("background: transparent;")
        self.screenshots_container = QWidget()
        self.screenshots_layout = QHBoxLayout(self.screenshots_container)
        self.screenshots_layout.setContentsMargins(0, 0, 0, 0)
        self.screenshots_layout.setSpacing(6)
        self.screenshots_scroll.setWidget(self.screenshots_container)

        screenshots = item_data.get("screenshots", [])
        if screenshots:
            expanded_layout.addWidget(self.screenshots_scroll)
            img_urls = []
            for s in screenshots:
                s_url = s
                if not s_url.startswith("http") and item_data.get("raw_root"):
                    s_url = f"{item_data['raw_root']}/{item_id}/{s_url}"
                pix = ImageCache.get_instance().get_pixmap(s_url, max_h=90)
                if pix and not pix.isNull():
                    lbl = QLabel()
                    lbl.setPixmap(pix)
                    lbl.setStyleSheet("border-radius: 6px; border: 1px solid rgba(255,255,255,30);")
                    self.screenshots_layout.addWidget(lbl)
                else:
                    img_urls.append(s_url)
            if img_urls:
                self.scr_worker = ImageDownloadWorker(img_urls)
                def on_scr_img(u, p):
                    try:
                        p_pix = ImageCache.get_instance().get_pixmap(u, max_h=90)
                        if p_pix and not p_pix.isNull():
                            lbl = QLabel()
                            lbl.setPixmap(p_pix)
                            lbl.setStyleSheet("border-radius: 6px; border: 1px solid rgba(255,255,255,30);")
                            self.screenshots_layout.addWidget(lbl)
                    except RuntimeError:
                        pass
                self.scr_worker.image_loaded.connect(on_scr_img)
                self.scr_worker.finished.connect(self.scr_worker.deleteLater)
                self.scr_worker.start()

        self.expanded_box.hide()
        layout.addWidget(self.expanded_box)

    def toggle_expanded(self):
        if self.expanded_box.isVisible():
            self.expanded_box.hide()
            self.info_btn.setText("info")
        else:
            self.expanded_box.show()
            self.info_btn.setText("hide")


class PluginManager(OverlayWindow):
    def __init__(self, ktools_instance):
        super().__init__(ktools_instance, width=780, height=520)
        self.auto_hide = True
        self._prevent_deactivate = False

        self.repo_mgr = getattr(ktools_instance, 'repo_mgr', None)
        if self.repo_mgr is None:
            self.repo_mgr = RepositoryManager(ktools_instance)

        self.active_repo_name = "official"
        self.is_repo_editing = False

        self.root = QWidget()
        self.root.setObjectName("MainContainer")

        self.outer_vbox = QVBoxLayout(self.root)
        self.outer_vbox.setContentsMargins(10, 10, 10, 15)

        self.content_area = QStackedWidget()

        self.plugins_page = QWidget()
        plugins_layout = QVBoxLayout(self.plugins_page)
        plugins_layout.setContentsMargins(0, 0, 0, 0)
        plugins_layout.setSpacing(10)

        self.core_update_banner = QFrame()
        self.core_update_banner.setObjectName("CoreUpdateBanner")
        core_banner_layout = QHBoxLayout(self.core_update_banner)
        core_banner_layout.setContentsMargins(14, 8, 12, 8)
        core_banner_layout.setSpacing(10)

        self.core_update_label = QLabel("ktools update available")
        self.core_update_label.setObjectName("CoreUpdateLabel")
        core_banner_layout.addWidget(self.core_update_label)
        core_banner_layout.addStretch()

        self.core_update_btn = QPushButton("update ktools")
        self.core_update_btn.setObjectName("CoreUpdateBtn")
        self.core_update_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.core_update_btn.clicked.connect(self.handle_update_ktools_core)
        core_banner_layout.addWidget(self.core_update_btn)

        self.core_update_banner.hide()
        plugins_layout.addWidget(self.core_update_banner)

        self.plugin_nav_scroll = QScrollArea()
        self.plugin_nav_scroll.setFixedHeight(45)
        self.plugin_nav_scroll.setWidgetResizable(True)
        self.plugin_nav_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.plugin_nav_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.plugin_nav_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.plugin_nav_scroll.setStyleSheet("background: transparent;")
        self.plugin_nav_scroll.wheelEvent = self.plugin_nav_wheel_event

        self.plugin_nav_container = QWidget()
        self.plugin_list_layout = QHBoxLayout(self.plugin_nav_container)
        self.plugin_list_layout.setContentsMargins(10, 0, 10, 0)
        self.plugin_list_layout.setSpacing(5)
        self.plugin_list_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.plugin_nav_scroll.setWidget(self.plugin_nav_container)

        self.plugin_details_scroll = QScrollArea()
        self.plugin_details_scroll.setWidgetResizable(True)
        self.plugin_details_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.plugin_details_scroll.setStyleSheet("background: transparent;")

        self.plugin_details_stack = QStackedWidget()
        self.info_views = []
        
        for _ in range(2):
            view = QWidget()
            view.setObjectName("PluginDetailsWidget")
            info_layout = QVBoxLayout(view)
            info_layout.setContentsMargins(10, 0, 15, 0) 
            info_layout.setSpacing(10)
            info_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

            header_row = QHBoxLayout()
            header_row.setSpacing(12)
            header_row.setAlignment(Qt.AlignmentFlag.AlignVCenter)

            title_box = QVBoxLayout()
            title_box.setSpacing(2)
            title = QLabel("select a plugin")
            title.setObjectName("PluginTitle")
            title_box.addWidget(title)

            version_badge = QLabel("")
            version_badge.setObjectName("VersionBadge")
            version_badge.setStyleSheet("color: rgba(255, 255, 255, 120); font-family: 'Menlo'; font-size: 11px;")
            title_box.addWidget(version_badge)

            header_row.addLayout(title_box)
            header_row.addStretch()

            update_btn = QPushButton("update")
            update_btn.setObjectName("ActionBtn")
            update_btn.setStyleSheet("color: #729fcf; border-color: rgba(114, 159, 207, 70); padding: 5px 12px;")
            update_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            update_btn.hide()
            header_row.addWidget(update_btn)

            info_layout.addLayout(header_row)

            readme_browser = QTextBrowser()
            readme_browser.setObjectName("PluginReadme")
            readme_browser.setOpenExternalLinks(True)
            readme_browser.setFrameShape(QFrame.Shape.NoFrame)
            readme_browser.setStyleSheet("background: transparent; border: none;")
            readme_browser.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            readme_browser.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            readme_browser.setMinimumHeight(120)
            readme_browser.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            info_layout.addWidget(readme_browser)

            screenshots_scroll = QScrollArea()
            screenshots_scroll.setFixedHeight(105)
            screenshots_scroll.setWidgetResizable(True)
            screenshots_scroll.setFrameShape(QFrame.Shape.NoFrame)
            screenshots_scroll.setStyleSheet("background: transparent;")
            screenshots_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            screenshots_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            screenshots_container = QWidget()
            screenshots_layout = QHBoxLayout(screenshots_container)
            screenshots_layout.setContentsMargins(0, 0, 0, 0)
            screenshots_layout.setSpacing(8)
            screenshots_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            screenshots_scroll.setWidget(screenshots_container)
            screenshots_scroll.hide()
            info_layout.addWidget(screenshots_scroll)

            settings_box = QVBoxLayout() 
            settings_box.setSpacing(8)
            settings_box.setAlignment(Qt.AlignmentFlag.AlignTop)
            info_layout.addLayout(settings_box)
            info_layout.addStretch()
            
            self.plugin_details_stack.addWidget(view)
            self.info_views.append({
                'view': view,
                'header_row': header_row,
                'title': title,
                'version_badge': version_badge,
                'update_btn': update_btn,
                'readme_browser': readme_browser,
                'screenshots_scroll': screenshots_scroll,
                'screenshots_layout': screenshots_layout,
                'settings_box': settings_box
            })

        self.plugin_details_scroll.setWidget(self.plugin_details_stack)

        plugins_layout.addWidget(self.plugin_nav_scroll)
        plugins_layout.addWidget(self.plugin_details_scroll)

        self.content_area.addWidget(self.plugins_page)

        self.repo_page = self.setup_repo_page()
        self.content_area.addWidget(self.repo_page)

        self.settings_page = self.setup_settings_page()
        self.content_area.addWidget(self.settings_page)

        self.log_view = QWidget()
        log_layout = QVBoxLayout(self.log_view)
        log_layout.setContentsMargins(10, 0, 0, 0)
        
        self.log_display = QLabel("")
        self.log_display.setObjectName("DetailsText")
        self.log_display.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.log_display.setWordWrap(True)
        
        log_scroll = QScrollArea()
        log_scroll.setWidgetResizable(True)
        log_scroll.setFrameShape(QFrame.Shape.NoFrame)
        log_scroll.setStyleSheet("background: transparent;")
        log_scroll.setWidget(self.log_display)
        
        log_layout.addWidget(log_scroll)
        self.content_area.addWidget(self.log_view)

        self.nav_btns = []
        for i, name in enumerate(["plugins manager", "repository manager", "ktools settings", "logs"]):
            btn = QPushButton(name)
            btn.setObjectName("BottomNavBtn")
            btn.setCheckable(True)
            btn.clicked.connect(lambda ch, idx=i: self.set_main_tab(idx))
            self.nav_btns.append(btn)

        self.main_nav_scroll = QScrollArea()
        self.main_nav_scroll.setFixedHeight(45)
        self.main_nav_scroll.setWidgetResizable(True)
        self.main_nav_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.main_nav_scroll.setStyleSheet("background: transparent;")
        self.main_nav_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.main_nav_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.main_nav_scroll.wheelEvent = self.main_nav_wheel_event
        
        self.main_nav_container = QWidget()
        self.main_nav_layout = QHBoxLayout(self.main_nav_container)
        self.main_nav_layout.setContentsMargins(10, 0, 10, 0)
        self.main_nav_layout.setSpacing(5)
        self.main_nav_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.main_nav_scroll.setWidget(self.main_nav_container)
        
        for btn in self.nav_btns: 
            self.main_nav_layout.addWidget(btn)

        self.nav_hbox = QHBoxLayout()
        self.nav_hbox.setContentsMargins(0, 0, 0, 0)
        self.nav_hbox.addWidget(self.main_nav_scroll)
        self.nav_hbox.addStretch()

        self.update_all_btn = QPushButton("update all")
        self.update_all_btn.setObjectName("ActionBtn")
        self.update_all_btn.setStyleSheet("color: #729fcf; border-color: rgba(114, 159, 207, 70);")
        self.update_all_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.update_all_btn.clicked.connect(self.handle_update_all)
        self.update_all_btn.hide()

        self.reload_btn = QPushButton("reload plugins")
        self.reload_btn.setObjectName("ActionBtn")
        self.reload_btn.clicked.connect(lambda checked=False: self.ktools.reload_all())

        self.import_btn = QPushButton("import plugins")
        self.import_btn.setObjectName("ActionBtn")
        self.import_btn.clicked.connect(self.handle_import)

        self.nav_hbox.addWidget(self.update_all_btn)
        self.nav_hbox.addWidget(self.import_btn)
        self.nav_hbox.addWidget(self.reload_btn)

        self.progress_container = QWidget()
        self.progress_layout = QVBoxLayout(self.progress_container)
        self.progress_layout.setContentsMargins(10, 0, 10, 5)
        self.progress_layout.setSpacing(4)
        
        self.progress_status_label = QLabel("")
        self.progress_status_label.setObjectName("InstallStatusLabel")
        self.progress_bar = QProgressBar()
        self.progress_bar.setObjectName("InstallProgress")
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(4)
        
        self.progress_layout.addWidget(self.progress_status_label)
        self.progress_layout.addWidget(self.progress_bar)
        self.progress_container.hide()

        self.outer_vbox.addWidget(self.content_area)
        self.outer_vbox.addWidget(self.progress_container)
        self.outer_vbox.addLayout(self.nav_hbox)

        self.setCentralWidget(self.root)

        self.plugin_group = QButtonGroup(self)
        self.plugin_group.setExclusive(True)
        
        self.is_hiding = False
        self.installEventFilter(self)
        self.update_theme()

        self.repo_mgr.updates_found.connect(self.on_updates_found)
        self.repo_mgr.check_finished.connect(self.on_check_finished)
        self.repo_mgr.repo_list_changed.connect(self.refresh_repo_tabs)

    def show_install_progress(self, total):
        self.progress_bar.setRange(0, total)
        self.progress_bar.setValue(0)
        self.progress_status_label.setText("checking dependencies...")
        self.progress_container.show()
        if hasattr(self, 'update_all_btn'):
            self.update_all_btn.setEnabled(False)
        self.import_btn.setEnabled(False)
        self.reload_btn.setEnabled(False)

    def update_install_progress(self, pkg_name, current, total):
        self.progress_bar.setValue(current - 1)
        self.progress_status_label.setText(f"installing {pkg_name} ({current}/{total})...")

    def hide_install_progress(self):
        self.progress_container.hide()
        if hasattr(self, 'update_all_btn'):
            self.update_all_btn.setEnabled(len(self.repo_mgr.get_all_pending_updates()) > 0)
        self.import_btn.setEnabled(True)
        self.reload_btn.setEnabled(True)

    def show_download_progress(self, status_text="downloading..."):
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_status_label.setText(status_text)
        self.progress_container.show()
        if hasattr(self, 'update_all_btn'):
            self.update_all_btn.setEnabled(False)
        self.import_btn.setEnabled(False)
        self.reload_btn.setEnabled(False)

    def update_download_progress(self, done_bytes, total_bytes, speed, status_text):
        if total_bytes > 0:
            percent = int((done_bytes / total_bytes) * 100)
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(percent)
        else:
            self.progress_bar.setRange(0, 0)
        self.progress_status_label.setText(status_text)

    def hide_download_progress(self):
        self.progress_container.hide()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        if hasattr(self, 'update_all_btn'):
            self.update_all_btn.setEnabled(len(self.repo_mgr.get_all_pending_updates()) > 0)
        self.import_btn.setEnabled(True)
        self.reload_btn.setEnabled(True)

    def plugin_nav_wheel_event(self, event):
        delta = event.angleDelta()
        if abs(delta.x()) > abs(delta.y()):
            val = self.plugin_nav_scroll.horizontalScrollBar().value() - delta.x()
        else:
            val = self.plugin_nav_scroll.horizontalScrollBar().value() - delta.y()
        self.plugin_nav_scroll.horizontalScrollBar().setValue(val)

    def main_nav_wheel_event(self, event):
        delta = event.angleDelta()
        if abs(delta.x()) > abs(delta.y()):
            val = self.main_nav_scroll.horizontalScrollBar().value() - delta.x()
        else:
            val = self.main_nav_scroll.horizontalScrollBar().value() - delta.y()
        self.main_nav_scroll.horizontalScrollBar().setValue(val)

    def settings_nav_wheel_event(self, event):
        delta = event.angleDelta()
        if abs(delta.x()) > abs(delta.y()):
            val = self.settings_nav_scroll.horizontalScrollBar().value() - delta.x()
        else:
            val = self.settings_nav_scroll.horizontalScrollBar().value() - delta.y()
        self.settings_nav_scroll.horizontalScrollBar().setValue(val)

    def repo_nav_wheel_event(self, event):
        delta = event.angleDelta()
        if abs(delta.x()) > abs(delta.y()):
            val = self.repo_nav_scroll.horizontalScrollBar().value() - delta.x()
        else:
            val = self.repo_nav_scroll.horizontalScrollBar().value() - delta.y()
        self.repo_nav_scroll.horizontalScrollBar().setValue(val)

    def set_main_tab(self, idx):
        if hasattr(self, "stop_hotkey_recording"):
            self.stop_hotkey_recording()
        if idx < 0 or idx >= self.content_area.count():
            return
            
        old_idx = self.content_area.currentIndex()
        
        if old_idx != idx:
            direction = 1 if old_idx == -1 or idx > old_idx else -1
            
            if old_idx != -1:
                old_widget = self.content_area.widget(old_idx)
                new_widget = self.content_area.widget(idx)
                
                if hasattr(self, 'slide_group') and self.slide_group:
                    if self.slide_group.state() == QParallelAnimationGroup.State.Running:
                        self.slide_group.stop()
                    self.slide_group.deleteLater()
                    self.slide_group = None
                    
                for i in range(self.content_area.count()):
                    if i != old_idx and i != idx:
                        w = self.content_area.widget(i)
                        w.hide()
                        w.move(0, 0)
                
                self.content_area.setCurrentIndex(idx)
                
                old_widget.setGeometry(self.content_area.rect())
                old_widget.show()
                old_widget.raise_()
                new_widget.raise_()
                
                start_x = direction * (self.content_area.width() or 780)
                
                self.slide_group = QParallelAnimationGroup(self)
                
                anim_in = QPropertyAnimation(new_widget, b"pos")
                anim_in.setDuration(250)
                anim_in.setStartValue(QPoint(start_x, 0))
                anim_in.setEndValue(QPoint(0, 0))
                anim_in.setEasingCurve(QEasingCurve.Type.OutQuart)
                
                anim_out = QPropertyAnimation(old_widget, b"pos")
                anim_out.setDuration(250)
                anim_out.setStartValue(QPoint(0, 0))
                anim_out.setEndValue(QPoint(-start_x, 0))
                anim_out.setEasingCurve(QEasingCurve.Type.OutQuart)
                
                self.slide_group.addAnimation(anim_in)
                self.slide_group.addAnimation(anim_out)
                
                def finish_anim(w_old=old_widget):
                    w_old.hide()
                    w_old.move(0, 0)
                    
                self.slide_group.finished.connect(finish_anim)
                self.slide_group.start()
            else:
                self.content_area.setCurrentIndex(idx)
                
        for i, b in enumerate(self.nav_btns):
            b.setChecked(i == idx)

        if idx == 1:
            self.refresh_repo_plugins()
        elif idx == 2:
            self.refresh_deps_tab()
            self.refresh_updates_tab()

    def _clear_layout(self, layout):
        if not layout:
            return
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                for child in widget.findChildren(QWidget):
                    try:
                        child.setParent(None)
                        child.deleteLater()
                    except Exception:
                        pass
                widget.setParent(None)
                widget.deleteLater()
            elif item.layout():
                self._clear_layout(item.layout())

    def refresh_list(self):
        for b in list(self.plugin_group.buttons()):
            self.plugin_group.removeButton(b)
        self._clear_layout(self.plugin_list_layout)
        plugins = self.ktools.get_plugins_info()

        for i, data in enumerate(plugins):
            has_update = any(u.get('id') == data.get('id') for u in self.repo_mgr.available_updates)
            btn = PluginCard(data.get('name', 'unknown'), is_active=(i==0), has_update=has_update)
            self.plugin_group.addButton(btn)
            btn.clicked.connect(lambda checked, d=data, b=btn: self.show_plugin_details(d, b))
            self.plugin_list_layout.addWidget(btn)
        
        if plugins: 
            first_btn = self.plugin_list_layout.itemAt(0).widget()
            self.show_plugin_details(plugins[0], first_btn)

    def show_plugin_details(self, data, active_btn=None):
        self.current_plugin_data = data
        if active_btn:
            self.plugin_nav_scroll.ensureWidgetVisible(active_btn, 50, 0)
            
            target_layout_idx = -1
            for i in range(self.plugin_list_layout.count()):
                item = self.plugin_list_layout.itemAt(i)
                if item and item.widget() == active_btn:
                    target_layout_idx = i
                    break
                    
            current_layout_idx = getattr(self, 'current_plugin_layout_idx', -1)
            
            if target_layout_idx != -1:
                direction = 1 if current_layout_idx == -1 or target_layout_idx > current_layout_idx else -1
                self.current_plugin_layout_idx = target_layout_idx
            else:
                direction = 1
                
            for b in self.plugin_group.buttons():
                b.setChecked(b == active_btn)
        else:
            direction = 1

        old_idx = self.plugin_details_stack.currentIndex()
        new_idx = 1 if old_idx == 0 else 0
        
        target = self.info_views[new_idx]
        target['title'].setText(data.get('name', 'unknown').lower())

        plugin_id = data.get('id', '')
        local_ver = data.get('version', '1.0.0')
        update_item = next((u for u in self.repo_mgr.available_updates if u.get('id') == plugin_id), None)

        if update_item:
            target['version_badge'].setText(f"v{local_ver} -> v{update_item.get('version')} [update available]")
            target['version_badge'].setStyleSheet("color: #729fcf; font-family: 'Menlo'; font-size: 11px; font-weight: bold;")
            target['update_btn'].show()
            try:
                target['update_btn'].clicked.disconnect()
            except Exception:
                pass
            target['update_btn'].clicked.connect(lambda ch, item=update_item, btn=target['update_btn']: self.handle_install_or_update_plugin(item, btn))
        else:
            target['version_badge'].setText(f"v{local_ver}")
            target['version_badge'].setStyleSheet("color: rgba(255, 255, 255, 120); font-family: 'Menlo'; font-size: 11px;")
            try:
                target['update_btn'].clicked.disconnect()
            except Exception:
                pass
            target['update_btn'].hide()

        readme_text = data.get('readme')
        if readme_text:
            target['readme_browser'].setMarkdown(readme_text)
        else:
            deps_str = ', '.join(data.get('deps', [])) if data.get('deps') else 'none'
            fallback_md = (
                f"**author:** `{data.get('author', 'kriaiss')}`  \n"
                f"**version:** `{local_ver}`  \n"
                f"**dependencies:** `{deps_str}`  \n\n"
                f"{data.get('desc', 'no description')}"
            )
            target['readme_browser'].setMarkdown(fallback_md)

        self._clear_layout(target['screenshots_layout'])
        screenshots = data.get('screenshots', [])
        if screenshots:
            target['screenshots_scroll'].show()
            for s in screenshots:
                s_path = s if os.path.isabs(s) else os.path.join(data.get('dir', ''), s)
                pix = ImageCache.get_instance().get_pixmap(s_path, max_h=95)
                if pix and not pix.isNull():
                    scr_lbl = QLabel()
                    scr_lbl.setPixmap(pix)
                    scr_lbl.setStyleSheet("border-radius: 8px; border: 1px solid rgba(255,255,255,30);")
                    target['screenshots_layout'].addWidget(scr_lbl)
        else:
            target['screenshots_scroll'].hide()

        plugin_instance = self.ktools.plugins.get(data.get('id'))
        self._clear_layout(target['settings_box'])

        for setting_name in data.get('settings', []):
            s_btn = QPushButton(setting_name.lower())
            s_btn.setObjectName("ActionBtn")
            s_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            
            if plugin_instance:
                s_btn.clicked.connect(lambda checked, s=setting_name, p=plugin_instance: 
                                      self.handle_setting_click(p, s))
            target['settings_box'].addWidget(s_btn)

        if plugin_instance and hasattr(plugin_instance, 'config_path') and os.path.exists(plugin_instance.config_path):
            cfg_btn = QPushButton("open config.json")
            cfg_btn.setObjectName("ActionBtn")
            cfg_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            cfg_btn.setStyleSheet("color: #729fcf; border-color: rgba(114, 159, 207, 40);")
            cfg_btn.clicked.connect(lambda checked, p=plugin_instance.config_path: subprocess.Popen(["open", "-t", p]))
            target['settings_box'].addWidget(cfg_btn)

        del_btn = QPushButton("delete plugin")
        del_btn.setObjectName("ActionBtn")
        del_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        del_btn.setStyleSheet("color: #ff4444; border-color: rgba(255, 68, 68, 60);")
        del_btn.clicked.connect(lambda: self.ktools.remove_plugin(data.get('id')))
        target['settings_box'].addWidget(del_btn)

        if old_idx != -1:
            old_widget = self.plugin_details_stack.widget(old_idx)
            new_widget = self.plugin_details_stack.widget(new_idx)
            
            if hasattr(self, 'details_slide_group') and self.details_slide_group:
                if self.details_slide_group.state() == QParallelAnimationGroup.State.Running:
                    self.details_slide_group.stop()
                self.details_slide_group.deleteLater()
                self.details_slide_group = None
                
            for i in range(self.plugin_details_stack.count()):
                if i != old_idx and i != new_idx:
                    w = self.plugin_details_stack.widget(i)
                    w.hide()
                    w.move(0, 0)
            
            self.plugin_details_stack.setCurrentIndex(new_idx)
            
            old_widget.setGeometry(self.plugin_details_stack.rect())
            old_widget.show()
            old_widget.raise_()
            new_widget.raise_()
            
            start_x = direction * (self.plugin_details_scroll.width() or 400)
            
            self.details_slide_group = QParallelAnimationGroup(self)
            
            anim_in = QPropertyAnimation(new_widget, b"pos")
            anim_in.setDuration(250)
            anim_in.setStartValue(QPoint(start_x, 0))
            anim_in.setEndValue(QPoint(0, 0))
            anim_in.setEasingCurve(QEasingCurve.Type.OutQuart)
            
            anim_out = QPropertyAnimation(old_widget, b"pos")
            anim_out.setDuration(250)
            anim_out.setStartValue(QPoint(0, 0))
            anim_out.setEndValue(QPoint(-start_x, 0))
            anim_out.setEasingCurve(QEasingCurve.Type.OutQuart)
            
            self.details_slide_group.addAnimation(anim_in)
            self.details_slide_group.addAnimation(anim_out)
            
            def finish_anim(w_old=old_widget):
                w_old.hide()
                w_old.move(0, 0)
                
            self.details_slide_group.finished.connect(finish_anim)
            self.details_slide_group.start()
        else:
            self.plugin_details_stack.setCurrentIndex(new_idx)

        self.plugin_details_scroll.verticalScrollBar().setValue(0)
        if self.content_area.currentIndex() != 0:
            self.set_main_tab(0)

    def setup_repo_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(10, 0, 10, 0)
        top_bar.setSpacing(6)

        self.repo_nav_scroll = QScrollArea()
        self.repo_nav_scroll.setFixedHeight(45)
        self.repo_nav_scroll.setWidgetResizable(True)
        self.repo_nav_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.repo_nav_scroll.setStyleSheet("background: transparent;")
        self.repo_nav_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.repo_nav_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.repo_nav_scroll.wheelEvent = self.repo_nav_wheel_event

        self.repo_tabs_container = QWidget()
        self.repo_tabs_layout = QHBoxLayout(self.repo_tabs_container)
        self.repo_tabs_layout.setContentsMargins(0, 0, 0, 0)
        self.repo_tabs_layout.setSpacing(6)
        self.repo_tabs_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.repo_nav_scroll.setWidget(self.repo_tabs_container)

        top_bar.addWidget(self.repo_nav_scroll, stretch=1)

        self.repo_check_btn = QPushButton("check updates")
        self.repo_check_btn.setObjectName("ActionBtn")
        self.repo_check_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.repo_check_btn.clicked.connect(self.handle_repo_check_updates)
        top_bar.addWidget(self.repo_check_btn)

        self.repo_edit_btn = QPushButton("edit")
        self.repo_edit_btn.setObjectName("ActionBtn")
        self.repo_edit_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.repo_edit_btn.clicked.connect(self.toggle_repo_edit_mode)
        top_bar.addWidget(self.repo_edit_btn)

        layout.addLayout(top_bar)

        self.add_repo_panel = QFrame()
        self.add_repo_panel.setObjectName("AddRepoPanel")
        self.add_repo_panel.setStyleSheet("background: rgba(255,255,255,8); border-radius: 8px; padding: 6px;")
        add_layout = QHBoxLayout(self.add_repo_panel)
        add_layout.setContentsMargins(10, 5, 10, 5)
        add_layout.setSpacing(8)

        self.repo_name_input = QLineEdit()
        self.repo_name_input.setPlaceholderText("name (e.g. community)")
        self.repo_name_input.setStyleSheet("background: rgba(0,0,0,30); border: 1px solid rgba(255,255,255,30); color: #fff; font-family: 'Menlo'; font-size: 12px; padding: 5px; border-radius: 4px;")

        self.repo_url_input = QLineEdit()
        self.repo_url_input.setPlaceholderText("https://example.com/repo or http://192.168.x.x:8000")
        self.repo_url_input.setStyleSheet("background: rgba(0,0,0,30); border: 1px solid rgba(255,255,255,30); color: #fff; font-family: 'Menlo'; font-size: 12px; padding: 5px; border-radius: 4px;")

        self.repo_submit_add_btn = QPushButton("add")
        self.repo_submit_add_btn.setObjectName("ActionBtn")
        self.repo_submit_add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.repo_submit_add_btn.clicked.connect(self.handle_submit_add_repo)

        self.repo_cancel_add_btn = QPushButton("cancel")
        self.repo_cancel_add_btn.setObjectName("ActionBtn")
        self.repo_cancel_add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.repo_cancel_add_btn.clicked.connect(lambda: self.add_repo_panel.hide())

        add_label = QLabel("new repo:")
        add_label.setStyleSheet("color: rgba(255,255,255,140); font-family: 'Menlo'; font-size: 12px;")
        add_layout.addWidget(add_label)
        add_layout.addWidget(self.repo_name_input)
        add_layout.addWidget(self.repo_url_input, stretch=1)
        add_layout.addWidget(self.repo_submit_add_btn)
        add_layout.addWidget(self.repo_cancel_add_btn)
        self.add_repo_panel.hide()
        layout.addWidget(self.add_repo_panel)

        self.repo_plugins_scroll = QScrollArea()
        self.repo_plugins_scroll.setWidgetResizable(True)
        self.repo_plugins_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.repo_plugins_scroll.setStyleSheet("background: transparent;")
        
        self.repo_plugins_container = QWidget()
        self.repo_plugins_layout = QVBoxLayout(self.repo_plugins_container)
        self.repo_plugins_layout.setContentsMargins(10, 0, 15, 0)
        self.repo_plugins_layout.setSpacing(10)
        self.repo_plugins_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.repo_plugins_scroll.setWidget(self.repo_plugins_container)

        layout.addWidget(self.repo_plugins_scroll)

        self.refresh_repo_tabs()
        return page

    def toggle_repo_edit_mode(self):
        self.is_repo_editing = not self.is_repo_editing
        self.repo_edit_btn.setText("done" if self.is_repo_editing else "edit")
        if not self.is_repo_editing:
            self.add_repo_panel.hide()
        self.refresh_repo_tabs()

    def refresh_repo_tabs(self):
        self._clear_layout(self.repo_tabs_layout)
        repos = self.repo_mgr.get_repositories()
        
        for r in repos:
            name = r["name"]
            is_def = r.get("is_default", False)
            is_active = (name.lower() == self.active_repo_name.lower())
            
            tab_btn = QPushButton(f"{name} (default)" if is_def else name)
            tab_btn.setObjectName("PluginTabBtn")
            tab_btn.setCheckable(True)
            tab_btn.setChecked(is_active)
            tab_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            tab_btn.clicked.connect(lambda ch, n=name: self.set_active_repo(n))
            self.repo_tabs_layout.addWidget(tab_btn)

            if self.is_repo_editing and not is_def:
                del_btn = QPushButton("×")
                del_btn.setObjectName("RepoDelBtn")
                del_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                del_btn.clicked.connect(lambda ch, n=name: self.handle_remove_repo(n))
                self.repo_tabs_layout.addWidget(del_btn)

        if self.is_repo_editing:
            add_btn = QPushButton("+ add")
            add_btn.setObjectName("ActionBtn")
            add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            add_btn.clicked.connect(lambda: self.add_repo_panel.setVisible(not self.add_repo_panel.isVisible()))
            self.repo_tabs_layout.addWidget(add_btn)

    def set_active_repo(self, repo_name):
        self.active_repo_name = repo_name
        self.refresh_repo_tabs()
        self.refresh_repo_plugins()

    def refresh_repo_plugins(self):
        if hasattr(self, "repo_mgr") and self.repo_mgr and hasattr(self.repo_mgr, "sync_installed_status"):
            self.repo_mgr.sync_installed_status()
        self._clear_layout(self.repo_plugins_layout)
        repo_data = self.repo_mgr.cached_repos_data.get(self.active_repo_name)
        if not repo_data or "items" not in repo_data:
            empty_lbl = QLabel(f"no items loaded for '{self.active_repo_name}'.\nclick 'check updates' to query the repository.")
            empty_lbl.setStyleSheet("color: rgba(255, 255, 255, 120); font-family: 'Menlo'; font-size: 13px; padding: 20px;")
            empty_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.repo_plugins_layout.addWidget(empty_lbl)
            return

        items = repo_data.get("items", {})
        ordered_items = []
        if "ktools" in items:
            ordered_items.append(("ktools", items["ktools"]))
        for item_id, item_info in items.items():
            if item_id != "ktools":
                ordered_items.append((item_id, item_info))

        for item_id, item_info in ordered_items:
            card = RepoPluginCardWidget(item_id, item_info, self)
            self.repo_plugins_layout.addWidget(card)

        if not ordered_items:
            no_plugs = QLabel("no items found in this repository.")
            no_plugs.setStyleSheet("color: rgba(255, 255, 255, 120); font-family: 'Menlo'; font-size: 13px; padding: 20px;")
            no_plugs.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.repo_plugins_layout.addWidget(no_plugs)

    def handle_submit_add_repo(self):
        name = self.repo_name_input.text().strip()
        url = self.repo_url_input.text().strip()
        if not name or not url:
            self.ktools.notify("please specify both name and URL")
            return

        self.repo_submit_add_btn.setEnabled(False)
        self.show_download_progress("validating repository...")

        def on_done(success, err):
            self.repo_submit_add_btn.setEnabled(True)
            self.hide_download_progress()
            if success:
                self.ktools.notify(f"repository '{name}' added")
                self.repo_name_input.clear()
                self.repo_url_input.clear()
                self.add_repo_panel.hide()
                self.active_repo_name = name
                self.refresh_repo_tabs()
                self.refresh_repo_plugins()
            else:
                self.ktools.notify(f"invalid repository: {err}")

        try:
            self.repo_mgr.add_repository(name, url, on_done=on_done)
        except Exception as e:
            self.hide_download_progress()
            self.repo_submit_add_btn.setEnabled(True)
            self.ktools.notify(f"error: {e}")

    def handle_remove_repo(self, repo_name):
        self.repo_mgr.remove_repository(repo_name)
        self.ktools.notify(f"repository '{repo_name}' removed")
        self.active_repo_name = "official"
        self.refresh_repo_tabs()
        self.refresh_repo_plugins()

    def handle_repo_check_updates(self):
        self.repo_check_btn.setEnabled(False)
        self.repo_check_btn.setText("checking...")
        self.show_download_progress("checking repositories for updates...")

        def on_complete(updates, err):
            self.repo_check_btn.setEnabled(True)
            self.repo_check_btn.setText("check updates")
            self.hide_download_progress()
            self.refresh_repo_plugins()
            self.refresh_update_indicators()
            if updates:
                self.ktools.notify(f"{len(updates)} updates available")
            elif err:
                self.ktools.notify(f"check updates failed: {err}")
            else:
                self.ktools.notify("all plugins up to date")

        self.repo_mgr.check_all_repositories(notify_if_found=False, on_complete=on_complete)

    def handle_install_or_update_plugin(self, item_data, action_btn=None):
        if action_btn:
            action_btn.setEnabled(False)
            action_btn.setText("downloading...")

        plugin_id = item_data.get("id", "plugin")
        self.show_download_progress(f"downloading {plugin_id}...")

        def on_progress(idx, total, item_id, done, total_bytes, speed, status, *args):
            self.update_download_progress(done, total_bytes, speed, status)

        def on_done(results):
            self.hide_download_progress()
            success = any(r.get("success") for r in results)
            if success:
                self.ktools.notify(f"{plugin_id} updated successfully")
                self.refresh_list()
                self.refresh_repo_plugins()
                self.refresh_update_indicators()
                self.refresh_updates_tab()
            else:
                err = results[0].get("error", "unknown error") if results else "failed"
                self.ktools.notify(f"failed to update {plugin_id}: {err}")
                if action_btn:
                    action_btn.setEnabled(True)
                    action_btn.setText("retry")

        self.repo_mgr.update_plugin(item_data, on_progress=on_progress, on_done=on_done)

    def handle_update_all(self):
        queue = self.repo_mgr.get_all_pending_updates()
        if not queue:
            return
        has_core_queued = any(u.get("id") == "ktools" for u in queue)
        if has_core_queued and hasattr(self, "core_update_btn"):
            self.core_update_btn.setEnabled(False)
            self.core_update_btn.setText("downloading...")
        self.show_download_progress("starting batch update...")

        def on_progress(idx, total, item_id, done, total_bytes, speed, status, *args):
            prefix = f"updating ({idx}/{total}): "
            self.update_download_progress(done, total_bytes, speed, prefix + status)

        def on_done(results):
            self.hide_download_progress()
            success_count = sum(1 for r in results if r.get("success"))
            core_ok = any(r.get("id") == "ktools" and r.get("success") for r in results)
            if core_ok:
                self.ktools.notify(f"updated {success_count}/{len(results)} items, restarting...")
            else:
                self.ktools.notify(f"updated {success_count}/{len(results)} items")
                if has_core_queued and hasattr(self, "core_update_btn"):
                    self.core_update_btn.setEnabled(True)
                    self.core_update_btn.setText("update ktools")
            self.refresh_list()
            self.refresh_repo_plugins()
            self.refresh_update_indicators()
            self.refresh_updates_tab()

        self.repo_mgr.update_all(on_progress=on_progress, on_done=on_done)

    def handle_update_ktools_core(self):
        if not self.repo_mgr.core_update:
            return
        self.core_update_btn.setEnabled(False)
        self.core_update_btn.setText("downloading...")
        self.show_download_progress("downloading ktools core update...")

        def on_progress(idx, total, item_id, done, total_bytes, speed, status, *args):
            self.update_download_progress(done, total_bytes, speed, status)

        def on_done(results):
            self.hide_download_progress()
            success = any(r.get("success") for r in results)
            if success:
                self.ktools.notify("ktools updated, restarting...")
                self.refresh_update_indicators()
                self.refresh_updates_tab()
            else:
                err = results[0].get("error") if results else "failed"
                self.ktools.notify(f"core update failed: {err}")
                self.core_update_btn.setEnabled(True)
                self.core_update_btn.setText("update ktools")

        self.repo_mgr.update_plugin(self.repo_mgr.core_update, on_progress=on_progress, on_done=on_done)

    def refresh_update_indicators(self):
        if hasattr(self, "repo_mgr") and self.repo_mgr and hasattr(self.repo_mgr, "sync_installed_status"):
            self.repo_mgr.sync_installed_status()
        if self.repo_mgr.core_update:
            cur_ver = self.repo_mgr.get_core_version()
            new_ver = self.repo_mgr.core_update.get("version", "unknown")
            self.core_update_label.setText(f"ktools update available: v{cur_ver} -> v{new_ver}")
            self.core_update_banner.show()
        else:
            self.core_update_banner.hide()

        up_count = len(self.repo_mgr.get_all_pending_updates())
        if up_count > 0:
            self.update_all_btn.setText(f"update all ({up_count})")
            self.update_all_btn.show()
            self.update_all_btn.setEnabled(True)
        else:
            self.update_all_btn.hide()

        plugins = self.ktools.get_plugins_info()
        for i in range(self.plugin_list_layout.count()):
            item = self.plugin_list_layout.itemAt(i)
            if item and item.widget() and i < len(plugins):
                btn = item.widget()
                p_id = plugins[i].get("id")
                has_up = any(u.get("id") == p_id for u in self.repo_mgr.available_updates)
                raw_n = plugins[i].get("name", "unknown").lower()
                btn.setText(f"{raw_n} •" if has_up else raw_n)

        if hasattr(self, 'current_plugin_data') and self.current_plugin_data and hasattr(self, 'plugin_details_stack'):
            cur_idx = self.plugin_details_stack.currentIndex()
            if hasattr(self, 'info_views') and cur_idx < len(self.info_views):
                target = self.info_views[cur_idx]
                p_id = self.current_plugin_data.get('id', '')
                local_ver = self.current_plugin_data.get('version', '1.0.0')
                update_item = next((u for u in self.repo_mgr.available_updates if u.get('id') == p_id), None)
                if update_item:
                    target['version_badge'].setText(f"v{local_ver} -> v{update_item.get('version')} [update available]")
                    target['version_badge'].setStyleSheet("color: #729fcf; font-family: 'Menlo'; font-size: 11px; font-weight: bold;")
                    target['update_btn'].show()
                    try:
                        target['update_btn'].clicked.disconnect()
                    except Exception:
                        pass
                    target['update_btn'].clicked.connect(lambda ch, item=update_item, btn=target['update_btn']: self.handle_install_or_update_plugin(item, btn))
                else:
                    target['version_badge'].setText(f"v{local_ver}")
                    target['version_badge'].setStyleSheet("color: rgba(255, 255, 255, 120); font-family: 'Menlo'; font-size: 11px;")
                    target['update_btn'].hide()

    def on_updates_found(self, updates):
        self.refresh_update_indicators()
        self.refresh_repo_plugins()
        self.refresh_updates_tab()

    def on_check_finished(self, updates, err):
        self.refresh_update_indicators()
        self.refresh_repo_plugins()
        self.refresh_updates_tab()

    def setup_settings_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(15)

        self.settings_nav_scroll = QScrollArea()
        self.settings_nav_scroll.setFixedHeight(45)
        self.settings_nav_scroll.setWidgetResizable(True)
        self.settings_nav_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.settings_nav_scroll.setStyleSheet("background: transparent;")
        self.settings_nav_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.settings_nav_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.settings_nav_scroll.wheelEvent = self.settings_nav_wheel_event

        self.settings_nav_container = QWidget()
        self.settings_menu_layout = QHBoxLayout(self.settings_nav_container)
        self.settings_menu_layout.setContentsMargins(10, 0, 10, 0)
        self.settings_menu_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.settings_menu_layout.setSpacing(5)
        
        self.settings_nav_scroll.setWidget(self.settings_nav_container)

        settings_tabs = ["updates", "dependency manager", "hotkey manager", "about"]
        self.settings_btns = []
        self.settings_group = QButtonGroup(self)
        self.settings_group.setExclusive(True)

        for i, name in enumerate(settings_tabs):
            btn = QPushButton(name)
            btn.setObjectName("PluginTabBtn")
            btn.setCheckable(True)
            btn.setChecked(i == 0)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda ch, idx=i: self.set_settings_tab(idx))
            
            self.settings_btns.append(btn)
            self.settings_group.addButton(btn)
            self.settings_menu_layout.addWidget(btn)

        self.settings_stack = QStackedWidget()

        self.tab_updates = QWidget()
        updates_layout = QVBoxLayout(self.tab_updates)
        updates_layout.setContentsMargins(10, 0, 0, 0)
        updates_layout.setSpacing(12)

        updates_header = QHBoxLayout()
        updates_title = QLabel("updates")
        updates_title.setObjectName("PluginTitle")
        updates_header.addWidget(updates_title)
        updates_header.addStretch()

        self.updates_check_now_btn = QPushButton("check now")
        self.updates_check_now_btn.setObjectName("ActionBtn")
        self.updates_check_now_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.updates_check_now_btn.clicked.connect(self.handle_updates_tab_check)
        updates_header.addWidget(self.updates_check_now_btn)
        updates_layout.addLayout(updates_header)

        updates_card = QFrame()
        updates_card.setObjectName("RepoPluginCard")
        card_layout = QVBoxLayout(updates_card)
        card_layout.setContentsMargins(16, 14, 16, 14)
        card_layout.setSpacing(10)

        row_interval = QHBoxLayout()
        interval_label = QLabel("check for updates")
        interval_label.setObjectName("DetailsText")
        row_interval.addWidget(interval_label)
        row_interval.addStretch()

        self.update_interval_combo = QComboBox()
        self.update_interval_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        interval_options = [
            ("never", 0),
            ("2 hours", 2),
            ("12 hours", 12),
            ("24 hours", 24),
            ("48 hours", 48),
            ("week", 168),
            ("2 weeks", 336),
            ("month", 720)
        ]
        for label, hours in interval_options:
            self.update_interval_combo.addItem(label, hours)

        self._sync_update_interval_combo()
        self.update_interval_combo.currentIndexChanged.connect(self.handle_update_interval_changed)
        row_interval.addWidget(self.update_interval_combo)
        card_layout.addLayout(row_interval)

        row_status = QHBoxLayout()
        self.updates_last_check_label = QLabel("")
        self.updates_last_check_label.setObjectName("DetailsText")
        row_status.addWidget(self.updates_last_check_label)
        row_status.addStretch()

        self.updates_status_badge = QLabel("")
        self.updates_status_badge.setObjectName("DetailsText")
        row_status.addWidget(self.updates_status_badge)
        card_layout.addLayout(row_status)

        updates_layout.addWidget(updates_card)

        self.updates_scroll = QScrollArea()
        self.updates_scroll.setWidgetResizable(True)
        self.updates_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.updates_scroll.setStyleSheet("background: transparent;")

        self.updates_list_container = QWidget()
        self.updates_list_vbox = QVBoxLayout(self.updates_list_container)
        self.updates_list_vbox.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.updates_list_vbox.setSpacing(6)
        self.updates_scroll.setWidget(self.updates_list_container)

        updates_layout.addWidget(self.updates_scroll)

        self.tab_deps = QWidget()
        deps_layout = QVBoxLayout(self.tab_deps)
        deps_layout.setContentsMargins(10, 0, 0, 0)
        
        deps_header = QHBoxLayout()
        deps_title = QLabel("dependency manager")
        deps_title.setObjectName("PluginTitle")
        deps_header.addWidget(deps_title)
        deps_header.addStretch()

        self.clean_deps_btn = QPushButton("clean unused")
        self.clean_deps_btn.setObjectName("ActionBtn")
        self.clean_deps_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.clean_deps_btn.clicked.connect(self.handle_clean_unused_deps)
        deps_header.addWidget(self.clean_deps_btn)
        
        self.deps_list_scroll = QScrollArea()
        self.deps_list_scroll.setWidgetResizable(True)
        self.deps_list_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.deps_list_scroll.setStyleSheet("background: transparent;")
        
        self.deps_list_container = QWidget()
        self.deps_list_vbox = QVBoxLayout(self.deps_list_container)
        self.deps_list_vbox.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.deps_list_scroll.setWidget(self.deps_list_container)
        
        deps_layout.addLayout(deps_header)
        deps_layout.addWidget(self.deps_list_scroll)

        self.tab_hotkeys = QWidget()
        hotkeys_layout = QVBoxLayout(self.tab_hotkeys)
        hotkeys_layout.setContentsMargins(10, 0, 0, 0)
        hotkeys_layout.setSpacing(10)

        hotkeys_header = QHBoxLayout()
        hotkeys_title = QLabel("hotkey manager")
        hotkeys_title.setObjectName("PluginTitle")
        hotkeys_header.addWidget(hotkeys_title)
        hotkeys_header.addStretch()

        self.hotkeys_conflict_badge = QLabel("")
        self.hotkeys_conflict_badge.setObjectName("DetailsText")
        self.hotkeys_conflict_badge.setStyleSheet("color: #ff5555; font-size: 11px;")
        self.hotkeys_conflict_badge.hide()
        hotkeys_header.addWidget(self.hotkeys_conflict_badge)

        self.hotkeys_scroll = QScrollArea()
        self.hotkeys_scroll.setWidgetResizable(True)
        self.hotkeys_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.hotkeys_scroll.setStyleSheet("background: transparent;")

        self.hotkeys_container = QWidget()
        self.hotkeys_vbox = QVBoxLayout(self.hotkeys_container)
        self.hotkeys_vbox.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.hotkeys_vbox.setSpacing(6)
        self.hotkeys_scroll.setWidget(self.hotkeys_container)

        hotkeys_layout.addLayout(hotkeys_header)
        hotkeys_layout.addWidget(self.hotkeys_scroll)

        self.tab_about = self._create_settings_info("about", f"ktools engine v{self.repo_mgr.get_core_version()}\ndeveloped by kriaiss\ncake is a lie\n\nminimalistic plugin api and manager for macos\n\n>you are entirely on your own with the third-party plugins you download or create.\nif a poorly written script hangs your system or your setup starts acting up,\ndon't look at me! it's all on you. :3")

        self.settings_stack.addWidget(self.tab_updates)
        self.settings_stack.addWidget(self.tab_deps)
        self.settings_stack.addWidget(self.tab_hotkeys)
        self.settings_stack.addWidget(self.tab_about)

        layout.addWidget(self.settings_nav_scroll)
        layout.addWidget(self.settings_stack)
        
        self.refresh_updates_tab()
        return page

    def set_settings_tab(self, idx):
        if hasattr(self, "stop_hotkey_recording"):
            self.stop_hotkey_recording()
        if idx < 0 or idx >= self.settings_stack.count():
            return
            
        old_idx = self.settings_stack.currentIndex()
        
        if old_idx != idx:
            direction = 1 if old_idx == -1 or idx > old_idx else -1
            
            if old_idx != -1:
                old_widget = self.settings_stack.widget(old_idx)
                new_widget = self.settings_stack.widget(idx)
                
                if hasattr(self, 'settings_slide_group') and self.settings_slide_group:
                    if self.settings_slide_group.state() == QParallelAnimationGroup.State.Running:
                        self.settings_slide_group.stop()
                    self.settings_slide_group.deleteLater()
                    self.settings_slide_group = None
                    
                for i in range(self.settings_stack.count()):
                    if i != old_idx and i != idx:
                        w = self.settings_stack.widget(i)
                        w.hide()
                        w.move(0, 0)
                
                self.settings_stack.setCurrentIndex(idx)
                
                old_widget.setGeometry(self.settings_stack.rect())
                old_widget.show()
                old_widget.raise_()
                new_widget.raise_()
                
                start_x = direction * (self.settings_stack.width() or 780)
                
                self.settings_slide_group = QParallelAnimationGroup(self)
                
                anim_in = QPropertyAnimation(new_widget, b"pos")
                anim_in.setDuration(250)
                anim_in.setStartValue(QPoint(start_x, 0))
                anim_in.setEndValue(QPoint(0, 0))
                anim_in.setEasingCurve(QEasingCurve.Type.OutQuart)
                
                anim_out = QPropertyAnimation(old_widget, b"pos")
                anim_out.setDuration(250)
                anim_out.setStartValue(QPoint(0, 0))
                anim_out.setEndValue(QPoint(-start_x, 0))
                anim_out.setEasingCurve(QEasingCurve.Type.OutQuart)
                
                self.settings_slide_group.addAnimation(anim_in)
                self.settings_slide_group.addAnimation(anim_out)
                
                def finish_anim(w_old=old_widget):
                    w_old.hide()
                    w_old.move(0, 0)
                    
                self.settings_slide_group.finished.connect(finish_anim)
                self.settings_slide_group.start()
            else:
                self.settings_stack.setCurrentIndex(idx)
                
        for i, b in enumerate(self.settings_btns):
            b.setChecked(i == idx)
        if idx == 1:
            self.refresh_hotkeys_tab()

    def _create_settings_info(self, title, text):
        w = QWidget()
        l = QVBoxLayout(w)
        l.setContentsMargins(10, 0, 0, 0)
        t = QLabel(title)
        t.setObjectName("PluginTitle")
        d = QLabel(text)
        d.setObjectName("DetailsText")
        l.addWidget(t)
        l.addWidget(d)
        l.addStretch()
        return w

    def handle_clean_unused_deps(self):
        self.ktools.dep_mgr.cleanup_unused()
        self.refresh_deps_tab()
        self.ktools.notify("unused packages cleaned")

    def _sync_update_interval_combo(self):
        auto_check = self.repo_mgr.settings.get("auto_check_updates", True)
        curr_hours = self.repo_mgr.settings.get("check_interval_hours", 24)
        target = 0 if not auto_check or curr_hours <= 0 else curr_hours
        found = 0
        for i in range(self.update_interval_combo.count()):
            if self.update_interval_combo.itemData(i) == target:
                found = i
                break
        self.update_interval_combo.blockSignals(True)
        self.update_interval_combo.setCurrentIndex(found)
        self.update_interval_combo.blockSignals(False)

    def handle_update_interval_changed(self, idx):
        hours = self.update_interval_combo.itemData(idx)
        if hours is not None:
            self.repo_mgr.set_check_interval(hours)

    def handle_updates_tab_check(self):
        self.updates_check_now_btn.setEnabled(False)
        self.updates_status_badge.setText("checking...")
        self.updates_status_badge.setStyleSheet("color: #e5a50a; font-size: 11px;")

        def on_done(updates, err):
            self.updates_check_now_btn.setEnabled(True)
            self.refresh_updates_tab()

        self.repo_mgr.check_all_repositories(notify_if_found=True, on_complete=on_done)

    def refresh_updates_tab(self):
        if not hasattr(self, "update_interval_combo"):
            return
        self._sync_update_interval_combo()
        last_ts = self.repo_mgr.settings.get("last_update_check_timestamp", 0)
        if last_ts > 0:
            time_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(last_ts))
            self.updates_last_check_label.setText(f"last check: {time_str}")
        else:
            self.updates_last_check_label.setText("last check: never")

        self._clear_layout(self.updates_list_vbox)
        updates = self.repo_mgr.available_updates
        core_up = self.repo_mgr.core_update
        total = list(updates)
        if core_up:
            total.append(core_up)

        if not total:
            self.updates_status_badge.setText("all plugins up to date")
            self.updates_status_badge.setStyleSheet("color: #73d216; font-size: 11px;")
            no_up = QLabel("no pending updates")
            no_up.setObjectName("DetailsText")
            self.updates_list_vbox.addWidget(no_up)
        else:
            self.updates_status_badge.setText(f"{len(total)} update(s) available")
            self.updates_status_badge.setStyleSheet("color: #729fcf; font-size: 11px;")
            for u in total:
                row = QFrame()
                row.setObjectName("RepoPluginCard")
                r_layout = QHBoxLayout(row)
                r_layout.setContentsMargins(12, 8, 12, 8)
                lbl = QLabel(f"{u.get('name', u.get('id', 'item'))} ({u.get('current_version', '')} -> {u.get('version', '')})")
                lbl.setObjectName("DetailsText")
                r_layout.addWidget(lbl)
                r_layout.addStretch()
                up_btn = QPushButton("update")
                up_btn.setObjectName("UpdateBtn")
                up_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                up_btn.clicked.connect(lambda ch, item=u, btn=up_btn: self.handle_install_or_update_plugin(item, btn))
                r_layout.addWidget(up_btn)
                self.updates_list_vbox.addWidget(row)

    def refresh_hotkeys_tab(self):
        if not hasattr(self, 'hotkeys_vbox'):
            return

        self._clear_layout(self.hotkeys_vbox)

        if not hasattr(self.ktools, 'hotkey_mgr'):
            return

        items = self.ktools.hotkey_mgr.get_items()
        conflicts = self.ktools.hotkey_mgr.get_conflicts()

        if conflicts:
            conflict_count = len(conflicts)
            self.hotkeys_conflict_badge.setText(f"{conflict_count} conflict{'s' if conflict_count > 1 else ''} detected")
            self.hotkeys_conflict_badge.show()
        else:
            self.hotkeys_conflict_badge.hide()

        if not items:
            lbl = QLabel("no plugin hotkeys registered")
            lbl.setObjectName("DetailsText")
            lbl.setStyleSheet("margin-top: 10px; opacity: 0.5;")
            self.hotkeys_vbox.addWidget(lbl)
            return

        for it in items:
            key = it["key"]
            plugin_name = it["plugin_name"]
            action_id = it["action_id"]
            current_hk = it["current_hotkey"]
            default_hk = it["default_hotkey"]
            is_conflicting = self.ktools.hotkey_mgr.is_item_conflicting(it)
            is_recording = getattr(self, "recording_action_key", None) == key

            row_widget = QWidget()
            row = QHBoxLayout(row_widget)
            row.setContentsMargins(0, 4, 10, 4)
            row.setSpacing(8)

            display_label = f"{it['label']} ({plugin_name})"
            if is_conflicting:
                other_items = self.ktools.hotkey_mgr.get_item_conflicts(it)
                other_names = ", ".join(f"{o['plugin_name']}" for o in other_items)
                display_label = f"{it['label']} ({plugin_name}) (conflict with {other_names})"

            lbl = QLabel(display_label)
            lbl.setObjectName("DetailsText")
            if is_conflicting:
                lbl.setStyleSheet("color: #ff4444;")
            row.addWidget(lbl)
            row.addStretch()

            hk_btn = QPushButton()
            hk_btn.setObjectName("ActionBtn")
            hk_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            hk_btn.setFixedHeight(22)
            hk_btn.setMinimumWidth(90)

            if is_recording:
                hk_btn.setText("recording...")
                hk_btn.setStyleSheet("color: #5599ff; font-size: 11px; border-color: rgba(85, 153, 255, 100);")
            elif is_conflicting:
                disp_text = format_display_hotkey(current_hk)
                hk_btn.setText(disp_text)
                hk_btn.setStyleSheet("color: #ff4444; font-size: 11px; border-color: rgba(255, 68, 68, 60);")
            else:
                disp_text = format_display_hotkey(current_hk) if current_hk else "unassigned"
                hk_btn.setText(disp_text)
                if not current_hk:
                    hk_btn.setStyleSheet("opacity: 0.4; font-size: 11px;")
                else:
                    hk_btn.setStyleSheet("font-size: 11px;")

            hk_btn.clicked.connect(lambda ch, k=key: self.start_hotkey_recording(k))
            row.addWidget(hk_btn)

            if current_hk != default_hk:
                reset_btn = QPushButton("reset")
                reset_btn.setObjectName("ActionBtn")
                reset_btn.setFixedSize(50, 22)
                reset_btn.setStyleSheet("font-size: 10px;")
                reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                reset_btn.clicked.connect(lambda ch, p=plugin_name, a=action_id: self.reset_hotkey(p, a))
                row.addWidget(reset_btn)

            if current_hk:
                clear_btn = QPushButton("✕")
                clear_btn.setObjectName("ActionBtn")
                clear_btn.setFixedSize(22, 22)
                clear_btn.setStyleSheet("font-size: 10px;")
                clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                clear_btn.clicked.connect(lambda ch, p=plugin_name, a=action_id: self.clear_hotkey(p, a))
                row.addWidget(clear_btn)

            self.hotkeys_vbox.addWidget(row_widget)

    def start_hotkey_recording(self, action_key):
        if getattr(self, "recording_action_key", None) == action_key:
            self.stop_hotkey_recording()
            self.refresh_hotkeys_tab()
            return

        self.recording_action_key = action_key
        if hasattr(self.ktools, "hotkey_mgr"):
            self.ktools.hotkey_mgr.is_recording = True

        if not hasattr(self, "_hotkey_filter"):
            parent_window = self
            class HotkeyCaptureFilter(QObject):
                def eventFilter(self, obj, event):
                    rec_key = getattr(parent_window, "recording_action_key", None)
                    if rec_key:
                        if event.type() == QEvent.Type.KeyPress:
                            if event.key() == Qt.Key.Key_Escape:
                                parent_window.stop_hotkey_recording()
                                parent_window.refresh_hotkeys_tab()
                                return True

                            if event.key() in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete) and not event.modifiers():
                                item = parent_window.ktools.hotkey_mgr.items.get(rec_key)
                                if item:
                                    p = item.get("plugin_name")
                                    a = item.get("action_id")
                                else:
                                    p, a = rec_key.rsplit(".", 1)
                                parent_window.ktools.hotkey_mgr.clear_hotkey(p, a)
                                parent_window.stop_hotkey_recording()
                                parent_window.refresh_hotkeys_tab()
                                return True

                            modifier_keys = {
                                Qt.Key.Key_Control, Qt.Key.Key_Shift, Qt.Key.Key_Alt, Qt.Key.Key_Meta,
                                Qt.Key.Key_AltGr, Qt.Key.Key_Super_L, Qt.Key.Key_Super_R,
                                Qt.Key.Key_Hyper_L, Qt.Key.Key_Hyper_R, Qt.Key.Key_CapsLock
                            }
                            if event.key() in modifier_keys:
                                return True

                            hk_str = parent_window.ktools.hotkey_mgr.key_event_to_hotkey(event)
                            if hk_str:
                                item = parent_window.ktools.hotkey_mgr.items.get(rec_key)
                                if item:
                                    p = item.get("plugin_name")
                                    a = item.get("action_id")
                                else:
                                    p, a = rec_key.rsplit(".", 1)
                                parent_window.ktools.hotkey_mgr.set_hotkey(p, a, hk_str)
                                parent_window.stop_hotkey_recording()
                                parent_window.refresh_hotkeys_tab()
                                return True
                        elif event.type() == QEvent.Type.MouseButtonPress:
                            if isinstance(obj, QPushButton):
                                pass
                            else:
                                parent_window.stop_hotkey_recording()
                                parent_window.refresh_hotkeys_tab()
                    return super().eventFilter(obj, event)

            self._hotkey_filter = HotkeyCaptureFilter()

        app_inst = QApplication.instance()
        if app_inst:
            app_inst.installEventFilter(self._hotkey_filter)

        self.refresh_hotkeys_tab()

    def stop_hotkey_recording(self):
        self.recording_action_key = None
        if hasattr(self.ktools, "hotkey_mgr"):
            self.ktools.hotkey_mgr.is_recording = False
        app_inst = QApplication.instance()
        if app_inst and hasattr(self, "_hotkey_filter"):
            try:
                app_inst.removeEventFilter(self._hotkey_filter)
            except Exception:
                pass

    def reset_hotkey(self, plugin_name, action_id):
        self.stop_hotkey_recording()
        if hasattr(self.ktools, "hotkey_mgr"):
            self.ktools.hotkey_mgr.reset_hotkey(plugin_name, action_id)
        self.refresh_hotkeys_tab()

    def clear_hotkey(self, plugin_name, action_id):
        self.stop_hotkey_recording()
        if hasattr(self.ktools, "hotkey_mgr"):
            self.ktools.hotkey_mgr.clear_hotkey(plugin_name, action_id)
        self.refresh_hotkeys_tab()

    def refresh_deps_tab(self):
        self._clear_layout(self.deps_list_vbox)

        plugin_deps_map = self.ktools.dep_mgr.get_plugin_dependencies_map()
        direct_plugin_deps = set()
        for deps in plugin_deps_map.values():
            for d in deps:
                direct_plugin_deps.add(normalize_name(d))

        all_plugin_needed = resolve_transitive_dependencies(direct_plugin_deps)

        installed = get_installed_distributions()

        items_to_display = []
        seen = set()

        # hide 150 background pyobjc frameworks
        primary_core = ["pyqt6", "pyobjc-framework-cocoa", "pyobjc-framework-quartz"]
        for c in primary_core:
            norm = normalize_name(c)
            if norm in installed and norm not in seen:
                seen.add(norm)
                items_to_display.append({
                    "name": installed[norm].lower(),
                    "real_name": installed[norm],
                    "status": "core",
                    "can_delete": False
                })

        for p in sorted(direct_plugin_deps):
            norm = normalize_name(p)
            if norm in seen:
                continue
            seen.add(norm)
            if norm in installed:
                items_to_display.append({
                    "name": installed[norm].lower(),
                    "real_name": installed[norm],
                    "status": "in use",
                    "can_delete": True
                })
            else:
                items_to_display.append({
                    "name": p.lower(),
                    "real_name": p,
                    "status": "missing",
                    "can_delete": False
                })

        for norm, real_name in sorted(installed.items()):
            if norm in seen or is_system_package(norm):
                continue
            if norm not in all_plugin_needed:
                seen.add(norm)
                items_to_display.append({
                    "name": real_name.lower(),
                    "real_name": real_name,
                    "status": "unused",
                    "can_delete": True
                })

        items_to_display.sort(key=lambda x: x["name"])

        if not items_to_display:
            lbl = QLabel("no external plugin packages installed")
            lbl.setObjectName("DetailsText")
            lbl.setStyleSheet("margin-top: 10px; opacity: 0.5;")
            self.deps_list_vbox.addWidget(lbl)
            return

        for item in items_to_display:
            row_widget = QWidget()
            row = QHBoxLayout(row_widget)
            row.setContentsMargins(0, 4, 10, 4)

            display_text = item["name"]
            if item["status"] == "unused":
                display_text = f"{item['name']} (unused)"
            elif item["status"] == "missing":
                display_text = f"{item['name']} (missing)"

            lbl = QLabel(display_text)
            lbl.setObjectName("DetailsText")
            row.addWidget(lbl)
            row.addStretch()

            if item["can_delete"]:
                del_btn = QPushButton("delete")
                del_btn.setFixedSize(60, 22)
                del_btn.setObjectName("ActionBtn")
                del_btn.setStyleSheet("color: #ff4444; font-size: 10px; border-color: rgba(255,68,68,40);")
                del_btn.clicked.connect(lambda ch, p=item["real_name"]: self.uninstall_package(p))
                row.addWidget(del_btn)

            self.deps_list_vbox.addWidget(row_widget)

    def uninstall_package(self, pkg_name):
        norm = normalize_name(pkg_name)
        if is_system_package(norm) and norm in {normalize_name(p) for p in core_deps}:
            print(f"dependency manager: cannot uninstall core dependency: {pkg_name}")
            self.ktools.notify(f"cannot remove core: {pkg_name}")
            return
        print(f"dependency manager: manual uninstall: {pkg_name}")
        cmd = self.ktools.dep_mgr.pip_cmd + ["uninstall", "-y", pkg_name]
        subprocess.run(cmd, capture_output=True)
        importlib.invalidate_caches()
        self.refresh_deps_tab()
        self.ktools.notify(f"removed {pkg_name}")

    def toggle(self):
        self.ktools.toggle_plugin("kmanager")

    def hide_anim(self):
        self.stop_hotkey_recording()
        super().hide_anim()

    def _on_anim_finished(self):
        was_hiding = getattr(self, "is_hiding", False)
        super()._on_anim_finished()
        if was_hiding:
            ImageCache.get_instance().clear_memory()

    def closeEvent(self, event):
        self.stop_hotkey_recording()
        ImageCache.get_instance().clear_memory()
        super().closeEvent(event)

    def update_theme(self):
        defaults = NSUserDefaults.standardUserDefaults()
        is_dark = defaults.stringForKey_("AppleInterfaceStyle") == "Dark" if defaults else True
        self.setStyleSheet(get_theme(is_dark) + self.extra_styles(is_dark))
        apply_liquid_glass(self, radius=24.0, force=True)
        self.style().unpolish(self.root)
        self.style().polish(self.root)
        self.root.update()
        for i in range(self.plugin_list_layout.count()):
            it = self.plugin_list_layout.itemAt(i)
            if it and it.widget():
                it.widget().style().unpolish(it.widget())
                it.widget().style().polish(it.widget())
                it.widget().update()
        self.refresh_hotkeys_tab()

    def extra_styles(self, is_dark):
        bg = "transparent"
        text = "#ffffff" if is_dark else "#000000"
        border = "rgba(255,255,255,15)" if is_dark else "rgba(0,0,0,5)"
        st = "rgba(255,255,255,120)" if is_dark else "rgba(0,0,0,120)"
        btn = "rgba(255,255,255,15)" if is_dark else "rgba(0,0,0,5)"
        item_hover = "rgba(255,255,255,25)" if is_dark else "rgba(0,0,0,15)"
        view_bg = "#1e1e1e" if is_dark else "#f0f0f0"
        
        return f"""
            QWidget#MainContainer {{
                background: {bg};
                border-radius: 24px;
                border: 1px solid {border};
            }}

            QPushButton#ActionBtn {{
                text-align: center; background: {btn}; border: 1px solid {border};
                color: {text}; font-family: 'Menlo'; font-size: 12px; padding: 6px; border-radius: 6px;
            }}
            QPushButton#ActionBtn:hover {{ background: transparent; }}

            QPushButton#BottomNavBtn {{
                background: transparent; border: none; color: {st}; font-family: 'Menlo'; font-size: 13px; padding: 5px 10px;
            }}
            QPushButton#BottomNavBtn:checked {{ color: {text}; border-bottom: 2px solid {text}; }}
            
            QLabel#DetailsText {{ color: {st}; font-family: 'Menlo'; font-size: 13px; }}

            QProgressBar#InstallProgress {{
                border: none;
                border-radius: 2px;
                background: {btn};
                height: 4px;
            }}
            QProgressBar#InstallProgress::chunk {{
                background: {text};
                border-radius: 2px;
            }}
            QLabel#InstallStatusLabel {{
                color: {st};
                font-family: 'Menlo';
                font-size: 11px;
            }}
            QTextBrowser#PluginReadme {{
                background: transparent;
                border: none;
                color: {st};
                font-family: 'Menlo';
                font-size: 12px;
            }}
            QFrame#RepoPluginCard {{
                background: {btn};
                border: 1px solid {border};
                border-radius: 10px;
            }}
            QFrame#CoreUpdateBanner {{
                background: {btn};
                border: 1px solid {border};
                border-radius: 10px;
                margin: 2px 15px 0px 10px;
            }}
            QLabel#CoreUpdateLabel {{
                color: {text};
                font-family: 'Menlo';
                font-size: 12px;
            }}
            QPushButton#CoreUpdateBtn {{
                background: {btn};
                border: 1px solid {border};
                color: {text};
                font-family: 'Menlo';
                font-size: 11px;
                font-weight: bold;
                padding: 5px 12px;
                border-radius: 6px;
            }}
            QPushButton#CoreUpdateBtn:hover {{
                background: {item_hover};
            }}
            QPushButton#UpdateBtn {{
                background: rgba(114, 159, 207, 30);
                border: 1px solid rgba(114, 159, 207, 70);
                color: #729fcf;
                font-family: 'Menlo';
                font-size: 11px;
                padding: 4px 10px;
                border-radius: 5px;
            }}
            QPushButton#InstallBtn {{
                background: rgba(100, 220, 100, 30);
                border: 1px solid rgba(100, 220, 100, 70);
                color: #73d216;
                font-family: 'Menlo';
                font-size: 11px;
                padding: 4px 10px;
                border-radius: 5px;
            }}
            QPushButton#RepoDelBtn {{
                background: transparent;
                border: none;
                color: #ff5555;
                font-family: 'Menlo';
                font-size: 15px;
                font-weight: bold;
                padding: 0 4px;
            }}
            QComboBox {{
                background: {btn};
                border: 1px solid {border};
                color: {text};
                font-family: 'Menlo';
                font-size: 12px;
                padding: 4px 10px;
                border-radius: 6px;
                min-width: 140px;
            }}
            QComboBox:hover {{
                border: 1px solid {st};
            }}
            QComboBox::drop-down {{
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 20px;
                border: none;
            }}
            QComboBox::down-arrow {{
                width: 0;
                height: 0;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 5px solid {text};
                margin-right: 6px;
            }}
            QComboBox QAbstractItemView {{
                background: {view_bg};
                color: {text};
                border: 1px solid {border};
                border-radius: 6px;
                padding: 4px;
                selection-background-color: {item_hover};
                selection-color: {text};
                outline: none;
                font-family: 'Menlo';
                font-size: 12px;
            }}
            QComboBox QAbstractItemView::item {{
                min-height: 24px;
                padding: 4px 8px;
                border-radius: 4px;
            }}
            QComboBox QAbstractItemView::item:selected {{
                background-color: {item_hover};
            }}
        """

    def event(self, event):
        if event.type() == QEvent.Type.WindowDeactivate:
            if hasattr(self, "stop_hotkey_recording"):
                self.stop_hotkey_recording()
            if getattr(self, "_prevent_deactivate", False):
                return super().event(event)
            if not self.auto_hide:
                return super().event(event)
            if getattr(self.ktools, 'is_switching', False):
                return super().event(event)
            if self.is_hiding:
                return super().event(event)
            if self.windowOpacity() < 0.95:
                return super().event(event)
            if self.isVisible():
                self.hide_anim()
        return super().event(event)
    
    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.hide_anim()
        super().keyPressEvent(event)

    def handle_setting_click(self, plugin, setting_name):
        method_name = setting_name.lower().replace(" ", "_")

        if hasattr(plugin, method_name):
            method = getattr(plugin, method_name)
            method()
        else:
            if hasattr(plugin, "on_setting"):
                plugin.on_setting(setting_name)
            else:
                print(f"ktools: plugin dont know what {setting_name} is")

    def add_log(self, message):
        time_str = QTime.currentTime().toString("HH:mm:ss")
        current_text = self.log_display.text()

        lines = (current_text + f"\n[{time_str}] {message}").split('\n')
        self.log_display.setText("\n".join(lines[-100:])) 

        parent_scroll = self.log_display.parent().parent()
        if isinstance(parent_scroll, QScrollArea):
            QTimer.singleShot(10, lambda: parent_scroll.verticalScrollBar().setValue(
                parent_scroll.verticalScrollBar().maximum()
            ))

    def handle_import(self):
        self._prevent_deactivate = True
        try:
            file_path, _ = QFileDialog.getOpenFileName(
                self, "select plugin zip", "", "Zip files (*.zip)"
            )
        finally:
            def restore_deactivate():
                self._prevent_deactivate = False
                if self.isVisible():
                    self.raise_()
                    self.activateWindow()
            QTimer.singleShot(250, restore_deactivate)

        if not file_path:
            return

        try:
            plugins_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "plugins"))
            os.makedirs(plugins_dir, exist_ok=True)

            plugin_name = None
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                names = [n for n in zip_ref.namelist() if not n.startswith("__MACOSX/") and not os.path.basename(n).startswith("._")]

                if "inf.json" in names:
                    try:
                        inf_data = json.loads(zip_ref.read("inf.json").decode("utf-8"))
                        plugin_name = inf_data.get("id") or inf_data.get("name")
                    except Exception:
                        pass
                else:
                    inf_matches = [n for n in names if n.endswith("/inf.json") and n.count("/") == 1]
                    if len(inf_matches) == 1:
                        try:
                            inf_data = json.loads(zip_ref.read(inf_matches[0]).decode("utf-8"))
                            plugin_name = inf_data.get("id") or inf_data.get("name") or inf_matches[0].split("/")[0]
                        except Exception:
                            plugin_name = inf_matches[0].split("/")[0]

            if not plugin_name:
                clean_top = [n.split("/")[0] for n in names if n and not n.startswith(".") and not n.startswith("__MACOSX")]
                unique_top = list(dict.fromkeys(clean_top))
                if len(unique_top) == 1:
                    plugin_name = unique_top[0]
                else:
                    plugin_name = os.path.splitext(os.path.basename(file_path))[0]

            plugin_name = SecurityValidator.sanitize_name(plugin_name)
            target_dir = os.path.abspath(os.path.join(plugins_dir, plugin_name))
            SafeArchiveExtractor.extract(file_path, target_dir)
            imported_names = [plugin_name]

            self.ktools.notify(f"imported: {', '.join(imported_names)}")
            self.ktools.reload_all()
        except Exception as e:
            self.ktools.notify("import error")
            print(f"ktools: import error: {e}")


class DependencyManager:
    def __init__(self, ktools_instance):
        self.ktools = ktools_instance
        self.pip_cmd = [sys.executable, "-m", "pip"]
        self.is_installing = False
        self.worker = None
        self._install_callbacks = []

    def get_plugin_dependencies_map(self):
        plugin_deps_map = {}
        base_path = os.path.dirname(os.path.abspath(__file__))
        p_dir = os.path.join(base_path, "plugins")
        if not os.path.exists(p_dir):
            return {}
        for name in os.listdir(p_dir):
            if name.startswith(".") or name == "__MACOSX":
                continue
            inf_path = os.path.join(p_dir, name, "inf.json")
            if os.path.exists(inf_path):
                try:
                    with open(inf_path, "r", encoding="utf-8") as f:
                        inf = json.load(f)
                        deps = inf.get("dependencies", [])
                        if isinstance(deps, list):
                            clean = [str(d).strip() for d in deps if str(d).strip() and str(d).lower() != "no deps"]
                            plugin_deps_map[name] = clean
                except Exception:
                    continue
        return plugin_deps_map

    def get_all_plugin_dependencies(self):
        deps_map = self.get_plugin_dependencies_map()
        all_deps = set()
        for deps in deps_map.values():
            for d in deps:
                all_deps.add(d)
        return all_deps

    def get_missing_plugin_dependencies(self):
        all_deps = self.get_all_plugin_dependencies()
        installed = get_installed_distributions()
        missing = []
        for d in all_deps:
            if normalize_name(d) not in installed:
                missing.append(d)
        return sorted(list(set(missing)))

    def is_package_installed(self, pkg_name):
        installed = get_installed_distributions()
        return normalize_name(pkg_name) in installed

    def check_and_install_missing(self, on_done=None):
        missing = self.get_missing_plugin_dependencies()
        if not missing:
            if on_done:
                on_done()
            return
        self.install_packages(missing, on_done=on_done)

    def _flush_callbacks(self):
        cbs = list(self._install_callbacks)
        self._install_callbacks.clear()
        for cb in cbs:
            try:
                cb()
            except Exception as e:
                print(f"dependency manager callback error: {e}")

    def install_packages(self, to_install, on_done=None):
        if on_done:
            self._install_callbacks.append(on_done)
        if self.is_installing:
            return
        if not to_install:
            self._flush_callbacks()
            return
        self.is_installing = True
        print(f"dependency manager: starting installation of: {to_install}")
        self.ktools.notify(f"installing {len(to_install)} dependencies...")

        if hasattr(self.ktools, "manager"):
            self.ktools.manager.show_install_progress(len(to_install))

        self.worker = InstallWorker(self, to_install)
        if hasattr(self.ktools, "manager"):
            self.worker.package_started.connect(self.ktools.manager.update_install_progress)
        self.worker.finished.connect(self._on_install_finished)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker.start()

    def _on_install_finished(self, installed_pkgs, failed_pkgs):
        self.is_installing = False
        importlib.invalidate_caches()
        if hasattr(self.ktools, "manager"):
            self.ktools.manager.hide_install_progress()
        if installed_pkgs:
            print(f"dependency manager: {len(installed_pkgs)} pkgs installed")
        if failed_pkgs:
            print(f"dependency manager: failed to install: {failed_pkgs}")
            self.ktools.notify(f"failed to install: {', '.join(failed_pkgs)}")
        self._flush_callbacks()

    def cleanup_unused(self):
        if sys.prefix == sys.base_prefix:
            print("dependency manager: outside venv, skipping cleanup")
            return

        installed_map = get_installed_distributions()
        protected = {normalize_name(p) for p in core_deps + base_deps}
        plugin_deps = self.get_all_plugin_dependencies()

        root_needed = list(protected) + list(plugin_deps)
        all_needed = resolve_transitive_dependencies(root_needed)

        unused_to_uninstall = []
        for norm_name, real_name in installed_map.items():
            # never uninstall system packages during cleanup
            if is_system_package(norm_name):
                continue
            if norm_name not in all_needed:
                unused_to_uninstall.append(real_name)

        if unused_to_uninstall:
            print(f"dependency manager: aggressive cleanup of unused packages: {unused_to_uninstall}")
            cmd = self.pip_cmd + ["uninstall", "-y"] + unused_to_uninstall
            res = subprocess.run(cmd, capture_output=True, text=True)
            if res.returncode == 0:
                print("dependency manager: cleanup finished")
            else:
                print(f"dependency manager: cleanup error: {res.stderr}")
            importlib.invalidate_caches()


class ktools:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setQuitOnLastWindowClosed(False)
        self.menu_filter = KToolsMenuFilter()
        self.app.installEventFilter(self.menu_filter)
        self.app._ktools_menu_filtered = True

        def custom_excepthook(exc_type, exc_value, exc_traceback):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            import traceback
            tb = traceback.extract_tb(exc_traceback)
            plugins_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")
            culprit = None
            for frame in tb:
                if frame.filename.startswith(plugins_path):
                    rel = os.path.relpath(frame.filename, plugins_path)
                    parts = rel.split(os.sep)
                    if parts:
                        culprit = parts[0]
                        break
            if culprit and hasattr(self, 'plugins') and culprit in self.plugins:
                err_msg = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
                QTimer.singleShot(0, lambda: self.isolate_plugin_crash(culprit, err_msg))

        sys.excepthook = custom_excepthook
        
        try:
            import AppKit
            AppKit.NSApplication.sharedApplication().setActivationPolicy_(AppKit.NSApplicationActivationPolicyAccessory)
        except Exception: pass
        self.plugins = {}
        self.last_active_app = None
        self.is_switching = False
        self.is_reloading = False
        self.active_toasts = []

        self.dep_mgr = DependencyManager(self) 
        self.hotkey_mgr = HotkeyManager(self)
        self.app.aboutToQuit.connect(self.hotkey_mgr.unload)
        self.repo_mgr = RepositoryManager(self)

        self.manager = PluginManager(self)
        self.apply_global_native_flags(self.manager, is_overlay=True)
        self.setup_tray()

        self.log_emitter = LogEmitter()
        self.log_emitter.sig_log.connect(self.manager.add_log)
        
        sys.stdout = LogStream(self.log_emitter, sys.stdout)
        sys.stderr = LogStream(self.log_emitter, sys.stderr)

        self.hotkey_mgr.load()

        self.cleanup_timer = QTimer(self.app)
        self.cleanup_timer.timeout.connect(self._run_maintenance)
        self.cleanup_timer.start(300000)

        self.screen_change_timer = QTimer(self.app)
        self.screen_change_timer.setSingleShot(True)
        self.screen_change_timer.timeout.connect(self._handle_screens_reconfigured)

        self.app.screenAdded.connect(self._schedule_screen_reconfiguration)
        self.app.screenRemoved.connect(self._schedule_screen_reconfiguration)
        self.app.primaryScreenChanged.connect(self._schedule_screen_reconfiguration)
        for s in self.app.screens():
            s.geometryChanged.connect(self._schedule_screen_reconfiguration)
            s.availableGeometryChanged.connect(self._schedule_screen_reconfiguration)

        self.notif_observer = KToolsNotificationObserver.alloc().initWithKtools_(self)

        try:
            from AppKit import NSNotificationCenter
            self.screen_notif_center = NSNotificationCenter.defaultCenter()
            self.screen_notif_center.addObserver_selector_name_object_(
                self.notif_observer, "onScreenParametersChanged:", "NSApplicationDidChangeScreenParametersNotification", None
            )
        except Exception:
            pass

        self.reload_all()
        print("ktools: engine started")

        try:
            from AppKit import NSDistributedNotificationCenter
            self.dist_center = NSDistributedNotificationCenter.defaultCenter()
            self.dist_center.addObserver_selector_name_object_(
                self.notif_observer, "updateSystemTheme:", "AppleInterfaceThemeChangedNotification", None
            )
        except Exception as e:
            print(f"ktools: failed to register theme notification observer: {e}")

    def _schedule_screen_reconfiguration(self, *args):
        if hasattr(self, 'screen_change_timer') and self.screen_change_timer:
            self.screen_change_timer.start(250)

    def _handle_screens_reconfigured(self):
        for s in self.app.screens():
            try:
                s.geometryChanged.disconnect(self._schedule_screen_reconfiguration)
                s.availableGeometryChanged.disconnect(self._schedule_screen_reconfiguration)
            except Exception:
                pass
            s.geometryChanged.connect(self._schedule_screen_reconfiguration)
            s.availableGeometryChanged.connect(self._schedule_screen_reconfiguration)

        self.rearrange_toasts()

        if hasattr(self, 'manager') and self.manager and self.manager.isVisible():
            try:
                screen = QGuiApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
                if screen:
                    sgeo = screen.availableGeometry()
                    target_x = sgeo.center().x() - int(self.manager.width() / 2)
                    target_y = sgeo.center().y() - int(self.manager.height() / 2)
                    self.manager.end_pos = QPoint(target_x, target_y)
                    self.manager.move(self.manager.end_pos)
            except Exception:
                pass

        for name, plugin in list(self.plugins.items()):
            if hasattr(plugin, "on_screen_changed"):
                try:
                    plugin.on_screen_changed()
                except Exception as e:
                    print(f"ktools: screen update error in {name}: {e}")

    def update_theme(self):
        try:
            defaults = NSUserDefaults.standardUserDefaults()
            is_dark = defaults.stringForKey_("AppleInterfaceStyle") == "Dark" if defaults else True

            if hasattr(self, 'manager') and self.manager:
                self.manager.update_theme()

            if hasattr(self, 'menu') and self.menu:
                self.menu.setStyleSheet(get_theme(is_dark))

            for toast in list(self.active_toasts):
                if hasattr(toast, 'update_theme'):
                    toast.update_theme()

            for plugin_name, plugin_inst in list(self.plugins.items()):
                if hasattr(plugin_inst, 'update_theme'):
                    try:
                        plugin_inst.update_theme()
                    except Exception as e:
                        print(f"ktools: error updating theme for {plugin_name}: {e}")
        except Exception as e:
            print(f"ktools: error during theme update: {e}")

    def _run_maintenance(self):
        try:
            with objc.autorelease_pool():
                pass
        except Exception:
            pass
        gc.collect()

    def pre_scan_dependencies(self):
        return self.dep_mgr.get_plugin_dependencies_map()

    # i love mac os 27 :) another crash fix
    def setup_tray(self):
        self.tray = QSystemTrayIcon()
        icon = QIcon(os.path.join(os.path.dirname(__file__), "iconTemplate.png"))
        icon.setIsMask(True)
        self.tray.setIcon(icon)
        self.menu = QMenu()

        self.menu.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.menu.setWindowFlags(self.menu.windowFlags() | Qt.WindowType.FramelessWindowHint | Qt.WindowType.NoDropShadowWindowHint)

        self.refresh_menu()
        
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    def _on_tray_activated(self, reason):
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.Context):

            # update styles on open
            defaults = NSUserDefaults.standardUserDefaults()
            is_dark = defaults.stringForKey_("AppleInterfaceStyle") == "Dark" if defaults else True
            self.menu.setStyleSheet(get_theme(is_dark))

            self.refresh_menu()
            self.menu.popup(QCursor.pos())

    def refresh_menu(self):
        self.menu.clear()
        act_mgr = QAction("plugin manager", self.menu)
        act_mgr.triggered.connect(self.manager.toggle)
        self.menu.addAction(act_mgr)
        self.menu.addSeparator()
        
        for name, inst in self.plugins.items():
            if hasattr(inst, "get_actions"):
                try:
                    for act in inst.get_actions():
                        if act:
                            self.menu.addAction(act)
                except Exception:
                    pass
        
        self.menu.addSeparator()
        act_reload = QAction("reload plugins", self.menu)
        act_reload.triggered.connect(self.reload_all)
        self.menu.addAction(act_reload)
        
        act_exit = QAction("exit", self.menu)
        act_exit.triggered.connect(self.app.quit)
        self.menu.addAction(act_exit)

    def load_plugins(self):
        base_path = os.path.dirname(os.path.abspath(__file__))
        p_dir = os.path.join(base_path, "plugins")
        
        if not os.path.exists(p_dir): return

        for name in os.listdir(p_dir):
            if name.startswith(".") or name == "__MACOSX":
                continue
            path = os.path.join(p_dir, name)
            if os.path.isdir(path):
                py_file = os.path.join(path, f"{name}.py")
                inf_file = os.path.join(path, "inf.json")
                if os.path.isfile(inf_file):
                    try:
                        with open(inf_file, "r", encoding="utf-8") as f:
                            inf_d = json.load(f)
                            cand = str(inf_d.get("entrypoint") or inf_d.get("entry") or "").strip()
                            if cand and not os.path.isabs(cand):
                                cand_abs = os.path.abspath(os.path.join(path, cand))
                                if os.path.commonpath([path, cand_abs]) == path and os.path.isfile(cand_abs):
                                    py_file = cand_abs
                    except Exception:
                        pass
                if os.path.exists(py_file):
                    try:
                        self._import_plugin(name, py_file, path)
                        print(f"ktools: {name} loaded")
                    except Exception as e:
                        print(f"ktools: {name} failed: {e}")
    def _import_plugin(self, name, path, plugin_dir=None):
        try:
            if "ktools_plugins" not in sys.modules:
                pkg = types.ModuleType("ktools_plugins")
                pkg.__path__ = []
                sys.modules["ktools_plugins"] = pkg
            mod_name = f"ktools_plugins.{name}"
            for loaded_k in list(sys.modules.keys()):
                if loaded_k == mod_name or loaded_k.startswith(mod_name + "."):
                    del sys.modules[loaded_k]
            search_dir = plugin_dir or os.path.dirname(os.path.abspath(path))
            spec = importlib.util.spec_from_file_location(mod_name, path, submodule_search_locations=[search_dir])
            mod = importlib.util.module_from_spec(spec)
            sys.modules[mod_name] = mod
            spec.loader.exec_module(mod)
            
            if hasattr(mod, "Plugin"): 
                plugin_instance = mod.Plugin(self)
                self.plugins[name] = plugin_instance
                target_win = getattr(plugin_instance, 'shell', getattr(plugin_instance, 'window', getattr(plugin_instance, 'monitor', None)))
                target_layer = getattr(plugin_instance, 'layer', 'overlay')
                if target_win:
                    self.apply_global_native_flags(target_win, is_overlay=(target_layer == 'overlay'))
        except Exception as e: 
            print(f"ktools: {name} failed to import: {e}")

    def reload_all(self, on_done=None):
        self.is_reloading = True
        print("\nktools: --- reload start ---")

        for p in list(self.plugins.values()):
            try:
                if hasattr(p, 'unload'):
                    p.unload()
            except Exception:
                pass
            try:
                target_win = getattr(p, 'shell', getattr(p, 'window', getattr(p, 'monitor', None)))
                if target_win:
                    try:
                        if hasattr(target_win, 'anim_group') and target_win.anim_group:
                            target_win.anim_group.stop()
                        if hasattr(target_win, 'desktop_anim_group') and target_win.desktop_anim_group:
                            target_win.desktop_anim_group.stop()
                        target_win.hide()
                        target_win.close()
                        target_win.deleteLater()
                    except Exception:
                        pass
            except Exception:
                pass
        self.plugins.clear()

        for key in list(sys.modules.keys()):
            if key.startswith("ktools_plugins."):
                del sys.modules[key]

        app = QApplication.instance()
        if app:
            app.sendPostedEvents(None, int(QEvent.Type.DeferredDelete))
            app.processEvents()

        def finish_callback():
            self._finish_reload()
            if callable(on_done):
                on_done()

        missing = self.dep_mgr.get_missing_plugin_dependencies()
        if missing or self.dep_mgr.is_installing:
            if missing:
                print(f"ktools: missing dependencies: {missing}")
            self.dep_mgr.install_packages(missing, on_done=finish_callback)
            return

        finish_callback()

    def _finish_reload(self):
        self.load_plugins()
        if hasattr(self, 'hotkey_mgr'):
            try:
                self.hotkey_mgr.reload()
            except Exception:
                try:
                    self.hotkey_mgr.unload()
                    self.hotkey_mgr = HotkeyManager(self)
                    self.hotkey_mgr.load()
                except Exception:
                    pass
        self.refresh_menu()
        if hasattr(self, 'manager'):
            self.manager.refresh_list()
            self.manager.refresh_deps_tab()
            self.manager.refresh_hotkeys_tab()
            if hasattr(self.manager, 'refresh_repo_plugins'):
                self.manager.refresh_repo_plugins()
            if hasattr(self.manager, 'refresh_update_indicators'):
                self.manager.refresh_update_indicators()
            if hasattr(self.manager, 'refresh_updates_tab'):
                self.manager.refresh_updates_tab()
            
        self.is_reloading = False

        app = QApplication.instance()
        if app:
            app.sendPostedEvents(None, int(QEvent.Type.DeferredDelete))
            app.processEvents()

        gc.collect()
        print(f"ktools: objects in memory: {len(gc.get_objects())}")

        print(f"ktools: reload finished. plugins: {len(self.plugins)}")
        self.notify("plugins reloaded")

    def notify(self, text):
        toast = KToast(text, self.active_toasts)
        
        primary = QApplication.primaryScreen()
        screen = primary.availableGeometry() if primary else None
        start_x = (screen.x() + (screen.width() - toast.width()) // 2) if screen else ((1920 - toast.width()) // 2)
        start_y = (screen.y() + screen.height()) if screen else 1080
        toast.move(start_x, start_y)
        toast.show()

        self.active_toasts.insert(0, toast)

        QTimer.singleShot(10, toast._apply_native_flags)
        
        self.rearrange_toasts()
        QTimer.singleShot(4000, toast.hide_anim)
        toast.destroyed.connect(self.rearrange_toasts)

    def rearrange_toasts(self, *args):
        for i, toast in enumerate(self.active_toasts):
            try:
                toast.update_position(i)
            except RuntimeError:
                pass

    def toggle_plugin(self, plugin_name):
        target_win = None
        target_layer = 'overlay'
        
        if plugin_name == "kmanager":
            target_win = self.manager
            target_layer = 'overlay'
        else:
            p = self.plugins.get(plugin_name)
            if p:
                target_win = getattr(p, 'shell', getattr(p, 'window', getattr(p, 'monitor', None)))
                target_layer = getattr(p, 'layer', 'overlay')

        if not target_win:
            return
            
        if hasattr(target_win, 'anim_group') and target_win.anim_group.state() == QParallelAnimationGroup.State.Running:
            return

        is_visible = target_win.isVisible()
        if hasattr(target_win, 'windowOpacity'):
            is_visible = is_visible and target_win.windowOpacity() > 0.1

        if is_visible:
            if hasattr(target_win, 'hide_anim'): target_win.hide_anim()
            else: target_win.hide()
        else:
            closed_other = False
            if target_layer == 'overlay':
                closed_other = self.request_show(plugin_name)

            delay = 120 if closed_other else 0
            is_ov = (target_layer == 'overlay')
            QTimer.singleShot(delay, lambda: self._execute_show(target_win, is_overlay=is_ov))

    def request_show(self, plugin_name):
        self.is_switching = True
        QTimer.singleShot(600, self._release_switching)
        
        try:
            ws = NSWorkspace.sharedWorkspace()
            active = ws.frontmostApplication()
            if active and active.processIdentifier() != os.getpid():
                self.last_active_app = active
        except Exception:
            pass
            
        closed_other = False
        for name, plugin in self.plugins.items():
            if name == plugin_name: continue
            layer = getattr(plugin, 'layer', 'overlay')
            if layer == 'overlay':
                win = getattr(plugin, 'shell', getattr(plugin, 'window', getattr(plugin, 'monitor', None)))
                if win and win.isVisible():
                    if hasattr(win, 'hide_anim'): win.hide_anim()
                    else: win.hide()
                    closed_other = True
                    
        if plugin_name != "kmanager" and hasattr(self, 'manager') and self.manager.isVisible():
            if hasattr(self.manager, 'hide_anim'):
                self.manager.hide_anim()
            else:
                self.manager.hide()
            closed_other = True

        return closed_other

    def _execute_show(self, target_win, is_overlay=True):
        if is_overlay:
            try:
                screen = QGuiApplication.screenAt(QCursor.pos())
                if not screen:
                    screen = QApplication.primaryScreen()
                screen_geo = screen.availableGeometry()
                
                if getattr(target_win, 'auto_center', True):
                    target_x = screen_geo.center().x() - int(target_win.width() / 2)
                    target_y = screen_geo.center().y() - int(target_win.height() / 2)

                    y_offset = -24
                    if hasattr(target_win, 'start_pos') and hasattr(target_win, 'end_pos'):
                        y_offset = target_win.start_pos.y() - target_win.end_pos.y()
                    
                    target_win.end_pos = QPoint(target_x, target_y)
                    target_win.start_pos = QPoint(target_x, target_y + y_offset)
                    target_win.move(target_win.start_pos)
            except Exception as e:
                print(f"ktools: failed to auto-center overlay: {e}")

        if hasattr(target_win, 'show_anim'):
            target_win.show_anim()
        else:
            target_win.show()
            
        target_win.raise_()
        target_win.activateWindow()
            
        try:
            self.apply_global_native_flags(target_win, is_overlay=is_overlay)
        except Exception: pass

    def _release_switching(self):
        self.is_switching = False

    def apply_global_native_flags(self, window, retries=10, is_overlay=False):
        try:
            view_ptr = int(window.winId())
            import objc
            ns_view = objc.objc_object(c_void_p=view_ptr)
            ns_win = ns_view.window()
            if ns_win:
                from AppKit import (
                    NSWindowCollectionBehaviorCanJoinAllSpaces,
                    NSWindowCollectionBehaviorMoveToActiveSpace,
                    NSWindowCollectionBehaviorStationary,
                    NSWindowCollectionBehaviorIgnoresCycle,
                    NSWindowCollectionBehaviorFullScreenAuxiliary,
                    NSStatusWindowLevel,
                    NSApplication
                )
                behavior = (
                    NSWindowCollectionBehaviorStationary | 
                    NSWindowCollectionBehaviorIgnoresCycle |
                    NSWindowCollectionBehaviorFullScreenAuxiliary
                )
                if is_overlay:
                    behavior |= NSWindowCollectionBehaviorMoveToActiveSpace
                    ns_win.setCollectionBehavior_(behavior)
                    ns_win.setLevel_(NSStatusWindowLevel + 1)
                    ns_win.setHidesOnDeactivate_(False)
                    if window.isVisible():
                        app = NSApplication.sharedApplication()
                        if app:
                            app.activateIgnoringOtherApps_(True)
                        ns_win.makeKeyAndOrderFront_(None)
                        window.activateWindow()
                else:
                    behavior |= NSWindowCollectionBehaviorCanJoinAllSpaces
                    ns_win.setCollectionBehavior_(behavior)
                    ns_win.setLevel_(-2147483601)
                    ns_win.setHidesOnDeactivate_(False)
                    ns_win.orderBack_(None)
                    
                apply_liquid_glass(window, radius=24.0)
            else:
                if retries > 0:
                    QTimer.singleShot(20, lambda: self.apply_global_native_flags(window, retries - 1, is_overlay))
        except Exception as e:
            print(f"ktools: failed to apply native flags: {e}")

    def _app_has_windows_on_current_space(self, pid):
        try:
            import Quartz
            options = Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements
            window_list = Quartz.CGWindowListCopyWindowInfo(options, Quartz.kCGNullWindowID)
            for window in window_list:
                if window.get(Quartz.kCGWindowOwnerPID) == pid:
                    if window.get(Quartz.kCGWindowLayer, 0) == 0:
                        return True
            return False
        except Exception:
            return True

    def restore_focus(self):
        if self.is_switching:
            return
            
        if getattr(self, 'skip_focus_restore', False):
            self.skip_focus_restore = False
            self.last_active_app = None
            return
            
        if self.last_active_app:
            try:
                from AppKit import NSWorkspace, NSApplicationActivateIgnoringOtherApps
                ws = NSWorkspace.sharedWorkspace()
                curr_app = ws.frontmostApplication()
                if curr_app and curr_app.processIdentifier() == os.getpid():
                    pid = self.last_active_app.processIdentifier()
                    
                    if self._app_has_windows_on_current_space(pid):
                        self.last_active_app.activateWithOptions_(NSApplicationActivateIgnoringOtherApps)
                    else:
                        for app in ws.runningApplications():
                            if app.bundleIdentifier() == "com.apple.finder":
                                app.activateWithOptions_(NSApplicationActivateIgnoringOtherApps)
                                break
                    
                    self.last_active_app = None
            except Exception:
                pass

    def reset_switching(self):
        self.is_switching = False

    def get_plugins_info(self):
        info_list = []
        p_dir = os.path.join(os.path.dirname(__file__), "plugins")
        if not os.path.exists(p_dir): return info_list

        for name in os.listdir(p_dir):
            if name.startswith(".") or name == "__MACOSX":
                continue
            plugin_path = os.path.join(p_dir, name)
            inf_path = os.path.join(plugin_path, "inf.json")
            if os.path.isfile(inf_path):
                try:
                    with open(inf_path, "r", encoding='utf-8') as f:
                        d = json.load(f)
                        info_list.append({
                            "id": name,
                            "name": d.get("name", name),
                            "author": d.get("author", "unknown"),
                            "version": d.get("version", "1.0.0"),
                            "ktools_v": d.get("ktools_version", "1.0.0"),
                            "desc": d.get("description", "no description"),
                            "readme": d.get("readme", ""),
                            "preview": d.get("preview", ""),
                            "screenshots": d.get("screenshots", []),
                            "deps": d.get("dependencies", []),
                            "settings": d.get("settings", []),
                            "dir": plugin_path
                        })
                except Exception: continue
        return info_list
    
    def remove_plugin(self, plugin_id):
        print(f"ktools: attempting to remove plugin: {plugin_id}")

        if plugin_id in self.plugins:
            try:
                p_inst = self.plugins[plugin_id]
                if hasattr(p_inst, 'unload'):
                    p_inst.unload()
                del self.plugins[plugin_id]
                mod_name = f"ktools_plugins.{plugin_id}"
                if mod_name in sys.modules:
                    del sys.modules[mod_name]
            except Exception as e:
                print(f"ktools: error unloading before removal: {e}")

        p_dir = os.path.join(os.path.dirname(__file__), "plugins", plugin_id)
        if not os.path.exists(p_dir):
            plugins_root = os.path.join(os.path.dirname(__file__), "plugins")
            if os.path.isdir(plugins_root):
                for entry in os.listdir(plugins_root):
                    if entry.startswith(".") or entry == "__MACOSX":
                        continue
                    edir = os.path.join(plugins_root, entry)
                    if not os.path.isdir(edir):
                        continue
                    inf_p = os.path.join(edir, "inf.json")
                    if os.path.isfile(inf_p):
                        try:
                            with open(inf_p, "r", encoding="utf-8") as f:
                                d = json.load(f)
                                if d.get("id") == plugin_id or d.get("name") == plugin_id:
                                    p_dir = edir
                                    break
                        except Exception:
                            pass

        if os.path.exists(p_dir):
            try:
                shutil.rmtree(p_dir)
                print(f"ktools files for {plugin_id} deleted")
            except Exception as e:
                self.notify(f"file error: {e}")
                return

        self.notify(f"plugin {plugin_id} removed")
        self.dep_mgr.cleanup_unused()
        self.reload_all()

    def add_log(self, message):
        if hasattr(self, 'manager') and self.manager and hasattr(self.manager, 'add_log'):
            self.manager.add_log(message)
        else:
            print(f"ktools: {message}")

    def isolate_plugin_crash(self, plugin_id, error_msg):
        print(f"ktools: isolating crash in plugin {plugin_id}")
        if plugin_id in self.plugins:
            try:
                p_inst = self.plugins[plugin_id]
                target_win = getattr(p_inst, 'shell', getattr(p_inst, 'window', getattr(p_inst, 'monitor', None)))
                if target_win:
                    target_win.hide()
                    target_win.deleteLater()
                if hasattr(p_inst, 'unload'):
                    p_inst.unload()
                del self.plugins[plugin_id]
                mod_name = f"ktools_plugins.{plugin_id}"
                if mod_name in sys.modules:
                    del sys.modules[mod_name]
            except Exception as e:
                print(f"ktools: error during crash isolation of {plugin_id}: {e}")
        
        self.notify(f"plugin {plugin_id} crashed!\ncheck logs. it was unloaded.")
        self.add_log(f"CRASH ISOLATED: {plugin_id}\n{error_msg}")
        self.refresh_menu()

    def run(self): 
        sys.exit(self.app.exec())

if __name__ == "__main__":
    ktools().run()
